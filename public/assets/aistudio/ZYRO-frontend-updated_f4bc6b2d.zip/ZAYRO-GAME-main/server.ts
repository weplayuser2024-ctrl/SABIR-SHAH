import express from 'express';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';
import {
  ACTIVITY_CHESTS,
  AuthProvider,
  DirectMessage,
  FamilyGroup,
  FeedPost,
  GACHA_REWARDS,
  GIFT_CATALOG,
  GachaWonItem,
  PublicFriend,
  RoomInvitation,
  RoomMessage,
  SHOP_ITEMS,
  SeatState,
  TOPUP_PACKAGES,
  UserProfile,
  VOICE_ROOM_TYPES,
  VoiceRoom,
  VoiceRoomType,
  DAILY_TASKS,
  computeGiftCharm,
  computeRoomLevel,
  computeVipLevel,
} from './src/shared/types.ts';

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'joyplay-db.json');

interface PendingAuthCode {
  code: string;
  provider: AuthProvider;
  identifier: string;
  expiresAt: number;
}

interface DatabaseSchema {
  users: Record<string, UserProfile>;
  sessions: Record<string, string>; // token -> userId
  rooms: Record<string, VoiceRoom>;
  roomMessages: Record<string, RoomMessage[]>;
  directMessages: Record<string, DirectMessage[]>;
  roomInvitations: RoomInvitation[];
  posts: FeedPost[];
  families: Record<string, FamilyGroup>;
  userTaskProgress: Record<string, { games: number; gifts: number; posts: number }>;
}

function createEmptySeats(owner: { id: string; name: string; dp: string; vipLevel: number }): SeatState[] {
  return Array.from({ length: 13 }, (_, idx) => {
    if (idx === 0) {
      return {
        seatIndex: 0,
        userId: owner.id,
        userName: owner.name,
        userDp: owner.dp,
        vipLevel: owner.vipLevel,
        isMuted: false,
        isSpeaking: false,
        isLocked: true, // Reserved for room owner
      };
    }
    return {
      seatIndex: idx,
      userId: null,
      userName: null,
      userDp: null,
      vipLevel: 0,
      isMuted: true,
      isSpeaking: false,
      isLocked: false,
    };
  });
}

function createSeedDatabase(): DatabaseSchema {
  const seedUsers: UserProfile[] = [
    {
      id: '8011204',
      authProvider: 'gmail',
      authIdentifier: 'aria.chen@gmail.com',
      name: 'Aria Chen',
      bio: 'Late-night Carrom striker & acoustic singer. Drop a rose if you vibe!',
      dp: 'pfp_aria',
      idStyle: 'royal',
      coins: 12400,
      totalCoinsSpent: 22500,
      vipLevel: 9,
      cpPoints: 4820,
      charmPoints: 9350,
      winsCount: 64,
      equippedChatEffect: 'chat_sakura',
      equippedEntryEffect: 'auto-vip',
      ownedChatEffects: ['chat_default', 'chat_mint', 'chat_sakura'],
      ownedEntryEffects: ['ride_scooter'],
      familyId: 'fam_phoenix',
      friends: ['8011209', '8011342', '8011588'],
      claimedTasks: [],
      claimedEvents: [],
      dailyCheckinStreak: 5,
      lastCheckinDate: null,
      privacy: {
        profileVisibility: 'everyone',
        showOnlineStatus: true,
        allowRoomInvites: true,
        allowFriendRequests: true,
        hideWealthLevel: false,
      },
      parental: {
        enabled: false,
        pinCode: '1234',
        dailySpendLimit: 5000,
        dailySpentToday: 0,
        restrictVoiceMic: false,
        safeContentFilter: true,
        playtimeLimitMinutes: 120,
      },
      isOnline: true,
      currentActivity: 'In Voice Room: Midnight Acoustic Lounge',
      gachaInventory: [],
      claimedChests: [],
      lastGachaFreeDate: null,
      familyActivityPoints: 620,
    },
    {
      id: '8011209',
      authProvider: 'facebook',
      authIdentifier: 'marcus.vega',
      name: 'Marcus Vega',
      bio: 'Uno +4 menace and Spy detective champion.',
      dp: 'pfp_marcus',
      idStyle: 'obsidian',
      coins: 8900,
      totalCoinsSpent: 61500,
      vipLevel: 12,
      cpPoints: 7400,
      charmPoints: 14200,
      winsCount: 112,
      equippedChatEffect: 'chat_royal',
      equippedEntryEffect: 'auto-vip',
      ownedChatEffects: ['chat_default', 'chat_royal'],
      ownedEntryEffects: ['ride_chariot'],
      familyId: 'fam_kings',
      friends: ['8011204', '8011342'],
      claimedTasks: [],
      claimedEvents: [],
      dailyCheckinStreak: 11,
      lastCheckinDate: null,
      privacy: {
        profileVisibility: 'everyone',
        showOnlineStatus: true,
        allowRoomInvites: true,
        allowFriendRequests: true,
        hideWealthLevel: false,
      },
      parental: {
        enabled: false,
        pinCode: '1234',
        dailySpendLimit: 10000,
        dailySpentToday: 0,
        restrictVoiceMic: false,
        safeContentFilter: true,
        playtimeLimitMinutes: 180,
      },
      isOnline: true,
      currentActivity: 'Hosting Carrom & Chill',
      gachaInventory: [],
      claimedChests: [],
      lastGachaFreeDate: null,
      familyActivityPoints: 480,
    },
    {
      id: '8011342',
      authProvider: 'phone',
      authIdentifier: '+14155550192',
      name: 'Nadia Sky',
      bio: 'Collecting CP for Starlight Squad. Always down for Star Mic duets!',
      dp: 'pfp_nadia',
      idStyle: 'sunset',
      coins: 4500,
      totalCoinsSpent: 125000,
      vipLevel: 14,
      cpPoints: 11200,
      charmPoints: 26400,
      winsCount: 89,
      equippedChatEffect: 'chat_nebula',
      equippedEntryEffect: 'auto-vip',
      ownedChatEffects: ['chat_default', 'chat_nebula', 'chat_royal'],
      ownedEntryEffects: ['ride_pegasus', 'ride_chariot'],
      familyId: 'fam_starlight',
      friends: ['8011204', '8011209'],
      claimedTasks: [],
      claimedEvents: [],
      dailyCheckinStreak: 21,
      lastCheckinDate: null,
      privacy: {
        profileVisibility: 'everyone',
        showOnlineStatus: true,
        allowRoomInvites: true,
        allowFriendRequests: true,
        hideWealthLevel: false,
      },
      parental: {
        enabled: false,
        pinCode: '1234',
        dailySpendLimit: 20000,
        dailySpentToday: 0,
        restrictVoiceMic: false,
        safeContentFilter: true,
        playtimeLimitMinutes: 240,
      },
      isOnline: true,
      currentActivity: 'In Voice Room: Starlight Karaoke Stage',
      gachaInventory: [],
      claimedChests: [],
      lastGachaFreeDate: null,
      familyActivityPoints: 920,
    },
    {
      id: '8011588',
      authProvider: 'gmail',
      authIdentifier: 'leo.park@gmail.com',
      name: 'Leo Park',
      bio: 'Quiet strategist. Never trust me in Who is the Spy.',
      dp: 'pfp_leo',
      idStyle: 'emerald',
      coins: 2100,
      totalCoinsSpent: 3400,
      vipLevel: 5,
      cpPoints: 1940,
      charmPoints: 3100,
      winsCount: 41,
      equippedChatEffect: 'chat_mint',
      equippedEntryEffect: 'auto-vip',
      ownedChatEffects: ['chat_default', 'chat_mint'],
      ownedEntryEffects: [],
      familyId: 'fam_phoenix',
      friends: ['8011204'],
      claimedTasks: [],
      claimedEvents: [],
      dailyCheckinStreak: 3,
      lastCheckinDate: null,
      privacy: {
        profileVisibility: 'everyone',
        showOnlineStatus: true,
        allowRoomInvites: true,
        allowFriendRequests: true,
        hideWealthLevel: false,
      },
      parental: {
        enabled: false,
        pinCode: '1234',
        dailySpendLimit: 5000,
        dailySpentToday: 0,
        restrictVoiceMic: false,
        safeContentFilter: true,
        playtimeLimitMinutes: 120,
      },
      isOnline: true,
      currentActivity: 'Playing Uno Blitz',
      gachaInventory: [],
      claimedChests: [],
      lastGachaFreeDate: null,
      familyActivityPoints: 210,
    },
  ];

  const users: Record<string, UserProfile> = {};
  for (const u of seedUsers) users[u.id] = u;

  const room1Seats = createEmptySeats({ id: '8011204', name: 'Aria Chen', dp: 'pfp_aria', vipLevel: 9 });
  room1Seats[1] = { seatIndex: 1, userId: '8011588', userName: 'Leo Park', userDp: 'pfp_leo', vipLevel: 5, isMuted: false, isSpeaking: false, isLocked: false };

  const room2Seats = createEmptySeats({ id: '8011342', name: 'Nadia Sky', dp: 'pfp_nadia', vipLevel: 14 });
  room2Seats[2] = { seatIndex: 2, userId: '8011209', userName: 'Marcus Vega', userDp: 'pfp_marcus', vipLevel: 12, isMuted: false, isSpeaking: false, isLocked: false };

  const room3Seats = createEmptySeats({ id: '8011209', name: 'Marcus Vega', dp: 'pfp_marcus', vipLevel: 12 });

  const room4Seats = createEmptySeats({ id: '8011588', name: 'Leo Park', dp: 'pfp_leo', vipLevel: 5 });

  const rooms: Record<string, VoiceRoom> = {
    room_midnight: {
      id: 'room_midnight',
      title: 'Midnight Acoustic Lounge',
      category: 'Music',
      roomType: 'YouTube Room',
      ownerId: '8011204',
      ownerName: 'Aria Chen',
      ownerDp: 'pfp_aria',
      ownerVipLevel: 9,
      level: 4,
      xpCoins: 1850,
      nextLevelCoins: 3200,
      seats: room1Seats,
      listenersCount: 14,
      createdAt: Date.now() - 3600000 * 3,
    },
    room_starlight: {
      id: 'room_starlight',
      title: 'Starlight Friends Hangout',
      category: 'Friend',
      roomType: 'Normal',
      ownerId: '8011342',
      ownerName: 'Nadia Sky',
      ownerDp: 'pfp_nadia',
      ownerVipLevel: 14,
      level: 6,
      xpCoins: 6420,
      nextLevelCoins: 10000,
      seats: room2Seats,
      listenersCount: 28,
      createdAt: Date.now() - 3600000 * 5,
    },
    room_carrom: {
      id: 'room_carrom',
      title: 'Carrom & Spy Strategy Arena',
      category: 'Game',
      roomType: 'Game Room',
      ownerId: '8011209',
      ownerName: 'Marcus Vega',
      ownerDp: 'pfp_marcus',
      ownerVipLevel: 12,
      level: 3,
      xpCoins: 740,
      nextLevelCoins: 1500,
      seats: room3Seats,
      listenersCount: 9,
      createdAt: Date.now() - 3600000 * 1.5,
    },
    room_nightowl: {
      id: 'room_nightowl',
      title: 'Late Night Tea & Chat',
      category: 'Chat',
      roomType: 'Normal',
      ownerId: '8011588',
      ownerName: 'Leo Park',
      ownerDp: 'pfp_leo',
      ownerVipLevel: 5,
      level: 2,
      xpCoins: 420,
      nextLevelCoins: 600,
      seats: room4Seats,
      listenersCount: 11,
      createdAt: Date.now() - 3600000,
    },
  };

  const roomMessages: Record<string, RoomMessage[]> = {
    room_midnight: [
      {
        id: 'msg_seed_1',
        roomId: 'room_midnight',
        userId: '8011204',
        userName: 'Aria Chen',
        userDp: 'avatar_fox',
        vipLevel: 9,
        chatEffect: 'chat_sakura',
        type: 'chat',
        text: 'Welcome to Midnight Acoustic! Grab seats 1–9 and drop an emote.',
        timestamp: Date.now() - 180000,
      },
      {
        id: 'msg_seed_2',
        roomId: 'room_midnight',
        userId: '8011588',
        userName: 'Leo Park',
        userDp: 'avatar_owl',
        vipLevel: 5,
        chatEffect: 'chat_mint',
        type: 'chat',
        text: 'Just pulled off a double Carrom pocket earlier—ready for round two!',
        timestamp: Date.now() - 90000,
      },
    ],
    room_starlight: [
      {
        id: 'msg_seed_3',
        roomId: 'room_starlight',
        userId: '8011342',
        userName: 'Nadia Sky',
        userDp: 'avatar_unicorn',
        vipLevel: 14,
        chatEffect: 'chat_nebula',
        type: 'chat',
        text: 'VIP 14 Eternal Supreme celebration tonight—every gift levels the room!',
        timestamp: Date.now() - 120000,
      },
    ],
    room_carrom: [],
  };

  const families: Record<string, FamilyGroup> = {
    fam_phoenix: {
      id: 'fam_phoenix',
      name: 'Royal Phoenix',
      crest: '🔥',
      motto: 'Play bold, gift generously, rise together.',
      level: 7,
      totalCp: 18400,
      activityScore: 620,
      barrierUntil: 0,
      leaderId: '8011204',
      leaderName: 'Aria Chen',
      memberIds: ['8011204', '8011588'],
      maxMembers: 50,
    },
    fam_kings: {
      id: 'fam_kings',
      name: 'Carrom Kings',
      crest: '👑',
      motto: 'Queen pocket specialists & Uno card sharks.',
      level: 8,
      totalCp: 24900,
      activityScore: 780,
      barrierUntil: 0,
      leaderId: '8011209',
      leaderName: 'Marcus Vega',
      memberIds: ['8011209'],
      maxMembers: 50,
    },
    fam_starlight: {
      id: 'fam_starlight',
      name: 'Starlight Squad',
      crest: '🌟',
      motto: 'Open mic harmony and top-tier voice rooms every night.',
      level: 10,
      totalCp: 41200,
      activityScore: 1450,
      barrierUntil: Date.now() + 3600000 * 3,
      leaderId: '8011342',
      leaderName: 'Nadia Sky',
      memberIds: ['8011342'],
      maxMembers: 60,
    },
    fam_midnight: {
      id: 'fam_midnight',
      name: 'Midnight Detectives',
      crest: '🕵️',
      motto: 'Read the room, spot the Spy, claim the crown.',
      level: 5,
      totalCp: 9600,
      activityScore: 210,
      barrierUntil: 0,
      leaderId: '8011588',
      leaderName: 'Leo Park',
      memberIds: [],
      maxMembers: 40,
    },
  };

  const posts: FeedPost[] = [
    {
      id: 'post_video_1',
      authorId: '8011204',
      authorName: 'Aria Chen',
      authorDp: 'avatar_fox',
      authorVip: 9,
      tag: 'Voice Room Clip',
      mediaType: 'video',
      videoTitle: 'Midnight Acoustic Encore — Live Duet Highlight',
      videoDuration: '0:24',
      videoTheme: 'concert',
      content: 'Recorded tonight’s live vocal jam from Midnight Acoustic Lounge! Turn up the volume and drop a rose for the squad.',
      likes: ['8011209', '8011342'],
      cpBoosts: 280,
      comments: [
        { id: 'c_v1', userId: '8011342', userName: 'Nadia Sky', text: 'Your chorus harmony hit so clean!', timestamp: Date.now() - 280000 },
      ],
      createdAt: Date.now() - 900000,
    },
    {
      id: 'post_video_2',
      authorId: '8011209',
      authorName: 'Marcus Vega',
      authorDp: 'avatar_lion',
      authorVip: 12,
      tag: 'Carrom & Uno',
      mediaType: 'video',
      videoTitle: 'Impossible Bank Shot Red Queen + Cover',
      videoDuration: '0:18',
      videoTheme: 'carrom',
      content: 'Clipped my double rebound Carrom finish from tonight’s 1v1 showdown. Who wants the next match?',
      likes: ['8011204', '8011588'],
      cpBoosts: 220,
      comments: [],
      createdAt: Date.now() - 1400000,
    },
    {
      id: 'post_1',
      authorId: '8011342',
      authorName: 'Nadia Sky',
      authorDp: 'avatar_unicorn',
      authorVip: 14,
      tag: 'VIP 14 Milestone',
      mediaType: 'post',
      content: 'Finally unlocked Eternal Supreme (VIP 14)! Hop into Starlight Karaoke to see the red-carpet fireworks entry animation live!',
      likes: ['8011204', '8011209'],
      cpBoosts: 340,
      comments: [
        { id: 'c_1', userId: '8011204', userName: 'Aria Chen', text: 'That VIP 14 entrance looks unreal on stage!', timestamp: Date.now() - 400000 },
      ],
      createdAt: Date.now() - 1800000,
    },
    {
      id: 'post_2',
      authorId: '8011209',
      authorName: 'Marcus Vega',
      authorDp: 'avatar_lion',
      authorVip: 12,
      tag: 'Carrom & Uno',
      mediaType: 'post',
      content: 'Just pocketed the Red Queen + cover in 3 turns. Anyone challenging Carrom Kings for CP tonight?',
      likes: ['8011588'],
      cpBoosts: 190,
      comments: [],
      createdAt: Date.now() - 5400000,
    },
    {
      id: 'post_3',
      authorId: '8011588',
      authorName: 'Leo Park',
      authorDp: 'avatar_owl',
      authorVip: 5,
      tag: 'Who is the Spy',
      mediaType: 'post',
      content: 'Tip for Spy mode: never give too specific a clue on round 1 or the Civilians will vote you off immediately!',
      likes: ['8011204', '8011342'],
      cpBoosts: 120,
      comments: [],
      createdAt: Date.now() - 9200000,
    },
  ];

  return {
    users,
    sessions: {},
    rooms,
    roomMessages,
    directMessages: {
      '8011204_8011209': [
        {
          id: 'dm_seed_1',
          fromId: '8011204',
          toId: '8011209',
          text: 'Hey Marcus! Ready for a Carrom or Voice Room session tonight?',
          timestamp: Date.now() - 1800000,
        },
        {
          id: 'dm_seed_2',
          fromId: '8011209',
          toId: '8011204',
          text: 'Always ready! Jump into my Game Room whenever you are free.',
          timestamp: Date.now() - 1200000,
        },
      ],
    },
    posts,
    families,
    roomInvitations: [],
    userTaskProgress: {},
  };
}

function loadDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as DatabaseSchema;
      if (parsed && parsed.users && parsed.rooms) {
        const legacyMap: Record<string, VoiceRoom['category']> = {
          Party: 'Friend',
          Casual: 'Friend',
          Music: 'Music',
          Singing: 'Music',
          Gaming: 'Game',
          Chill: 'Chat',
          Chatting: 'Chat',
        };
        for (const r of Object.values(parsed.rooms)) {
          const rawCat = String(r.category);
          if (legacyMap[rawCat]) {
            r.category = legacyMap[rawCat];
          }
          if (!r.roomType || !(VOICE_ROOM_TYPES as readonly string[]).includes(r.roomType)) {
            if (r.id === 'room_midnight') r.roomType = 'YouTube Room';
            else if (r.id === 'room_carrom') r.roomType = 'Game Room';
            else if (r.id === 'room_nightowl') r.roomType = 'Normal';
            else r.roomType = 'Normal';
          }
        }
        for (const room of Object.values(parsed.rooms || {}) as VoiceRoom[]) {
          if (!Array.isArray(room.seats)) room.seats = [];
          while (room.seats.length < 13) {
            const seatIndex = room.seats.length;
            room.seats.push({
              seatIndex, userId: null, userName: null, userDp: null,
              vipLevel: 0, isMuted: true, isSpeaking: false, isLocked: false,
            });
          }
        }
        if (!parsed.directMessages) {
          parsed.directMessages = {};
        }
        if (!parsed.roomInvitations) {
          parsed.roomInvitations = [];
        }
        const legacySeedDps: Record<string, string> = {
          '8011204': 'pfp_aria',
          '8011209': 'pfp_marcus',
          '8011342': 'pfp_nadia',
          '8011588': 'pfp_leo',
        };
        const legacyEmojiIds = new Set(['avatar_fox', 'avatar_lion', 'avatar_unicorn', 'avatar_owl']);
        for (const u of Object.values(parsed.users)) {
          if (!Array.isArray(u.gachaInventory)) u.gachaInventory = [];
          if (!Array.isArray(u.claimedChests)) u.claimedChests = [];
          if (u.lastGachaFreeDate === undefined) u.lastGachaFreeDate = null;
          if (typeof u.familyActivityPoints !== 'number') {
            u.familyActivityPoints = u.id === '8011204' ? 620 : u.id === '8011342' ? 920 : 240;
          }
          if (!u.idStyle) {
            u.idStyle = u.id === '8011209' ? 'obsidian' : u.id === '8011342' ? 'sunset' : u.id === '8011588' ? 'emerald' : 'royal';
          }
          if (legacySeedDps[u.id] && legacyEmojiIds.has(u.dp)) {
            u.dp = legacySeedDps[u.id];
          }
        }
        for (const r of Object.values(parsed.rooms)) {
          if (legacySeedDps[r.ownerId] && legacyEmojiIds.has(r.ownerDp)) {
            r.ownerDp = legacySeedDps[r.ownerId];
          }
          r.seats.forEach((s) => {
            if (s.userId && legacySeedDps[s.userId] && s.userDp && legacyEmojiIds.has(s.userDp)) {
              s.userDp = legacySeedDps[s.userId];
            }
          });
        }
        if (parsed.families) {
          for (const f of Object.values(parsed.families)) {
            if (typeof f.activityScore !== 'number') {
              f.activityScore = Math.max(200, Math.round(f.totalCp * 0.04));
            }
            if (typeof f.barrierUntil !== 'number') {
              f.barrierUntil = f.id === 'fam_starlight' ? Date.now() + 3600000 * 3 : 0;
            }
          }
        }
        if (!Array.isArray(parsed.posts)) {
          parsed.posts = [];
        }
        for (const p of parsed.posts) {
          if (legacySeedDps[p.authorId] && legacyEmojiIds.has(p.authorDp)) {
            p.authorDp = legacySeedDps[p.authorId];
          }
        }
        const hasVideoPost = parsed.posts.some((p) => p.mediaType === 'video');
        if (!hasVideoPost) {
          parsed.posts.unshift(
            {
              id: 'post_video_1',
              authorId: '8011204',
              authorName: 'Aria Chen',
              authorDp: 'pfp_aria',
              authorVip: 9,
              tag: 'Voice Room Clip',
              mediaType: 'video',
              videoTitle: 'Midnight Acoustic Encore — Live Duet Highlight',
              videoDuration: '0:24',
              videoTheme: 'concert',
              content: 'Recorded tonight’s live vocal jam from Midnight Acoustic Lounge! Turn up the volume and drop a rose for the squad.',
              likes: ['8011209', '8011342'],
              cpBoosts: 280,
              comments: [
                { id: 'c_v1', userId: '8011342', userName: 'Nadia Sky', text: 'Your chorus harmony hit so clean!', timestamp: Date.now() - 280000 },
              ],
              createdAt: Date.now() - 900000,
            },
            {
              id: 'post_video_2',
              authorId: '8011209',
              authorName: 'Marcus Vega',
              authorDp: 'pfp_marcus',
              authorVip: 12,
              tag: 'Carrom & Uno',
              mediaType: 'video',
              videoTitle: 'Impossible Bank Shot Red Queen + Cover',
              videoDuration: '0:18',
              videoTheme: 'carrom',
              content: 'Clipped my double rebound Carrom finish from tonight’s 1v1 showdown. Who wants the next match?',
              likes: ['8011204', '8011588'],
              cpBoosts: 220,
              comments: [],
              createdAt: Date.now() - 1400000,
            }
          );
        }
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Resetting corrupt DB file:', err);
  }
  const seeded = createSeedDatabase();
  saveDatabase(seeded);
  return seeded;
}

function saveDatabase(data: DatabaseSchema) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist DB:', err);
  }
}

const db: DatabaseSchema = loadDatabase();
const pendingCodes = new Map<string, PendingAuthCode>();

// Track live WebSocket connections per user and per room
const wsClients = new Map<WebSocket, { userId: string; roomId: string | null }>();

function broadcastAll(event: string, payload: unknown) {
  const frame = JSON.stringify({ event, payload });
  for (const [ws] of wsClients.entries()) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(frame);
    }
  }
}

function broadcastToRoom(roomId: string, event: string, payload: unknown) {
  const frame = JSON.stringify({ event, payload });
  for (const [ws, meta] of wsClients.entries()) {
    if (ws.readyState === WebSocket.OPEN && meta.roomId === roomId) {
      ws.send(frame);
    }
  }
}

function sendToUser(userId: string, event: string, payload: unknown) {
  const frame = JSON.stringify({ event, payload });
  for (const [ws, meta] of wsClients.entries()) {
    if (ws.readyState === WebSocket.OPEN && meta.userId === userId) {
      ws.send(frame);
    }
  }
}

function getDmThreadKey(userA: string, userB: string): string {
  return userA < userB ? `${userA}_${userB}` : `${userB}_${userA}`;
}

function getFriendsList(viewer: UserProfile): PublicFriend[] {
  return Object.values(db.users)
    .filter((u) => u.id !== viewer.id)
    .map((u) => {
      const roomWithUser = Object.values(db.rooms).find((r) =>
        r.seats.some((s) => s.userId === u.id)
      );
      const fam = u.familyId ? db.families[u.familyId] : null;
      return {
        id: u.id,
        name: u.name,
        dp: u.dp,
        bio: u.bio,
        vipLevel: u.privacy.hideWealthLevel ? 0 : u.vipLevel,
        cpPoints: u.cpPoints,
        charmPoints: u.charmPoints,
        winsCount: u.winsCount,
        isOnline: u.privacy.showOnlineStatus ? u.isOnline : false,
        currentActivity: u.currentActivity,
        currentRoomId: roomWithUser ? roomWithUser.id : null,
        familyName: fam ? fam.name : null,
      };
    });
}

function getRankings() {
  const all = Object.values(db.users);
  return {
    wealth: [...all]
      .sort((a, b) => b.totalCoinsSpent - a.totalCoinsSpent)
      .slice(0, 15)
      .map((u, idx) => ({
        rank: idx + 1,
        id: u.id,
        name: u.name,
        dp: u.dp,
        vipLevel: u.vipLevel,
        charmPoints: u.charmPoints,
        score: u.totalCoinsSpent,
      })),
    charm: [...all]
      .sort((a, b) => b.charmPoints - a.charmPoints)
      .slice(0, 15)
      .map((u, idx) => ({
        rank: idx + 1,
        id: u.id,
        name: u.name,
        dp: u.dp,
        vipLevel: u.vipLevel,
        charmPoints: u.charmPoints,
        score: u.charmPoints,
      })),
    wins: [...all]
      .sort((a, b) => b.winsCount - a.winsCount)
      .slice(0, 15)
      .map((u, idx) => ({
        rank: idx + 1,
        id: u.id,
        name: u.name,
        dp: u.dp,
        vipLevel: u.vipLevel,
        charmPoints: u.charmPoints,
        score: u.winsCount,
      })),
  };
}

function getTaskProgress(user: UserProfile) {
  const today = new Date().toISOString().slice(0, 10);
  const progress = db.userTaskProgress[user.id] || { games: 0, gifts: 0, posts: 0 };
  return {
    checkin: user.lastCheckinDate === today ? 1 : 0,
    games: progress.games,
    gifts: progress.gifts,
    posts: progress.posts,
    vip: user.vipLevel >= 1 ? 1 : 0,
  };
}

function applyCoinSpend(user: UserProfile, amount: number): { ok: true } | { ok: false; error: string } {
  if (amount <= 0) return { ok: true };
  if (user.coins < amount) {
    return { ok: false, error: 'Not enough coins. Top up to continue!' };
  }
  if (user.parental.enabled) {
    if (user.parental.dailySpentToday + amount > user.parental.dailySpendLimit) {
      return {
        ok: false,
        error: `Blocked by Parental Controls: daily limit is ${user.parental.dailySpendLimit.toLocaleString()} coins.`,
      };
    }
    user.parental.dailySpentToday += amount;
  }
  user.coins -= amount;
  user.totalCoinsSpent += amount;
  user.vipLevel = computeVipLevel(user.totalCoinsSpent);
  return { ok: true };
}

function generateUserId(): string {
  let candidate = '';
  do {
    candidate = String(1000000 + Math.floor(Math.random() * 8999999));
  } while (db.users[candidate]);
  return candidate;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const reqUrl = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const token = reqUrl.searchParams.get('token') || '';
    const userId = db.sessions[token];
    if (!userId || !db.users[userId]) {
      ws.close(4001, 'Unauthorized');
      return;
    }

    const user = db.users[userId];
    user.isOnline = true;
    wsClients.set(ws, { userId, roomId: null });
    saveDatabase(db);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw)) as { event: string; payload?: Record<string, unknown> };
        const clientMeta = wsClients.get(ws);
        if (!clientMeta) return;
        const activeUser = db.users[clientMeta.userId];
        if (!activeUser) return;

        if (msg.event === 'room:join') {
          const roomId = String(msg.payload?.roomId || '');
          const room = db.rooms[roomId];
          if (!room) return;

          // Leave previous room if any
          if (clientMeta.roomId && clientMeta.roomId !== roomId) {
            const prevRoom = db.rooms[clientMeta.roomId];
            if (prevRoom) {
              prevRoom.seats.forEach((s) => {
                if (s.userId === activeUser.id && s.seatIndex !== 0) {
                  s.userId = null;
                  s.userName = null;
                  s.userDp = null;
                  s.vipLevel = 0;
                  s.isMuted = true;
                  s.isSpeaking = false;
                }
              });
              prevRoom.listenersCount = Math.max(1, prevRoom.listenersCount - 1);
              broadcastToRoom(prevRoom.id, 'room:state', prevRoom);
            }
          }

          clientMeta.roomId = roomId;
          room.listenersCount = Math.max(
            room.seats.filter((s) => s.userId !== null).length,
            room.listenersCount + 1
          );
          activeUser.currentActivity = `In Voice Room: ${room.title}`;
          saveDatabase(db);

          ws.send(
            JSON.stringify({
              event: 'room:init',
              payload: {
                room,
                messages: (db.roomMessages[roomId] || []).slice(-60),
              },
            })
          );

          // Broadcast VIP / Ride Entry Animation to everyone in the room!
          const entryMsg: RoomMessage = {
            id: `join_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            roomId,
            userId: activeUser.id,
            userName: activeUser.name,
            userDp: activeUser.dp,
            vipLevel: activeUser.vipLevel,
            chatEffect: activeUser.equippedChatEffect,
            type: 'join',
            text: `entered the room`,
            timestamp: Date.now(),
          };
          db.roomMessages[roomId] = [...(db.roomMessages[roomId] || []), entryMsg].slice(-80);
          saveDatabase(db);

          broadcastToRoom(roomId, 'room:entry_animation', {
            userId: activeUser.id,
            userName: activeUser.name,
            userDp: activeUser.dp,
            vipLevel: activeUser.vipLevel,
            equippedEntryEffect: activeUser.equippedEntryEffect,
            message: entryMsg,
          });
          broadcastToRoom(roomId, 'room:state', room);
          broadcastAll('rooms:list', Object.values(db.rooms));
        }

        if (msg.event === 'room:leave') {
          const roomId = clientMeta.roomId;
          if (!roomId) return;
          const room = db.rooms[roomId];
          if (room) {
            room.seats.forEach((s) => {
              if (s.userId === activeUser.id && s.seatIndex !== 0) {
                s.userId = null;
                s.userName = null;
                s.userDp = null;
                s.vipLevel = 0;
                s.isMuted = true;
                s.isSpeaking = false;
              }
            });
            room.listenersCount = Math.max(1, room.listenersCount - 1);
            broadcastToRoom(roomId, 'room:state', room);
          }
          clientMeta.roomId = null;
          activeUser.currentActivity = 'Browsing Play Lobby';
          saveDatabase(db);
          broadcastAll('rooms:list', Object.values(db.rooms));
        }

        if (msg.event === 'room:seat_take') {
          const roomId = clientMeta.roomId;
          const seatIndex = Number(msg.payload?.seatIndex);
          if (!roomId || !db.rooms[roomId]) return;
          const room = db.rooms[roomId];

          if (seatIndex < 0 || seatIndex > 9) return;
          // Seat 0 is exclusively reserved for the room owner
          if (seatIndex === 0 && room.ownerId !== activeUser.id) {
            ws.send(JSON.stringify({ event: 'room:error', payload: { error: 'Seat 1 (Host Throne) is reserved exclusively for the Room Owner.' } }));
            return;
          }

          const target = room.seats[seatIndex];
          if (target.userId && target.userId !== activeUser.id) {
            ws.send(JSON.stringify({ event: 'room:error', payload: { error: 'That seat is already occupied.' } }));
            return;
          }

          // Vacate any other seat held by this user in the room
          room.seats.forEach((s) => {
            if (s.userId === activeUser.id && s.seatIndex !== 0) {
              s.userId = null;
              s.userName = null;
              s.userDp = null;
              s.vipLevel = 0;
              s.isMuted = true;
              s.isSpeaking = false;
            }
          });

          target.userId = activeUser.id;
          target.userName = activeUser.name;
          target.userDp = activeUser.dp;
          target.vipLevel = activeUser.vipLevel;
          target.isMuted = activeUser.parental.enabled && activeUser.parental.restrictVoiceMic ? true : false;
          target.isSpeaking = false;
          saveDatabase(db);

          broadcastToRoom(roomId, 'room:state', room);
        }

        if (msg.event === 'room:seat_leave') {
          const roomId = clientMeta.roomId;
          if (!roomId || !db.rooms[roomId]) return;
          const room = db.rooms[roomId];
          room.seats.forEach((s) => {
            if (s.userId === activeUser.id && s.seatIndex !== 0) {
              s.userId = null;
              s.userName = null;
              s.userDp = null;
              s.vipLevel = 0;
              s.isMuted = true;
              s.isSpeaking = false;
            }
          });
          saveDatabase(db);
          broadcastToRoom(roomId, 'room:state', room);
        }

        if (msg.event === 'room:toggle_mute') {
          const roomId = clientMeta.roomId;
          if (!roomId || !db.rooms[roomId]) return;
          if (activeUser.parental.enabled && activeUser.parental.restrictVoiceMic) {
            ws.send(JSON.stringify({ event: 'room:error', payload: { error: 'Microphone disabled by Parental Controls.' } }));
            return;
          }
          const room = db.rooms[roomId];
          const seat = room.seats.find((s) => s.userId === activeUser.id);
          if (!seat) return;
          seat.isMuted = !seat.isMuted;
          if (seat.isMuted) seat.isSpeaking = false;
          saveDatabase(db);
          broadcastToRoom(roomId, 'room:state', room);
        }

        if (msg.event === 'room:speaking') {
          const roomId = clientMeta.roomId;
          if (!roomId || !db.rooms[roomId]) return;
          const room = db.rooms[roomId];
          const seat = room.seats.find((s) => s.userId === activeUser.id);
          if (!seat || seat.isMuted) return;
          seat.isSpeaking = Boolean(msg.payload?.isSpeaking);
          broadcastToRoom(roomId, 'room:state', room);
        }

        if (msg.event === 'room:chat') {
          const roomId = clientMeta.roomId;
          const text = String(msg.payload?.text || '').trim().slice(0, 240);
          if (!roomId || !db.rooms[roomId] || !text) return;

          const chatMsg: RoomMessage = {
            id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            roomId,
            userId: activeUser.id,
            userName: activeUser.name,
            userDp: activeUser.dp,
            vipLevel: activeUser.vipLevel,
            chatEffect: activeUser.equippedChatEffect,
            type: 'chat',
            text,
            timestamp: Date.now(),
          };
          db.roomMessages[roomId] = [...(db.roomMessages[roomId] || []), chatMsg].slice(-80);
          saveDatabase(db);
          broadcastToRoom(roomId, 'room:message', chatMsg);
        }

        if (msg.event === 'room:emote') {
          const roomId = clientMeta.roomId;
          const emoji = String(msg.payload?.emoji || '🔥');
          if (!roomId || !db.rooms[roomId]) return;
          const room = db.rooms[roomId];
          const seat = room.seats.find((s) => s.userId === activeUser.id);
          broadcastToRoom(roomId, 'room:emote', {
            userId: activeUser.id,
            userName: activeUser.name,
            seatIndex: seat ? seat.seatIndex : -1,
            emoji,
            id: `emote_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
          });
        }

        if (msg.event === 'room:change_type') {
          const roomId = clientMeta.roomId;
          const nextType = String(msg.payload?.roomType || '') as VoiceRoomType;
          if (!roomId || !db.rooms[roomId]) return;
          if (!(VOICE_ROOM_TYPES as readonly string[]).includes(nextType)) return;
          const room = db.rooms[roomId];
          if (room.roomType === nextType) return;

          room.roomType = nextType;
          const sysMsg: RoomMessage = {
            id: `type_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            roomId: room.id,
            userId: activeUser.id,
            userName: activeUser.name,
            userDp: activeUser.dp,
            vipLevel: activeUser.vipLevel,
            chatEffect: activeUser.equippedChatEffect,
            type: 'system',
            text: `switched the room mode to ${nextType}`,
            timestamp: Date.now(),
          };
          db.roomMessages[room.id] = [...(db.roomMessages[room.id] || []), sysMsg].slice(-80);
          saveDatabase(db);
          broadcastToRoom(room.id, 'room:state', room);
          broadcastToRoom(room.id, 'room:message', sysMsg);
          broadcastAll('rooms:list', Object.values(db.rooms));
        }

        if (msg.event === 'room:gift') {
          const roomId = clientMeta.roomId;
          const giftId = String(msg.payload?.giftId || '');
          const recipientId = String(msg.payload?.recipientId || '');
          const room = roomId ? db.rooms[roomId] : undefined;
          const gift = GIFT_CATALOG.find((g) => g.id === giftId);
          if (!room || !gift) return;

          const prevVip = activeUser.vipLevel;
          const spendResult = applyCoinSpend(activeUser, gift.coins);
          if (!spendResult.ok) {
            ws.send(JSON.stringify({ event: 'room:error', payload: { error: spendResult.error } }));
            return;
          }

          const charmGain = computeGiftCharm(gift.coins);
          const coinReturn = gift.coinReturn || 0;
          activeUser.coins += coinReturn;
          activeUser.charmPoints += charmGain;
          activeUser.cpPoints += gift.cpReward;

          const recipient = db.users[recipientId] || db.users[room.ownerId];
          if (recipient) {
            if (recipient.id !== activeUser.id) {
              recipient.charmPoints += charmGain;
            }
            recipient.cpPoints += Math.round(gift.cpReward * 0.4);
          }

          if (room.ownerId === activeUser.id) {
            room.ownerVipLevel = activeUser.vipLevel;
          }
          room.seats.forEach((s) => {
            if (s.userId === activeUser.id) {
              s.vipLevel = activeUser.vipLevel;
            }
          });

          const prevRoomLevel = room.level;
          room.xpCoins += gift.coins;
          const computed = computeRoomLevel(room.xpCoins);
          room.level = computed.level;
          room.nextLevelCoins = computed.nextLevelCoins;

          const progress = db.userTaskProgress[activeUser.id] || { games: 0, gifts: 0, posts: 0 };
          progress.gifts += 1;
          db.userTaskProgress[activeUser.id] = progress;

          const giftMsg: RoomMessage = {
            id: `gift_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            roomId: room.id,
            userId: activeUser.id,
            userName: activeUser.name,
            userDp: activeUser.dp,
            vipLevel: activeUser.vipLevel,
            chatEffect: activeUser.equippedChatEffect,
            type: 'gift',
            text: `sent ${gift.emoji} ${gift.name} to ${recipient ? recipient.name : room.ownerName} (+${charmGain} Charm${coinReturn > 0 ? `, +${coinReturn} Return Coins` : ''})`,
            giftId: gift.id,
            giftCoins: gift.coins,
            timestamp: Date.now(),
          };
          db.roomMessages[room.id] = [...(db.roomMessages[room.id] || []), giftMsg].slice(-80);
          saveDatabase(db);

          ws.send(
            JSON.stringify({
              event: 'user:updated',
              payload: {
                user: activeUser,
                vipLeveledUp: activeUser.vipLevel > prevVip,
                charmEarned: charmGain,
                coinReturn,
              },
            })
          );
          broadcastToRoom(room.id, 'room:gift_event', {
            gift,
            senderName: activeUser.name,
            senderDp: activeUser.dp,
            senderVip: activeUser.vipLevel,
            recipientName: recipient ? recipient.name : room.ownerName,
            charmEarned: charmGain,
            coinReturn,
            roomLeveledUp: room.level > prevRoomLevel,
            newRoomLevel: room.level,
            message: giftMsg,
          });
          broadcastToRoom(room.id, 'room:state', room);
          broadcastAll('rooms:list', Object.values(db.rooms));
        }
      } catch (err) {
        console.error('WebSocket message error:', err);
      }
    });

    ws.on('close', () => {
      const meta = wsClients.get(ws);
      wsClients.delete(ws);
      if (!meta) return;
      if (meta.roomId && db.rooms[meta.roomId]) {
        const room = db.rooms[meta.roomId];
        room.seats.forEach((s) => {
          if (s.userId === meta.userId && s.seatIndex !== 0) {
            s.userId = null;
            s.userName = null;
            s.userDp = null;
            s.vipLevel = 0;
            s.isMuted = true;
            s.isSpeaking = false;
          }
        });
        room.listenersCount = Math.max(1, room.listenersCount - 1);
        broadcastToRoom(room.id, 'room:state', room);
      }
      const stillConnected = Array.from(wsClients.values()).some((m) => m.userId === meta.userId);
      if (!stillConnected && db.users[meta.userId]) {
        db.users[meta.userId].isOnline = false;
        saveDatabase(db);
      }
    });
  });

  // Auth middleware
  function requireAuth(req: express.Request, res: express.Response): UserProfile | null {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    const userId = db.sessions[token];
    if (!userId || !db.users[userId]) {
      res.status(401).json({ error: 'Authentication required' });
      return null;
    }
    return db.users[userId];
  }

  // ---- AUTH ROUTES ----
  app.post('/api/auth/request-code', (req, res) => {
    const provider = req.body?.provider as AuthProvider;
    const rawIdentifier = String(req.body?.identifier || '').trim();

    if (!['gmail', 'facebook', 'phone'].includes(provider)) {
      res.status(400).json({ error: 'Unsupported sign-in provider.' });
      return;
    }

    let identifier = rawIdentifier;
    if (provider === 'gmail') {
      identifier = rawIdentifier.toLowerCase();
      if (!/^[^\s@]+@gmail\.com$/i.test(identifier) && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier)) {
        res.status(400).json({ error: 'Enter a valid Gmail address (e.g. name@gmail.com).' });
        return;
      }
    } else if (provider === 'phone') {
      const digits = rawIdentifier.replace(/[^\d+]/g, '');
      if (digits.length < 7) {
        res.status(400).json({ error: 'Enter a valid phone number with at least 7 digits.' });
        return;
      }
      identifier = digits;
    } else if (provider === 'facebook') {
      if (rawIdentifier.length < 3) {
        res.status(400).json({ error: 'Enter your Facebook name, handle, or email.' });
        return;
      }
    }

    const code = String(100000 + Math.floor(Math.random() * 900000));
    const key = `${provider}:${identifier.toLowerCase()}`;
    pendingCodes.set(key, {
      code,
      provider,
      identifier,
      expiresAt: Date.now() + 10 * 60 * 1000,
    });

    res.json({
      ok: true,
      identifier,
      provider,
      verificationCodePreview: code,
    });
  });

  app.post('/api/auth/verify', (req, res) => {
    const provider = req.body?.provider as AuthProvider;
    const identifier = String(req.body?.identifier || '').trim();
    const code = String(req.body?.code || '').trim();
    const displayNameInput = String(req.body?.displayName || '').trim();
    const dpInput = typeof req.body?.dp === 'string' && req.body.dp.length > 0 && req.body.dp.length < 500000
      ? req.body.dp
      : 'pfp_aria';

    if (!['gmail', 'facebook', 'phone'].includes(provider) || !identifier) {
      res.status(400).json({ error: 'Provider and account identifier are required.' });
      return;
    }

    const key = `${provider}:${identifier.toLowerCase()}`;
    const pending = pendingCodes.get(key);
    if (!pending || pending.expiresAt < Date.now()) {
      res.status(400).json({ error: 'Verification code expired. Request a new code.' });
      return;
    }
    if (pending.code !== code) {
      res.status(400).json({ error: 'Invalid 6-digit verification code.' });
      return;
    }
    pendingCodes.delete(key);

    let user = Object.values(db.users).find(
      (u) => u.authProvider === provider && u.authIdentifier.toLowerCase() === identifier.toLowerCase()
    );

    if (!user) {
      const id = generateUserId();
      const defaultName =
        displayNameInput ||
        (provider === 'gmail'
          ? identifier.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
          : provider === 'facebook'
          ? identifier
          : `Player ${id.slice(-4)}`);

      user = {
        id,
        authProvider: provider,
        authIdentifier: identifier,
        name: defaultName.slice(0, 28),
        bio: 'New to JoyPlay! Let’s play Carrom, Uno, or chill in a Voice Room.',
        dp: dpInput,
        idStyle: 'royal',
        coins: 1000,
        totalCoinsSpent: 0,
        vipLevel: 0,
        cpPoints: 120,
        charmPoints: 50,
        winsCount: 0,
        equippedChatEffect: 'chat_default',
        equippedEntryEffect: 'auto-vip',
        ownedChatEffects: ['chat_default'],
        ownedEntryEffects: [],
        familyId: null,
        friends: ['8011204', '8011209', '8011342'],
        claimedTasks: [],
        claimedEvents: [],
        dailyCheckinStreak: 1,
        lastCheckinDate: null,
        privacy: {
          profileVisibility: 'everyone',
          showOnlineStatus: true,
          allowRoomInvites: true,
          allowFriendRequests: true,
          hideWealthLevel: false,
        },
        parental: {
          enabled: false,
          pinCode: '1234',
          dailySpendLimit: 5000,
          dailySpentToday: 0,
          restrictVoiceMic: false,
          safeContentFilter: true,
          playtimeLimitMinutes: 120,
        },
        isOnline: true,
        currentActivity: 'Exploring JoyPlay Lobby',
        gachaInventory: [],
        claimedChests: [],
        lastGachaFreeDate: null,
        familyActivityPoints: 0,
      };
      db.users[id] = user;

      // Seed friendly welcome DMs and starter Room Invitations for the new account
      const welcomeKey1 = getDmThreadKey(id, '8011204');
      db.directMessages[welcomeKey1] = [
        {
          id: `dm_w1_${id}`,
          fromId: '8011204',
          toId: id,
          text: `Hey ${user.name}! Welcome to JoyPlay—feel free to drop into my voice room anytime!`,
          timestamp: Date.now() - 300000,
        },
      ];
      const welcomeKey2 = getDmThreadKey(id, '8011342');
      db.directMessages[welcomeKey2] = [
        {
          id: `dm_w2_${id}`,
          fromId: '8011342',
          toId: id,
          text: 'Let’s team up for Star Mic or Who’s the Spy later tonight!',
          timestamp: Date.now() - 180000,
        },
      ];

      const room1 = db.rooms['room_midnight'];
      const room2 = db.rooms['room_carrom'];
      if (room1) {
        db.roomInvitations.unshift({
          id: `inv_${id}_1`,
          roomId: room1.id,
          roomTitle: room1.title,
          roomType: room1.roomType,
          roomLevel: room1.level,
          fromId: '8011204',
          fromName: 'Aria Chen',
          fromDp: 'avatar_fox',
          fromVipLevel: 9,
          toId: id,
          message: 'Come grab a seat on stage in Midnight Acoustic Lounge!',
          status: 'pending',
          createdAt: Date.now() - 240000,
        });
      }
      if (room2) {
        db.roomInvitations.unshift({
          id: `inv_${id}_2`,
          roomId: room2.id,
          roomTitle: room2.title,
          roomType: room2.roomType,
          roomLevel: room2.level,
          fromId: '8011209',
          fromName: 'Marcus Vega',
          fromDp: 'avatar_lion',
          fromVipLevel: 12,
          toId: id,
          message: 'Need one more player for Carrom & Spy Strategy Arena!',
          status: 'pending',
          createdAt: Date.now() - 120000,
        });
      }
    } else {
      user.isOnline = true;
      user.currentActivity = 'Exploring JoyPlay Lobby';
    }

    const token = crypto.randomUUID();
    db.sessions[token] = user.id;
    saveDatabase(db);

    res.json({ token, user });
  });

  app.post('/api/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    const userId = db.sessions[token];
    if (userId && db.users[userId]) {
      db.users[userId].isOnline = false;
    }
    delete db.sessions[token];
    saveDatabase(db);
    res.json({ ok: true });
  });

  // ---- BOOTSTRAP ----
  app.get('/api/bootstrap', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;

    // Ensure existing test accounts without invitations get starter invitations
    const userInvites = db.roomInvitations.filter((inv) => inv.toId === user.id);
    if (userInvites.length === 0) {
      const room1 = db.rooms['room_midnight'];
      const room2 = db.rooms['room_carrom'];
      if (room1 && room1.ownerId !== user.id) {
        db.roomInvitations.unshift({
          id: `inv_${user.id}_1`,
          roomId: room1.id,
          roomTitle: room1.title,
          roomType: room1.roomType,
          roomLevel: room1.level,
          fromId: room1.ownerId,
          fromName: room1.ownerName,
          fromDp: room1.ownerDp,
          fromVipLevel: room1.ownerVipLevel,
          toId: user.id,
          message: 'Come grab a seat on stage with us!',
          status: 'pending',
          createdAt: Date.now() - 240000,
        });
      }
      if (room2 && room2.ownerId !== user.id) {
        db.roomInvitations.unshift({
          id: `inv_${user.id}_2`,
          roomId: room2.id,
          roomTitle: room2.title,
          roomType: room2.roomType,
          roomLevel: room2.level,
          fromId: room2.ownerId,
          fromName: room2.ownerName,
          fromDp: room2.ownerDp,
          fromVipLevel: room2.ownerVipLevel,
          toId: user.id,
          message: 'Join our squad room right now!',
          status: 'pending',
          createdAt: Date.now() - 120000,
        });
      }
      saveDatabase(db);
    }

    const friendsList = getFriendsList(user);
    const chatPreviews: Record<string, DirectMessage | null> = {};
    for (const f of friendsList) {
      const key = getDmThreadKey(user.id, f.id);
      const msgs = db.directMessages[key] || [];
      chatPreviews[f.id] = msgs.length > 0 ? msgs[msgs.length - 1] : null;
    }

    res.json({
      user,
      rooms: Object.values(db.rooms).sort((a, b) => b.level - a.level || b.listenersCount - a.listenersCount),
      friends: friendsList,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
      posts: [...db.posts].sort((a, b) => b.createdAt - a.createdAt),
      rankings: getRankings(),
      taskProgress: getTaskProgress(user),
      invitations: db.roomInvitations
        .filter((inv) => inv.toId === user.id)
        .sort((a, b) => b.createdAt - a.createdAt),
      chatPreviews,
    });
  });

  // ---- COINS & VIP ----
  app.post('/api/coins/topup', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const packageId = String(req.body?.packageId || '');
    const pkg = TOPUP_PACKAGES.find((p) => p.id === packageId);
    if (!pkg) {
      res.status(400).json({ error: 'Invalid top-up package.' });
      return;
    }
    const totalAdded = pkg.coins + pkg.bonus;
    user.coins += totalAdded;
    saveDatabase(db);
    res.json({ user, addedCoins: totalAdded });
  });

  app.post('/api/vip/upgrade', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const spendCoins = Number(req.body?.coins || 0);
    if (!Number.isFinite(spendCoins) || spendCoins <= 0) {
      res.status(400).json({ error: 'Invalid coin amount.' });
      return;
    }
    const prevVip = user.vipLevel;
    const result = applyCoinSpend(user, spendCoins);
    if (!result.ok) {
      res.status(400).json({ error: result.error });
      return;
    }
    user.cpPoints += Math.round(spendCoins * 0.5);
    saveDatabase(db);
    res.json({ user, vipLeveledUp: user.vipLevel > prevVip, prevVip });
  });

  // ---- SHOP ----
  app.post('/api/shop/buy', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const itemId = String(req.body?.itemId || '');
    const item = SHOP_ITEMS.find((i) => i.id === itemId);
    if (!item) {
      res.status(400).json({ error: 'Item not found.' });
      return;
    }
    const alreadyOwned =
      item.category === 'chat_effect'
        ? user.ownedChatEffects.includes(item.id)
        : user.ownedEntryEffects.includes(item.id);
    if (alreadyOwned) {
      res.status(400).json({ error: 'You already own this item.' });
      return;
    }
    const prevVip = user.vipLevel;
    const result = applyCoinSpend(user, item.price);
    if (!result.ok) {
      res.status(400).json({ error: result.error });
      return;
    }
    if (item.category === 'chat_effect') {
      user.ownedChatEffects.push(item.id);
      user.equippedChatEffect = item.id;
    } else {
      user.ownedEntryEffects.push(item.id);
      user.equippedEntryEffect = item.id;
    }
    saveDatabase(db);
    res.json({ user, vipLeveledUp: user.vipLevel > prevVip });
  });

  app.post('/api/shop/equip', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const type = String(req.body?.type || '');
    const itemId = String(req.body?.itemId || '');

    if (type === 'chat_effect') {
      if (!user.ownedChatEffects.includes(itemId)) {
        res.status(400).json({ error: 'Purchase this chat effect first.' });
        return;
      }
      user.equippedChatEffect = itemId;
    } else if (type === 'entry_effect') {
      if (itemId !== 'auto-vip' && !itemId.startsWith('vip_') && !user.ownedEntryEffects.includes(itemId)) {
        res.status(400).json({ error: 'Unlock or purchase this entry animation first.' });
        return;
      }
      if (itemId.startsWith('vip_')) {
        const lvl = Number(itemId.replace('vip_', ''));
        if (lvl > user.vipLevel) {
          res.status(400).json({ error: `Reach VIP ${lvl} to equip this entry animation.` });
          return;
        }
      }
      user.equippedEntryEffect = itemId;
    }
    saveDatabase(db);
    res.json({ user });
  });

  // ---- PROFILE, PRIVACY & PARENTAL ----
  app.patch('/api/profile', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;

    if (typeof req.body?.name === 'string') {
      const cleanName = req.body.name.trim().slice(0, 28);
      if (cleanName.length >= 2) {
        user.name = cleanName;
        // Update seats & owned rooms
        Object.values(db.rooms).forEach((room) => {
          if (room.ownerId === user.id) room.ownerName = cleanName;
          room.seats.forEach((s) => {
            if (s.userId === user.id) s.userName = cleanName;
          });
        });
      }
    }
    if (typeof req.body?.bio === 'string') {
      user.bio = req.body.bio.trim().slice(0, 160);
    }
    if (typeof req.body?.idStyle === 'string' && ['royal', 'obsidian', 'emerald', 'sunset'].includes(req.body.idStyle)) {
      user.idStyle = req.body.idStyle as UserProfile['idStyle'];
    }
    if (typeof req.body?.dp === 'string' && req.body.dp.length > 0 && req.body.dp.length < 500000) {
      user.dp = req.body.dp;
      Object.values(db.rooms).forEach((room) => {
        if (room.ownerId === user.id) room.ownerDp = user.dp;
        room.seats.forEach((s) => {
          if (s.userId === user.id) s.userDp = user.dp;
        });
      });
    }
    if (req.body?.privacy && typeof req.body.privacy === 'object') {
      user.privacy = { ...user.privacy, ...req.body.privacy };
    }
    if (req.body?.parental && typeof req.body.parental === 'object') {
      const incoming = req.body.parental;
      if (user.parental.enabled && incoming.pinAttempt !== user.parental.pinCode) {
        res.status(403).json({ error: 'Incorrect Parental PIN.' });
        return;
      }
      const nextPin = typeof incoming.pinCode === 'string' && /^\d{4}$/.test(incoming.pinCode)
        ? incoming.pinCode
        : user.parental.pinCode;
      user.parental = {
        enabled: Boolean(incoming.enabled),
        pinCode: nextPin,
        dailySpendLimit: Math.max(0, Number(incoming.dailySpendLimit ?? user.parental.dailySpendLimit)),
        dailySpentToday: user.parental.dailySpentToday,
        restrictVoiceMic: Boolean(incoming.restrictVoiceMic),
        safeContentFilter: Boolean(incoming.safeContentFilter),
        playtimeLimitMinutes: Math.max(15, Number(incoming.playtimeLimitMinutes ?? user.parental.playtimeLimitMinutes)),
      };
    }

    saveDatabase(db);
    res.json({ user });
  });

  // ---- VOICE ROOMS ----
  app.post('/api/rooms', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const title = String(req.body?.title || '').trim().slice(0, 42);
    const category = (['Friend', 'Game', 'Chat', 'Music'].includes(req.body?.category)
      ? req.body.category
      : 'Friend') as VoiceRoom['category'];
    const roomType = ((VOICE_ROOM_TYPES as readonly string[]).includes(req.body?.roomType)
      ? req.body.roomType
      : 'Normal') as VoiceRoomType;
    if (title.length < 3) {
      res.status(400).json({ error: 'Room name must be at least 3 characters.' });
      return;
    }

    const CREATE_ROOM_COST = 200;
    const prevVip = user.vipLevel;
    const spend = applyCoinSpend(user, CREATE_ROOM_COST);
    if (!spend.ok) {
      res.status(400).json({ error: spend.error });
      return;
    }

    const roomId = `room_${Date.now().toString(36)}`;
    const newRoom: VoiceRoom = {
      id: roomId,
      title,
      category,
      roomType,
      ownerId: user.id,
      ownerName: user.name,
      ownerDp: user.dp,
      ownerVipLevel: user.vipLevel,
      level: 1,
      xpCoins: CREATE_ROOM_COST,
      nextLevelCoins: 600,
      seats: createEmptySeats({ id: user.id, name: user.name, dp: user.dp, vipLevel: user.vipLevel }),
      listenersCount: 1,
      createdAt: Date.now(),
    };
    db.rooms[roomId] = newRoom;
    db.roomMessages[roomId] = [
      {
        id: `sys_${Date.now()}`,
        roomId,
        userId: user.id,
        userName: user.name,
        userDp: user.dp,
        vipLevel: user.vipLevel,
        chatEffect: user.equippedChatEffect,
        type: 'system',
        text: `${user.name} created this Voice Room! Seat 1 is reserved for the owner.`,
        timestamp: Date.now(),
      },
    ];
    saveDatabase(db);
    broadcastAll('rooms:list', Object.values(db.rooms));
    res.json({ room: newRoom, user, vipLeveledUp: user.vipLevel > prevVip });
  });

  // ---- TASKS & EVENTS ----
  app.post('/api/tasks/claim', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const taskId = String(req.body?.taskId || '');
    const task = DAILY_TASKS.find((t) => t.id === taskId);
    if (!task) {
      res.status(400).json({ error: 'Task not found.' });
      return;
    }
    if (user.claimedTasks.includes(taskId)) {
      res.status(400).json({ error: 'Task already claimed.' });
      return;
    }
    const progress = getTaskProgress(user);
    if (progress[task.metric] < task.target) {
      res.status(400).json({ error: 'Complete this task requirement first.' });
      return;
    }
    user.claimedTasks.push(taskId);
    user.coins += task.rewardCoins;
    user.cpPoints += task.rewardCp;
    saveDatabase(db);
    res.json({ user, taskProgress: getTaskProgress(user) });
  });

  app.post('/api/events/claim', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const eventId = String(req.body?.eventId || '');
    const rewards: Record<string, { coins: number; cp: number; minVip?: number }> = {
      evt_welcome_festival: { coins: 300, cp: 150 },
      evt_vip_celebration: { coins: 600, cp: 250, minVip: 1 },
      evt_party_streak: { coins: 450, cp: 200 },
    };
    const reward = rewards[eventId];
    if (!reward) {
      res.status(400).json({ error: 'Event reward not found.' });
      return;
    }
    if (user.claimedEvents.includes(eventId)) {
      res.status(400).json({ error: 'Event reward already claimed.' });
      return;
    }
    if (reward.minVip && user.vipLevel < reward.minVip) {
      res.status(400).json({ error: `Requires VIP ${reward.minVip} to claim this reward.` });
      return;
    }
    user.claimedEvents.push(eventId);
    user.coins += reward.coins;
    user.cpPoints += reward.cp;
    saveDatabase(db);
    res.json({ user });
  });

  // ---- FRIENDS & GAME REWARDS ----
  app.post('/api/friends/toggle', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const friendId = String(req.body?.friendId || '');
    if (!db.users[friendId] || friendId === user.id) {
      res.status(400).json({ error: 'Player not found.' });
      return;
    }
    if (user.friends.includes(friendId)) {
      user.friends = user.friends.filter((id) => id !== friendId);
    } else {
      user.friends.push(friendId);
    }
    saveDatabase(db);
    res.json({ user, friends: getFriendsList(user) });
  });

  app.post('/api/friends/send-cp', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const friendId = String(req.body?.friendId || '');
    const target = db.users[friendId];
    if (!target) {
      res.status(400).json({ error: 'Friend not found.' });
      return;
    }
    const prevVip = user.vipLevel;
    const spend = applyCoinSpend(user, 20);
    if (!spend.ok) {
      res.status(400).json({ error: spend.error });
      return;
    }
    const charmEarned = computeGiftCharm(20);
    const coinReturn = 2;
    user.coins += coinReturn;
    user.cpPoints += 40;
    user.charmPoints += charmEarned;
    target.cpPoints += 40;
    target.charmPoints += charmEarned;
    saveDatabase(db);
    res.json({
      user,
      friends: getFriendsList(user),
      charmEarned,
      coinReturn,
      vipLeveledUp: user.vipLevel > prevVip,
    });
  });

  app.post('/api/games/reward', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const won = Boolean(req.body?.won);
    const coinsReward = won ? 180 : 60;
    const cpReward = won ? 90 : 35;
    user.coins += coinsReward;
    user.cpPoints += cpReward;
    if (won) user.winsCount += 1;

    const progress = db.userTaskProgress[user.id] || { games: 0, gifts: 0, posts: 0 };
    progress.games += 1;
    db.userTaskProgress[user.id] = progress;
    saveDatabase(db);

    res.json({
      user,
      coinsReward,
      cpReward,
      taskProgress: getTaskProgress(user),
      rankings: getRankings(),
    });
  });

  // ---- DISCOVER: POSTS, CP & FAMILIES ----
  app.post('/api/cp/collect-daily', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const today = new Date().toISOString().slice(0, 10);
    if (user.lastCheckinDate === today) {
      res.status(400).json({ error: 'Daily CP already collected today!' });
      return;
    }
    user.lastCheckinDate = today;
    user.dailyCheckinStreak += 1;
    const bonusCp = 80 + user.vipLevel * 15;
    const bonusCoins = 100 + user.vipLevel * 20;
    user.cpPoints += bonusCp;
    user.coins += bonusCoins;
    saveDatabase(db);
    res.json({ user, bonusCp, bonusCoins, taskProgress: getTaskProgress(user) });
  });

  app.post('/api/posts', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const content = String(req.body?.content || '').trim().slice(0, 280);
    const tag = String(req.body?.tag || 'Party Highlight').trim().slice(0, 32);
    const mediaType = req.body?.mediaType === 'video' ? 'video' : 'post';
    const videoTitle = req.body?.videoTitle ? String(req.body.videoTitle).trim().slice(0, 80) : undefined;
    const videoDuration = req.body?.videoDuration ? String(req.body.videoDuration).trim().slice(0, 12) : undefined;
    const rawTheme = String(req.body?.videoTheme || '');
    const videoTheme =
      rawTheme === 'concert' || rawTheme === 'carrom' || rawTheme === 'party'
        ? rawTheme
        : mediaType === 'video'
        ? 'party'
        : undefined;
    const rawVideoUrl = typeof req.body?.videoUrl === 'string' ? req.body.videoUrl : undefined;
    const videoUrl =
      rawVideoUrl && rawVideoUrl.startsWith('data:video/') && rawVideoUrl.length < 3_000_000
        ? rawVideoUrl
        : undefined;

    if (content.length < 3) {
      res.status(400).json({ error: 'Post content is too short.' });
      return;
    }
    const post: FeedPost = {
      id: `post_${Date.now().toString(36)}`,
      authorId: user.id,
      authorName: user.name,
      authorDp: user.dp,
      authorVip: user.vipLevel,
      tag,
      mediaType,
      videoTitle,
      videoDuration: mediaType === 'video' ? videoDuration || '0:20' : undefined,
      videoUrl,
      videoTheme,
      content,
      likes: [],
      cpBoosts: 0,
      comments: [],
      createdAt: Date.now(),
    };
    db.posts.unshift(post);
    const progress = db.userTaskProgress[user.id] || { games: 0, gifts: 0, posts: 0 };
    progress.posts += 1;
    db.userTaskProgress[user.id] = progress;
    user.cpPoints += 25;
    saveDatabase(db);
    res.json({ post, user, posts: db.posts, taskProgress: getTaskProgress(user) });
  });

  app.post('/api/posts/:id/like', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const post = db.posts.find((p) => p.id === req.params.id);
    if (!post) {
      res.status(404).json({ error: 'Post not found.' });
      return;
    }
    if (post.likes.includes(user.id)) {
      post.likes = post.likes.filter((id) => id !== user.id);
    } else {
      post.likes.push(user.id);
    }
    saveDatabase(db);
    res.json({ posts: db.posts });
  });

  app.post('/api/posts/:id/cp', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const post = db.posts.find((p) => p.id === req.params.id);
    if (!post) {
      res.status(404).json({ error: 'Post not found.' });
      return;
    }
    post.cpBoosts += 20;
    user.cpPoints += 15;
    const progress = db.userTaskProgress[user.id] || { games: 0, gifts: 0, posts: 0 };
    progress.posts += 1;
    db.userTaskProgress[user.id] = progress;
    saveDatabase(db);
    res.json({ posts: db.posts, user, taskProgress: getTaskProgress(user) });
  });

  app.post('/api/posts/:id/comment', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const post = db.posts.find((p) => p.id === req.params.id);
    if (!post) {
      res.status(404).json({ error: 'Post not found.' });
      return;
    }
    const text = String(req.body?.text || '').trim().slice(0, 160);
    if (!text) {
      res.status(400).json({ error: 'Comment cannot be empty.' });
      return;
    }
    post.comments.push({
      id: `cmt_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      text,
      timestamp: Date.now(),
    });
    saveDatabase(db);
    res.json({ posts: db.posts });
  });

  app.post('/api/families/create', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const name = String(req.body?.name || '').trim().slice(0, 26);
    const motto = String(req.body?.motto || '').trim().slice(0, 90);
    const crest = String(req.body?.crest || '🛡️').slice(0, 4);
    if (name.length < 3) {
      res.status(400).json({ error: 'Family name must be at least 3 characters.' });
      return;
    }
    const COST = 500;
    const prevVip = user.vipLevel;
    const spend = applyCoinSpend(user, COST);
    if (!spend.ok) {
      res.status(400).json({ error: spend.error });
      return;
    }
    // Remove from old family if any
    if (user.familyId && db.families[user.familyId]) {
      db.families[user.familyId].memberIds = db.families[user.familyId].memberIds.filter((id) => id !== user.id);
    }
    const famId = `fam_${Date.now().toString(36)}`;
    const family: FamilyGroup = {
      id: famId,
      name,
      crest,
      motto: motto || 'United for victory and fun.',
      level: 1,
      totalCp: 500,
      activityScore: 100,
      barrierUntil: 0,
      leaderId: user.id,
      leaderName: user.name,
      memberIds: [user.id],
      maxMembers: 50,
    };
    db.families[famId] = family;
    user.familyId = famId;
    user.familyActivityPoints += 100;
    saveDatabase(db);
    res.json({
      user,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
      vipLeveledUp: user.vipLevel > prevVip,
    });
  });

  app.post('/api/families/:id/join', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const family = db.families[req.params.id];
    if (!family) {
      res.status(404).json({ error: 'Family not found.' });
      return;
    }
    if (user.familyId === family.id) {
      family.memberIds = family.memberIds.filter((id) => id !== user.id);
      user.familyId = null;
    } else {
      if (user.familyId && db.families[user.familyId]) {
        db.families[user.familyId].memberIds = db.families[user.familyId].memberIds.filter((id) => id !== user.id);
      }
      if (!family.memberIds.includes(user.id)) {
        family.memberIds.push(user.id);
      }
      user.familyId = family.id;
    }
    saveDatabase(db);
    res.json({
      user,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
    });
  });

  app.post('/api/families/:id/contribute', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const family = db.families[req.params.id];
    if (!family) {
      res.status(404).json({ error: 'Family not found.' });
      return;
    }
    const coins = Number(req.body?.coins || 50);
    const spend = applyCoinSpend(user, coins);
    if (!spend.ok) {
      res.status(400).json({ error: spend.error });
      return;
    }
    const cpGain = coins * 2;
    family.totalCp += cpGain;
    family.activityScore += cpGain;
    family.level = Math.max(1, Math.floor(family.totalCp / 2500) + 1);
    user.cpPoints += cpGain;
    user.familyActivityPoints += cpGain;
    saveDatabase(db);
    res.json({
      user,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
    });
  });

  // ---- DISCOVER: CP VIRTUAL GIFTING, FAMILY INTERACTIONS, CHESTS & SPIN WHEEL GACHA ----
  app.post('/api/discover/cp-gift', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const friendId = String(req.body?.friendId || '');
    const giftId = String(req.body?.giftId || '');
    const target = db.users[friendId];
    const gift = GIFT_CATALOG.find((g) => g.id === giftId);
    if (!target || target.id === user.id) {
      res.status(400).json({ error: 'Select a valid friend to send a gift.' });
      return;
    }
    if (!gift) {
      res.status(400).json({ error: 'Gift not found.' });
      return;
    }
    const prevVip = user.vipLevel;
    const spend = applyCoinSpend(user, gift.coins);
    if (!spend.ok) {
      res.status(400).json({ error: spend.error });
      return;
    }
    const charmGain = computeGiftCharm(gift.coins);
    const coinReturn = gift.coinReturn || 0;
    user.coins += coinReturn;
    user.cpPoints += gift.cpReward;
    user.charmPoints += charmGain;
    user.familyActivityPoints += gift.coins;
    target.cpPoints += gift.cpReward;
    target.charmPoints += charmGain;

    if (user.familyId && db.families[user.familyId]) {
      const myFam = db.families[user.familyId];
      myFam.activityScore += gift.coins;
      myFam.totalCp += Math.round(gift.cpReward * 0.5);
      myFam.level = Math.max(1, Math.floor(myFam.totalCp / 2500) + 1);
    }

    const progress = db.userTaskProgress[user.id] || { games: 0, gifts: 0, posts: 0 };
    progress.gifts += 1;
    db.userTaskProgress[user.id] = progress;
    saveDatabase(db);

    res.json({
      user,
      friends: getFriendsList(user),
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
      taskProgress: getTaskProgress(user),
      cpEarned: gift.cpReward,
      charmEarned: charmGain,
      coinReturn,
      gift,
      vipLeveledUp: user.vipLevel > prevVip,
    });
  });

  app.post('/api/families/:id/add-member', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const family = db.families[req.params.id];
    const friendId = String(req.body?.friendId || '');
    const target = db.users[friendId];
    if (!family) {
      res.status(404).json({ error: 'Family not found.' });
      return;
    }
    if (user.familyId !== family.id) {
      res.status(400).json({ error: 'Join this family first to add members.' });
      return;
    }
    if (!target || target.id === user.id) {
      res.status(400).json({ error: 'Select a valid friend to add.' });
      return;
    }
    if (family.memberIds.includes(target.id)) {
      res.status(400).json({ error: `${target.name} is already a member of ${family.name}.` });
      return;
    }
    if (family.memberIds.length >= family.maxMembers) {
      res.status(400).json({ error: 'This family is already at full capacity.' });
      return;
    }
    if (target.familyId && db.families[target.familyId]) {
      db.families[target.familyId].memberIds = db.families[target.familyId].memberIds.filter(
        (id) => id !== target.id
      );
    }
    family.memberIds.push(target.id);
    target.familyId = family.id;
    user.familyActivityPoints += 30;
    family.activityScore += 30;
    saveDatabase(db);
    res.json({
      user,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
      friends: getFriendsList(user),
      addedName: target.name,
    });
  });

  app.post('/api/families/:id/barrier', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const family = db.families[req.params.id];
    if (!family) {
      res.status(404).json({ error: 'Family not found.' });
      return;
    }
    if (user.familyId !== family.id) {
      res.status(400).json({ error: 'Join this family to activate its Barrier shield.' });
      return;
    }
    const BARRIER_COST = 80;
    const spend = applyCoinSpend(user, BARRIER_COST);
    if (!spend.ok) {
      res.status(400).json({ error: spend.error });
      return;
    }
    family.barrierUntil = Date.now() + 2 * 60 * 60 * 1000;
    family.activityScore += 40;
    user.familyActivityPoints += 40;
    user.cpPoints += 40;
    saveDatabase(db);
    res.json({
      user,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
    });
  });

  app.post('/api/families/:id/steal', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const targetFamily = db.families[req.params.id];
    if (!targetFamily) {
      res.status(404).json({ error: 'Target family not found.' });
      return;
    }
    if (user.familyId === targetFamily.id) {
      res.status(400).json({ error: 'You cannot steal CP from your own family.' });
      return;
    }
    if (targetFamily.barrierUntil > Date.now()) {
      targetFamily.barrierUntil = 0;
      user.familyActivityPoints += 15;
      saveDatabase(db);
      res.json({
        blocked: true,
        stolenCp: 0,
        message: `Blocked! ${targetFamily.name}'s Barrier absorbed your raid and cracked.`,
        user,
        families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
      });
      return;
    }
    const stolenCp = Math.min(180, Math.max(40, Math.round(targetFamily.totalCp * 0.05)));
    targetFamily.totalCp = Math.max(0, targetFamily.totalCp - stolenCp);
    user.cpPoints += stolenCp;
    user.familyActivityPoints += 60;
    if (user.familyId && db.families[user.familyId]) {
      const myFam = db.families[user.familyId];
      myFam.totalCp += stolenCp;
      myFam.activityScore += 60;
      myFam.level = Math.max(1, Math.floor(myFam.totalCp / 2500) + 1);
    }
    saveDatabase(db);
    res.json({
      blocked: false,
      stolenCp,
      message: `Raid successful! Stole +${stolenCp} CP from ${targetFamily.name}!`,
      user,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
    });
  });

  app.post('/api/families/claim-chest', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const chestId = String(req.body?.chestId || '');
    const chest = ACTIVITY_CHESTS.find((c) => c.id === chestId);
    if (!chest) {
      res.status(404).json({ error: 'Activity chest not found.' });
      return;
    }
    if (user.claimedChests.includes(chestId)) {
      res.status(400).json({ error: `${chest.name} has already been claimed.` });
      return;
    }
    if (user.familyActivityPoints < chest.requiredPoints) {
      res.status(400).json({
        error: `Need ${chest.requiredPoints.toLocaleString()} activity points to open ${chest.name}.`,
      });
      return;
    }
    user.claimedChests.push(chestId);
    user.coins += chest.rewardCoins;
    user.cpPoints += chest.rewardCp;
    saveDatabase(db);
    res.json({ user, chest });
  });

  app.post('/api/gacha/spin', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const today = new Date().toISOString().slice(0, 10);
    const isFree = user.lastGachaFreeDate !== today;
    const prevVip = user.vipLevel;
    if (isFree) {
      user.lastGachaFreeDate = today;
    } else {
      const spend = applyCoinSpend(user, 100);
      if (!spend.ok) {
        res.status(400).json({ error: spend.error });
        return;
      }
    }

    const totalWeight = GACHA_REWARDS.reduce((acc, r) => acc + r.weight, 0);
    let roll = Math.random() * totalWeight;
    let rewardIndex = 0;
    for (let i = 0; i < GACHA_REWARDS.length; i++) {
      roll -= GACHA_REWARDS[i].weight;
      if (roll <= 0) {
        rewardIndex = i;
        break;
      }
    }
    const reward = GACHA_REWARDS[rewardIndex];
    user.coins += reward.coinsBonus;
    user.cpPoints += reward.cpBonus;
    user.familyActivityPoints += 50;
    if (user.familyId && db.families[user.familyId]) {
      db.families[user.familyId].activityScore += 50;
    }

    if (reward.unlockShopId && reward.unlockCategory === 'chat_effect') {
      if (!user.ownedChatEffects.includes(reward.unlockShopId)) {
        user.ownedChatEffects.push(reward.unlockShopId);
      }
    }
    if (reward.unlockShopId && reward.unlockCategory === 'entry_ride') {
      if (!user.ownedEntryEffects.includes(reward.unlockShopId)) {
        user.ownedEntryEffects.push(reward.unlockShopId);
      }
    }

    const wonItem: GachaWonItem = {
      id: `gitem_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
      rewardId: reward.id,
      name: reward.name,
      rarity: reward.rarity,
      icon: reward.icon,
      acquiredAt: Date.now(),
    };
    user.gachaInventory = [wonItem, ...(user.gachaInventory || [])].slice(0, 40);
    saveDatabase(db);

    res.json({
      user,
      reward,
      rewardIndex,
      usedFreeSpin: isFree,
      families: Object.values(db.families).sort((a, b) => b.totalCp - a.totalCp),
      vipLeveledUp: user.vipLevel > prevVip,
    });
  });

  // ---- DIRECT FRIEND CHAT ----
  app.get('/api/chats/:friendId', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const friendId = String(req.params.friendId || '');
    if (!db.users[friendId]) {
      res.status(404).json({ error: 'Player not found.' });
      return;
    }
    const key = getDmThreadKey(user.id, friendId);
    const messages = db.directMessages[key] || [];
    res.json({ messages });
  });

  app.post('/api/chats/:friendId', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const friendId = String(req.params.friendId || '');
    if (!db.users[friendId]) {
      res.status(404).json({ error: 'Player not found.' });
      return;
    }
    const text = String(req.body?.text || '').trim().slice(0, 400);
    if (!text) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }
    const key = getDmThreadKey(user.id, friendId);
    const message: DirectMessage = {
      id: `dm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      fromId: user.id,
      toId: friendId,
      text,
      timestamp: Date.now(),
    };
    db.directMessages[key] = [...(db.directMessages[key] || []), message].slice(-120);
    saveDatabase(db);
    sendToUser(friendId, 'dm:message', message);
    res.json({ message, messages: db.directMessages[key] });
  });

  // ---- ROOM INVITATIONS ----
  app.post('/api/rooms/:roomId/invite', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const room = db.rooms[req.params.roomId];
    const friendId = String(req.body?.friendId || '');
    const customMsg = String(req.body?.message || '').trim().slice(0, 140);
    const target = db.users[friendId];

    if (!room) {
      res.status(404).json({ error: 'Voice room not found.' });
      return;
    }
    if (!target || target.id === user.id) {
      res.status(400).json({ error: 'Select a valid friend to invite.' });
      return;
    }

    const invitation: RoomInvitation = {
      id: `inv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      roomId: room.id,
      roomTitle: room.title,
      roomType: room.roomType || 'Normal',
      roomLevel: room.level,
      fromId: user.id,
      fromName: user.name,
      fromDp: user.dp,
      fromVipLevel: user.vipLevel,
      toId: target.id,
      message: customMsg || `Join me in ${room.title}!`,
      status: 'pending',
      createdAt: Date.now(),
    };
    db.roomInvitations.unshift(invitation);
    db.roomInvitations = db.roomInvitations.slice(0, 150);
    saveDatabase(db);
    sendToUser(target.id, 'room:invitation', invitation);
    res.json({ ok: true, invitation });
  });

  app.post('/api/invitations/:id/respond', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const inv = db.roomInvitations.find((i) => i.id === req.params.id && i.toId === user.id);
    if (!inv) {
      res.status(404).json({ error: 'Invitation not found.' });
      return;
    }
    const action = req.body?.action === 'accept' ? 'accepted' : 'declined';
    inv.status = action;
    saveDatabase(db);
    res.json({
      invitation: inv,
      invitations: db.roomInvitations
        .filter((i) => i.toId === user.id)
        .sort((a, b) => b.createdAt - a.createdAt),
    });
  });

  // Vite middleware in dev, static dist in production
  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`JoyPlay server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
