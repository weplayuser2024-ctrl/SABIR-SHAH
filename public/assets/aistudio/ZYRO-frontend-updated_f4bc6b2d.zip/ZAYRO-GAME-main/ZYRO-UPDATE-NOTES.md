# ZYRO frontend update

This archive is an incremental update of the supplied ZAYRO-GAME project.

## Included in this update
- Official product branding changed to ZYRO in the loading state and browser title.
- Voice room types now include Normal, YouTube Room, Game Room, and Official Zyro.
- Removed Action Room and replaced the former Video Room stage with a YouTube watch panel.
- YouTube panel accepts standard YouTube watch, youtu.be, embed, and Shorts URLs and embeds the video with youtube-nocookie.
- Voice room seat model expanded to 13 positions: owner position plus 12 speaker positions; existing saved rooms are extended on load.
- Charm ranking is selected by default in the ranking modal.
- Top-up package labels changed from USD to INR examples.

## Important integration notes
This is still a frontend/demo project with its own `server.ts` mock application backend. It is not yet connected to the separate Termux Express/PostgreSQL API described in the chat.
The existing microphone code captures a local microphone and detects speech; it does not yet relay audio between users. Real multi-user voice requires WebRTC plus a signaling/media service (for example an SFU).
The YouTube embed is a shared UI surface only; synchronized playback controls require room WebSocket events.
QR/UPI payment verification, monthly ₹200 VIP billing, growth/EXP accounting, charm ledger, admin authorization, wedding/ring purchases, and database persistence must be implemented server-side before real money or production use. Do not credit coins based only on a client-side payment-success screen.
