import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ClipboardCheck,
  Coins,
  Compass,
  Crown,
  Gamepad2,
  MessageSquare,
  Mic,
  Plus,
  Star,
  Trophy,
  User,
  Users,
} from 'lucide-react';
import {
  DirectMessage,
  FamilyGroup,
  FeedPost,
  GiftItem,
  PublicFriend,
  RoomInvitation,
  RoomMessage,
  UserProfile,
  VoiceRoom,
} from './shared/types';
import { AuthScreen } from './components/AuthScreen';
import { AvatarBadge } from './components/AvatarBadge';
import { EntryTrigger, VipEntryAnimation } from './components/VipEntryAnimation';
import {
  EventsModal,
  FriendsModal,
  RankingsModal,
  TasksModal,
  TopUpModal,
} from './components/PlayOverlays';
import { CarromGame } from './components/games/CarromGame';
import { UnoGame } from './components/games/UnoGame';
import { MicGame } from './components/games/MicGame';
import { SpyGame } from './components/games/SpyGame';
import { VoiceRoomTab } from './components/VoiceRoomTab';
import { DiscoverTab } from './components/DiscoverTab';
import { MeTab } from './components/MeTab';
import { ChatTab } from './components/ChatTab';

type MainTab = 'play' | 'voice' | 'chat' | 'discover' | 'me';
type ActiveGame = 'carrom' | 'uno' | 'mic' | 'spy' | null;

interface FloatingEmote {
  id: string;
  seatIndex: number;
  userName: string;
  emoji: string;
}

interface GiftBanner {
  id: string;
  senderName: string;
  senderDp: string;
  recipientName: string;
  gift: GiftItem;
  roomLeveledUp: boolean;
  newRoomLevel: number;
}

export default function App() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('joyplay_token'));
  const [user, setUser] = useState<UserProfile | null>(null);
  const [bootLoading, setBootLoading] = useState<boolean>(Boolean(localStorage.getItem('joyplay_token')));
  const [activeTab, setActiveTab] = useState<MainTab>('play');

  // World data
  const [rooms, setRooms] = useState<VoiceRoom[]>([]);
  const [friends, setFriends] = useState<PublicFriend[]>([]);
  const [families, setFamilies] = useState<FamilyGroup[]>([]);
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [rankings, setRankings] = useState<{
    wealth: { rank: number; id: string; name: string; dp: string; vipLevel: number; score: number }[];
    charm: { rank: number; id: string; name: string; dp: string; vipLevel: number; score: number }[];
    wins: { rank: number; id: string; name: string; dp: string; vipLevel: number; score: number }[];
  }>({ wealth: [], charm: [], wins: [] });
  const [taskProgress, setTaskProgress] = useState<Record<string, number>>({});

  // Play screen overlays & games
  const [showTopUp, setShowTopUp] = useState(false);
  const [showEvents, setShowEvents] = useState(false);
  const [showRankings, setShowRankings] = useState(false);
  const [showTasks, setShowTasks] = useState(false);
  const [showFriends, setShowFriends] = useState(false);
  const [activeGame, setActiveGame] = useState<ActiveGame>(null);

  // Voice Room Live WebSocket State
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [activeRoom, setActiveRoom] = useState<VoiceRoom | null>(null);
  const [roomMessages, setRoomMessages] = useState<RoomMessage[]>([]);
  const [floatingEmotes, setFloatingEmotes] = useState<FloatingEmote[]>([]);
  const [giftBanner, setGiftBanner] = useState<GiftBanner | null>(null);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [entryTrigger, setEntryTrigger] = useState<EntryTrigger | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [invitations, setInvitations] = useState<RoomInvitation[]>([]);
  const [chatPreviews, setChatPreviews] = useState<Record<string, DirectMessage | null>>({});
  const [chatTargetFriendId, setChatTargetFriendId] = useState<string | null>(null);
  const [incomingDm, setIncomingDm] = useState<DirectMessage | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const activeRoomIdRef = useRef<string | null>(null);

  useEffect(() => {
    activeRoomIdRef.current = activeRoomId;
  }, [activeRoomId]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((curr) => (curr === msg ? null : curr));
    }, 3500);
  }, []);

  const authHeaders = useCallback(
    () => ({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token || ''}`,
    }),
    [token]
  );

  // Bootstrap initial user + world state
  const fetchBootstrap = useCallback(async (sessionToken: string) => {
    setBootLoading(true);
    try {
      const res = await fetch('/api/bootstrap', {
        headers: { Authorization: `Bearer ${sessionToken}` },
      });
      if (!res.ok) {
        localStorage.removeItem('joyplay_token');
        setToken(null);
        setUser(null);
        return;
      }
      const data = await res.json();
      setUser(data.user);
      setRooms(data.rooms || []);
      setFriends(data.friends || []);
      setFamilies(data.families || []);
      setPosts(data.posts || []);
      setRankings(data.rankings || { wealth: [], charm: [], wins: [] });
      setTaskProgress(data.taskProgress || {});
      setInvitations(data.invitations || []);
      setChatPreviews(data.chatPreviews || {});
    } catch {
      // Keep UI responsive
    } finally {
      setBootLoading(false);
    }
  }, []);

  useEffect(() => {
    if (token) {
      fetchBootstrap(token);
    }
  }, [token, fetchBootstrap]);

  // Connect WebSocket when authenticated
  useEffect(() => {
    if (!token) return;
    let closedByCleanup = false;
    let reconnectTimer: number | null = null;

    const connect = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws?token=${encodeURIComponent(token)}`);
      wsRef.current = ws;

      ws.onopen = () => {
        if (activeRoomIdRef.current) {
          ws.send(JSON.stringify({ event: 'room:join', payload: { roomId: activeRoomIdRef.current } }));
        }
      };

      ws.onmessage = (evt) => {
        try {
          const parsed = JSON.parse(String(evt.data)) as { event: string; payload: Record<string, unknown> };
          if (parsed.event === 'rooms:list') {
            setRooms(parsed.payload as unknown as VoiceRoom[]);
          }
          if (parsed.event === 'room:init') {
            const p = parsed.payload as { room: VoiceRoom; messages: RoomMessage[] };
            setActiveRoom(p.room);
            setRoomMessages(p.messages || []);
            setRoomError(null);
          }
          if (parsed.event === 'room:state') {
            setActiveRoom(parsed.payload as unknown as VoiceRoom);
          }
          if (parsed.event === 'room:message') {
            const msg = parsed.payload as unknown as RoomMessage;
            setRoomMessages((prev) => (prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]));
          }
          if (parsed.event === 'room:entry_animation') {
            const p = parsed.payload as {
              userName: string;
              userDp: string;
              vipLevel: number;
              equippedEntryEffect: string;
              message: RoomMessage;
            };
            setRoomMessages((prev) =>
              prev.some((m) => m.id === p.message.id) ? prev : [...prev, p.message]
            );
            setEntryTrigger({
              id: `ent_${Date.now()}`,
              userName: p.userName,
              userDp: p.userDp,
              vipLevel: p.vipLevel,
              equippedEntryEffect: p.equippedEntryEffect,
            });
          }
          if (parsed.event === 'room:emote') {
            const em = parsed.payload as unknown as FloatingEmote;
            setFloatingEmotes((prev) => [...prev, em]);
            setTimeout(() => {
              setFloatingEmotes((prev) => prev.filter((item) => item.id !== em.id));
            }, 2200);
          }
          if (parsed.event === 'room:gift_event') {
            const p = parsed.payload as {
              gift: GiftItem;
              senderName: string;
              senderDp: string;
              recipientName: string;
              roomLeveledUp: boolean;
              newRoomLevel: number;
              message: RoomMessage;
            };
            setRoomMessages((prev) =>
              prev.some((m) => m.id === p.message.id) ? prev : [...prev, p.message]
            );
            const bannerId = `gb_${Date.now()}`;
            setGiftBanner({
              id: bannerId,
              gift: p.gift,
              senderName: p.senderName,
              senderDp: p.senderDp,
              recipientName: p.recipientName,
              roomLeveledUp: p.roomLeveledUp,
              newRoomLevel: p.newRoomLevel,
            });
            setTimeout(() => {
              setGiftBanner((curr) => (curr?.id === bannerId ? null : curr));
            }, 3400);
          }
          if (parsed.event === 'user:updated') {
            const p = parsed.payload as {
              user: UserProfile;
              vipLeveledUp?: boolean;
              charmEarned?: number;
              coinReturn?: number;
            };
            setUser(p.user);
            if (p.vipLeveledUp) {
              showToast(`VIP Level Up! You reached VIP ${p.user.vipLevel}!`);
            } else if (p.charmEarned && p.charmEarned > 0) {
              const returnPart = p.coinReturn && p.coinReturn > 0 ? ` · +${p.coinReturn.toLocaleString()} Return Coins` : '';
              showToast(`Gift sent! +${p.charmEarned} Charm${returnPart}`);
            }
          }
          if (parsed.event === 'room:error') {
            const err = String(parsed.payload?.error || 'Room action failed.');
            setRoomError(err);
            setTimeout(() => setRoomError(null), 3500);
          }
          if (parsed.event === 'dm:message') {
            const dm = parsed.payload as unknown as DirectMessage;
            setIncomingDm(dm);
            setChatPreviews((prev) => ({ ...prev, [dm.fromId]: dm }));
          }
          if (parsed.event === 'room:invitation') {
            const inv = parsed.payload as unknown as RoomInvitation;
            setInvitations((prev) => (prev.some((i) => i.id === inv.id) ? prev : [inv, ...prev]));
            showToast(`${inv.fromName} invited you to ${inv.roomTitle}!`);
          }
        } catch {
          // Ignore malformed frame
        }
      };

      ws.onclose = () => {
        if (!closedByCleanup) {
          reconnectTimer = window.setTimeout(connect, 2000);
        }
      };
    };

    connect();
    return () => {
      closedByCleanup = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [token, showToast]);

  const sendWs = (event: string, payload?: Record<string, unknown>) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ event, payload }));
    }
  };

  const handleJoinRoom = (roomId: string) => {
    setActiveRoomId(roomId);
    setActiveTab('voice');
    sendWs('room:join', { roomId });
  };

  const handleLeaveRoom = () => {
    sendWs('room:leave');
    setActiveRoomId(null);
    setActiveRoom(null);
    setRoomMessages([]);
  };

  const handleOpenChat = (friendId?: string) => {
    setChatTargetFriendId(friendId || null);
    setActiveTab('chat');
  };

  const handleGameComplete = async (won: boolean) => {
    if (!token) return;
    try {
      const res = await fetch('/api/games/reward', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ won }),
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data.user);
        setTaskProgress(data.taskProgress);
        setRankings(data.rankings);
        showToast(`+${data.coinsReward} Coins & +${data.cpReward} CP earned!`);
      }
    } catch {
      // Ignore
    }
  };

  const handleLogout = async () => {
    if (token) {
      await fetch('/api/auth/logout', { method: 'POST', headers: authHeaders() }).catch(() => {});
    }
    localStorage.removeItem('joyplay_token');
    setToken(null);
    setUser(null);
    setActiveRoomId(null);
    setActiveRoom(null);
  };

  if (!token || (!user && !bootLoading)) {
    return (
      <AuthScreen
        onAuthenticated={(newToken, newUser) => {
          localStorage.setItem('joyplay_token', newToken);
          setToken(newToken);
          setUser(newUser);
        }}
      />
    );
  }

  if (bootLoading || !user) {
    return (
      <div className="min-h-screen bg-[#F4F6FB] flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-display font-extrabold text-xl flex items-center justify-center mx-auto animate-pulse">
            J
          </div>
          <div className="text-sm font-semibold text-slate-600">Loading your ZYRO lobby...</div>
        </div>
      </div>
    );
  }

  const onlineFriendsCount = friends.filter((f) => f.isOnline).length;

  const GAME_CARDS = [
    {
      id: 'carrom' as const,
      title: 'Carrom',
      subtitle: 'Strike & pocket the Queen',
      meta: 'Board · 1v1',
      image: '/src/assets/images/game_carrom_cover_1794694356725.jpg',
      accent: 'from-amber-600 to-orange-600',
    },
    {
      id: 'uno' as const,
      title: 'Uno',
      subtitle: 'Classic +4 & Wild showdown',
      meta: 'Cards · 3 Players',
      image: '/src/assets/images/game_uno_cover_1794694357332.jpg',
      accent: 'from-emerald-600 to-teal-600',
    },
    {
      id: 'mic' as const,
      title: 'Star Mic',
      subtitle: 'Singing & rhythm stage',
      meta: 'Voice · Live Mic',
      image: '/src/assets/images/game_mic_cover_1794694356739.jpg',
      accent: 'from-violet-600 to-indigo-600',
    },
    {
      id: 'spy' as const,
      title: 'Who’s the Spy',
      subtitle: 'Clues, bluffing & voting',
      meta: 'Party · 4 Players',
      image: '/src/assets/images/game_spy_cover_1794694356919.jpg',
      accent: 'from-slate-800 to-indigo-900',
    },
  ];

  return (
    <div className="min-h-screen bg-[#F4F6FB] text-slate-900">
      {/* Global VIP Entry Animation Overlay */}
      <VipEntryAnimation trigger={entryTrigger} onComplete={() => setEntryTrigger(null)} />

      {/* Global Toast Notification */}
      {toastMsg && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 rounded-2xl bg-slate-900 text-white px-5 py-2.5 text-xs font-semibold shadow-xl border border-white/15">
          {toastMsg}
        </div>
      )}

      {/* MAIN PLAY TAB */}
      {activeTab === 'play' && (
        <main className="max-w-5xl mx-auto px-4 pt-4 pb-28">
          {/* Top Spatial Row: Top-Left (ID + Coins + Top Up) & Top-Right (Star Events + 3 icons stacked below) */}
          <div className="flex items-start justify-between gap-4">
            {/* Top-Left Corner: Coin Balance + Plus Top Up Option */}
            <div className="inline-flex items-center gap-2 bg-white rounded-2xl border border-slate-200 pl-3.5 pr-1.5 py-1.5 shadow-sm">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                  <Coins className="w-4 h-4" />
                </div>
                <span className="font-mono-num text-sm sm:text-base font-extrabold text-slate-900 pr-1">
                  {user.coins.toLocaleString()}
                </span>
              </div>
              <button
                onClick={() => setShowTopUp(true)}
                aria-label="Top Up Coins"
                title="Top Up Coins"
                className="w-9 h-9 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center justify-center shadow-xs transition-colors shrink-0"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            {/* Top-Right Corner: Star Icon for Events */}
            <div className="flex items-center shrink-0">
              <button
                onClick={() => setShowEvents(true)}
                aria-label="Events"
                className="h-11 px-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 hover:brightness-105 text-slate-950 font-bold text-xs shadow-sm flex items-center gap-1.5"
              >
                <Star className="w-4 h-4 fill-slate-950" />
                <span>Events</span>
              </button>
            </div>
          </div>

          {/* Rankings, Tasks, and Friends Action Bar */}
          <div className="mt-5 grid grid-cols-3 gap-3 max-w-2xl">
            <button
              onClick={() => setShowRankings(true)}
              aria-label="Rankings"
              className="bg-white hover:bg-amber-50/60 rounded-2xl border border-slate-200 hover:border-amber-300 p-3 sm:p-4 shadow-sm transition-all flex items-center gap-3 text-left min-w-0"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                <Trophy className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="font-display text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                  Rankings
                </div>
                <div className="text-[11px] text-slate-500 truncate hidden sm:block">
                  Top Players
                </div>
              </div>
            </button>

            <button
              onClick={() => setShowTasks(true)}
              aria-label="Tasks"
              className="bg-white hover:bg-indigo-50/60 rounded-2xl border border-slate-200 hover:border-indigo-300 p-3 sm:p-4 shadow-sm transition-all flex items-center gap-3 text-left min-w-0"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
                <ClipboardCheck className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="font-display text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                  Tasks
                </div>
                <div className="text-[11px] text-slate-500 truncate hidden sm:block">
                  Daily Rewards
                </div>
              </div>
            </button>

            <button
              onClick={() => setShowFriends(true)}
              aria-label="Online Friends"
              className="bg-white hover:bg-emerald-50/60 rounded-2xl border border-slate-200 hover:border-emerald-300 p-3 sm:p-4 shadow-sm transition-all flex items-center gap-3 text-left min-w-0"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="font-display text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                  Friends
                </div>
                <div className="text-[11px] text-slate-500 truncate hidden sm:block">
                  {onlineFriendsCount} Online
                </div>
              </div>
            </button>
          </div>

          {/* Further Down: 4 Featured Games Grid (2 rows x 2 items) */}
          <section className="mt-5">
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="font-display text-base sm:text-lg font-bold text-slate-900">Party Games</h2>
              <span className="text-xs text-slate-500">Win matches to earn Coins & CP</span>
            </div>

            <div className="grid grid-cols-2 gap-3 max-w-2xl">
              {GAME_CARDS.map((game) => (
                <button
                  key={game.id}
                  onClick={() => setActiveGame(game.id)}
                  className="group text-left bg-white rounded-2xl border border-slate-200 p-2.5 sm:p-3 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all flex items-center gap-3 min-w-0"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden bg-slate-100 shrink-0">
                    <img
                      src={game.image}
                      alt={game.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-between gap-1">
                    <div>
                      <h3 className="font-display text-sm sm:text-base font-extrabold text-slate-900 truncate">
                        {game.title}
                      </h3>
                      <div className="text-[11px] text-slate-500 truncate">{game.meta}</div>
                    </div>
                    <div className="flex items-center justify-between gap-2 pt-0.5">
                      <span className={`px-2.5 py-1 rounded-lg bg-gradient-to-r ${game.accent} text-white text-[11px] font-bold whitespace-nowrap`}>
                        Play
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Live Voice Rooms Strip Below Games */}
          <section className="mt-7">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-display text-lg font-bold text-slate-900">Hot Voice Rooms</h2>
              <button
                onClick={() => setActiveTab('voice')}
                className="text-xs font-semibold text-indigo-600 hover:underline"
              >
                See All Rooms
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {rooms.slice(0, 3).map((room) => (
                <button
                  key={room.id}
                  onClick={() => handleJoinRoom(room.id)}
                  className="text-left bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:border-indigo-300 transition-colors flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <AvatarBadge dp={room.ownerDp} name={room.ownerName} vipLevel={room.ownerVipLevel} size="md" />
                    <div className="min-w-0">
                      <div className="font-display font-bold text-sm text-slate-900 truncate">{room.title}</div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        {room.category} · Lv.{room.level} · {room.seats.filter((s) => s.userId).length}/10 Seated
                      </div>
                    </div>
                  </div>
                  <span className="px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 text-xs font-bold shrink-0">
                    Join
                  </span>
                </button>
              ))}
            </div>
          </section>
        </main>
      )}

      {/* VOICE ROOM TAB */}
      {activeTab === 'voice' && (
        <VoiceRoomTab
          user={user}
          rooms={rooms}
          friends={friends}
          activeRoomId={activeRoomId}
          activeRoom={activeRoom}
          roomMessages={roomMessages}
          floatingEmotes={floatingEmotes}
          giftBanner={giftBanner}
          roomError={roomError}
          onJoinRoom={handleJoinRoom}
          onLeaveRoom={handleLeaveRoom}
          onCreateRoom={async (title, category) => {
            const res = await fetch('/api/rooms', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ title, category, roomType: 'Normal' }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not create room.';
            setUser(data.user);
            handleJoinRoom(data.room.id);
            return null;
          }}
          onChangeRoomType={(roomType) => sendWs('room:change_type', { roomType })}
          onInviteFriend={async (roomId, friendId) => {
            const res = await fetch(`/api/rooms/${encodeURIComponent(roomId)}/invite`, {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ friendId }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not send invitation.';
            showToast('Room invitation sent!');
            return null;
          }}
          onTakeSeat={(seatIndex) => sendWs('room:seat_take', { seatIndex })}
          onLeaveSeat={() => sendWs('room:seat_leave')}
          onToggleMute={() => sendWs('room:toggle_mute')}
          onSetSpeaking={(isSpeaking) => sendWs('room:speaking', { isSpeaking })}
          onSendChat={(text) => sendWs('room:chat', { text })}
          onSendEmote={(emoji) => sendWs('room:emote', { emoji })}
          onSendGift={(giftId, recipientId) => sendWs('room:gift', { giftId, recipientId })}
          onOpenTopUp={() => setShowTopUp(true)}
        />
      )}

      {/* CHAT TAB */}
      {activeTab === 'chat' && (
        <ChatTab
          user={user}
          friends={friends}
          invitations={invitations}
          chatPreviews={chatPreviews}
          initialFriendId={chatTargetFriendId}
          incomingDm={incomingDm}
          authHeaders={authHeaders}
          onJoinRoom={handleJoinRoom}
          onRespondInvitation={async (invitationId, action, roomId) => {
            const res = await fetch(`/api/invitations/${encodeURIComponent(invitationId)}/respond`, {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ action }),
            });
            const data = await res.json();
            if (res.ok && Array.isArray(data.invitations)) {
              setInvitations(data.invitations);
            }
            if (action === 'accept' && roomId) {
              handleJoinRoom(roomId);
            }
          }}
          onUpdatePreview={(friendId, message) => {
            setChatPreviews((prev) => ({ ...prev, [friendId]: message }));
          }}
        />
      )}

      {/* DISCOVER TAB */}
      {activeTab === 'discover' && (
        <DiscoverTab
          user={user}
          friends={friends}
          posts={posts}
          families={families}
          onCollectDailyCp={async () => {
            const res = await fetch('/api/cp/collect-daily', {
              method: 'POST',
              headers: authHeaders(),
            });
            const data = await res.json();
            if (!res.ok) return { error: data.error || 'Already collected today.' };
            setUser(data.user);
            setTaskProgress(data.taskProgress);
            return { bonusCp: data.bonusCp, bonusCoins: data.bonusCoins };
          }}
          onCreatePost={async (payload) => {
            const res = await fetch('/api/posts', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not publish post.';
            setPosts(data.posts);
            setUser(data.user);
            setTaskProgress(data.taskProgress);
            return null;
          }}
          onLikePost={async (postId) => {
            const res = await fetch(`/api/posts/${postId}/like`, { method: 'POST', headers: authHeaders() });
            const data = await res.json();
            if (res.ok) setPosts(data.posts);
          }}
          onBoostPostCp={async (postId) => {
            const res = await fetch(`/api/posts/${postId}/cp`, { method: 'POST', headers: authHeaders() });
            const data = await res.json();
            if (res.ok) {
              setPosts(data.posts);
              setUser(data.user);
              setTaskProgress(data.taskProgress);
            }
          }}
          onCommentPost={async (postId, text) => {
            const res = await fetch(`/api/posts/${postId}/comment`, {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ text }),
            });
            const data = await res.json();
            if (res.ok) setPosts(data.posts);
          }}
          onSendCpGift={async (friendId, giftId) => {
            const res = await fetch('/api/discover/cp-gift', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ friendId, giftId }),
            });
            const data = await res.json();
            if (!res.ok) return { error: data.error || 'Could not send gift.' };
            setUser(data.user);
            setFriends(data.friends);
            setFamilies(data.families);
            setTaskProgress(data.taskProgress);
            if (data.vipLeveledUp) showToast(`VIP Level Up! You reached VIP ${data.user.vipLevel}!`);
            const recipient = friends.find((f) => f.id === friendId);
            return {
              cpEarned: data.cpEarned,
              charmEarned: data.charmEarned ?? 0,
              coinReturn: data.coinReturn ?? 0,
              giftName: data.gift?.name || 'Gift',
              friendName: recipient?.name || 'Friend',
            };
          }}
          onJoinFamily={async (familyId) => {
            const res = await fetch(`/api/families/${familyId}/join`, {
              method: 'POST',
              headers: authHeaders(),
            });
            const data = await res.json();
            if (res.ok) {
              setUser(data.user);
              setFamilies(data.families);
            }
          }}
          onCreateFamily={async (name, motto, crest) => {
            const res = await fetch('/api/families/create', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ name, motto, crest }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not create family.';
            setUser(data.user);
            setFamilies(data.families);
            if (data.vipLeveledUp) showToast(`VIP Level Up! You reached VIP ${data.user.vipLevel}!`);
            return null;
          }}
          onContributeFamily={async (familyId) => {
            const res = await fetch(`/api/families/${familyId}/contribute`, {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ coins: 50 }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Contribution failed.';
            setUser(data.user);
            setFamilies(data.families);
            return null;
          }}
          onAddFamilyMember={async (familyId, friendId) => {
            const res = await fetch(`/api/families/${encodeURIComponent(familyId)}/add-member`, {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ friendId }),
            });
            const data = await res.json();
            if (!res.ok) return { error: data.error || 'Could not add member.' };
            setUser(data.user);
            setFamilies(data.families);
            setFriends(data.friends);
            return { addedName: data.addedName };
          }}
          onActivateBarrier={async (familyId) => {
            const res = await fetch(`/api/families/${encodeURIComponent(familyId)}/barrier`, {
              method: 'POST',
              headers: authHeaders(),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not activate Barrier.';
            setUser(data.user);
            setFamilies(data.families);
            return null;
          }}
          onStealFamily={async (familyId) => {
            const res = await fetch(`/api/families/${encodeURIComponent(familyId)}/steal`, {
              method: 'POST',
              headers: authHeaders(),
            });
            const data = await res.json();
            if (!res.ok) return { error: data.error || 'Raid failed.' };
            setUser(data.user);
            setFamilies(data.families);
            return { blocked: data.blocked, stolenCp: data.stolenCp, message: data.message };
          }}
          onClaimChest={async (chestId) => {
            const res = await fetch('/api/families/claim-chest', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ chestId }),
            });
            const data = await res.json();
            if (!res.ok) return { error: data.error || 'Could not open chest.' };
            setUser(data.user);
            return { chest: data.chest };
          }}
          onSpinGacha={async () => {
            const res = await fetch('/api/gacha/spin', {
              method: 'POST',
              headers: authHeaders(),
            });
            const data = await res.json();
            if (!res.ok) return { error: data.error || 'Spin failed.' };
            setUser(data.user);
            if (data.families) setFamilies(data.families);
            if (data.vipLeveledUp) showToast(`VIP Level Up! You reached VIP ${data.user.vipLevel}!`);
            return {
              reward: data.reward,
              rewardIndex: data.rewardIndex,
              usedFreeSpin: data.usedFreeSpin,
            };
          }}
          onOpenChat={handleOpenChat}
        />
      )}

      {/* ME TAB */}
      {activeTab === 'me' && (
        <MeTab
          user={user}
          onUpdateProfile={async (payload) => {
            const res = await fetch('/api/profile', {
              method: 'PATCH',
              headers: authHeaders(),
              body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Update failed.';
            setUser(data.user);
            return null;
          }}
          onBuyShopItem={async (itemId) => {
            const res = await fetch('/api/shop/buy', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ itemId }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Purchase failed.';
            setUser(data.user);
            if (data.vipLeveledUp) showToast(`VIP Level Up! You reached VIP ${data.user.vipLevel}!`);
            return null;
          }}
          onEquipShopItem={async (type, itemId) => {
            const res = await fetch('/api/shop/equip', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ type, itemId }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not equip item.';
            setUser(data.user);
            return null;
          }}
          onUpgradeVip={async (coins) => {
            const res = await fetch('/api/vip/upgrade', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ coins }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Upgrade failed.';
            setUser(data.user);
            if (data.vipLeveledUp) {
              setEntryTrigger({
                id: `vipup_${Date.now()}`,
                userName: data.user.name,
                userDp: data.user.dp,
                vipLevel: data.user.vipLevel,
                equippedEntryEffect: `vip_${data.user.vipLevel}`,
              });
            }
            return null;
          }}
          onPreviewVipEntry={(vipLevel, customRideId) => {
            setEntryTrigger({
              id: `prev_${Date.now()}`,
              userName: user.name,
              userDp: user.dp,
              vipLevel,
              equippedEntryEffect: customRideId || `vip_${vipLevel}`,
            });
          }}
          onOpenTopUp={() => setShowTopUp(true)}
          onLogout={handleLogout}
        />
      )}

      {/* FIXED BOTTOM 5-TAB NAVIGATION BAR: Play, Voice Room, Chat, Discover, Me */}
      <nav
        aria-label="Primary Bottom Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_20px_rgba(15,23,42,0.06)]"
      >
        <div className="max-w-3xl mx-auto grid grid-cols-5 h-16">
          <button
            onClick={() => setActiveTab('play')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'play' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Gamepad2 className="w-5 h-5" />
            <span className="text-[10px] sm:text-[11px] font-bold whitespace-nowrap">Play</span>
          </button>

          <button
            onClick={() => setActiveTab('voice')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'voice' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Mic className="w-5 h-5" />
            <span className="text-[10px] sm:text-[11px] font-bold whitespace-nowrap">Voice Room</span>
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors relative ${
              activeTab === 'chat' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <div className="relative">
              <MessageSquare className="w-5 h-5" />
              {invitations.some((i) => i.status === 'pending') && (
                <span className="font-mono-num absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                  {invitations.filter((i) => i.status === 'pending').length}
                </span>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold whitespace-nowrap">Chat</span>
          </button>

          <button
            onClick={() => setActiveTab('discover')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'discover' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span className="text-[10px] sm:text-[11px] font-bold whitespace-nowrap">Discover</span>
          </button>

          <button
            onClick={() => setActiveTab('me')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors relative ${
              activeTab === 'me' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <div className="relative">
              <User className="w-5 h-5" />
              {user.vipLevel > 0 && (
                <Crown className="w-3 h-3 text-amber-500 absolute -top-1.5 -right-2" />
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold whitespace-nowrap">Me</span>
          </button>
        </div>
      </nav>

      {/* OVERLAY MODALS */}
      {showTopUp && (
        <TopUpModal
          user={user}
          onClose={() => setShowTopUp(false)}
          onTopUpSuccess={(updatedUser) => setUser(updatedUser)}
        />
      )}

      {showEvents && (
        <EventsModal
          user={user}
          onClose={() => setShowEvents(false)}
          onClaimEvent={async (eventId) => {
            const res = await fetch('/api/events/claim', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ eventId }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not claim event.';
            setUser(data.user);
            return null;
          }}
        />
      )}

      {showRankings && (
        <RankingsModal rankings={rankings} onClose={() => setShowRankings(false)} />
      )}

      {showTasks && (
        <TasksModal
          user={user}
          taskProgress={taskProgress}
          onClose={() => setShowTasks(false)}
          onClaimTask={async (taskId) => {
            const res = await fetch('/api/tasks/claim', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ taskId }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not claim task.';
            setUser(data.user);
            setTaskProgress(data.taskProgress);
            return null;
          }}
        />
      )}

      {showFriends && (
        <FriendsModal
          user={user}
          friends={friends}
          onClose={() => setShowFriends(false)}
          onToggleFriend={async (friendId) => {
            const res = await fetch('/api/friends/toggle', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ friendId }),
            });
            const data = await res.json();
            if (res.ok) {
              setUser(data.user);
              setFriends(data.friends);
            }
          }}
          onSendCp={async (friendId) => {
            const res = await fetch('/api/friends/send-cp', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ friendId }),
            });
            const data = await res.json();
            if (!res.ok) return data.error || 'Could not send CP.';
            setUser(data.user);
            setFriends(data.friends);
            if (data.vipLeveledUp) {
              showToast(`VIP Level Up! You reached VIP ${data.user.vipLevel}!`);
            } else {
              showToast(
                `Quick Gift sent! +${data.charmEarned ?? 4} Charm · +${data.coinReturn ?? 2} Return Coins`
              );
            }
            return null;
          }}
          onJoinRoom={(roomId) => handleJoinRoom(roomId)}
        />
      )}

      {/* PLAYABLE GAME MODALS */}
      {activeGame === 'carrom' && (
        <CarromGame onClose={() => setActiveGame(null)} onGameComplete={handleGameComplete} />
      )}
      {activeGame === 'uno' && (
        <UnoGame playerName={user.name} onClose={() => setActiveGame(null)} onGameComplete={handleGameComplete} />
      )}
      {activeGame === 'mic' && (
        <MicGame onClose={() => setActiveGame(null)} onGameComplete={handleGameComplete} />
      )}
      {activeGame === 'spy' && (
        <SpyGame playerName={user.name} onClose={() => setActiveGame(null)} onGameComplete={handleGameComplete} />
      )}
    </div>
  );
}
