// Lightweight synthesized sound effects via Web Audio API (no external audio file dependencies)
let audioCtx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function playTone(freq: number, duration = 0.12, type: OscillatorType = 'sine', gainVal = 0.08, delay = 0) {
  const ctx = getCtx();
  if (!ctx) return;
  try {
    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(gainVal, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  } catch {
    // Ignore audio errors
  }
}

export function playCoinChime() {
  playTone(987.77, 0.1, 'triangle', 0.09, 0);
  playTone(1318.51, 0.22, 'triangle', 0.09, 0.07);
}

export function playCardSnap() {
  playTone(420, 0.06, 'triangle', 0.06, 0);
}

export function playCarromClack() {
  playTone(210, 0.07, 'square', 0.04, 0);
  playTone(380, 0.05, 'triangle', 0.04, 0.01);
}

export function playVipFanfare(level: number) {
  if (level <= 0) {
    playTone(523.25, 0.15, 'sine', 0.05, 0);
    return;
  }
  const baseNotes = [523.25, 659.25, 783.99, 1046.5];
  baseNotes.forEach((n, i) => {
    playTone(n + level * 12, 0.22, level >= 10 ? 'triangle' : 'sine', 0.07, i * 0.08);
  });
  if (level >= 11) {
    playTone(1318.51, 0.35, 'triangle', 0.08, 0.34);
  }
}
