export type AuthProvider = 'gmail' | 'facebook' | 'phone';

export interface PrivacySettings {
  profileVisibility: 'everyone' | 'friends' | 'private';
  showOnlineStatus: boolean;
  allowRoomInvites: boolean;
  allowFriendRequests: boolean;
  hideWealthLevel: boolean;
}

export interface ParentalControls {
  enabled: boolean;
  pinCode: string;
  dailySpendLimit: number;
  dailySpentToday: number;
  restrictVoiceMic: boolean;
  safeContentFilter: boolean;
  playtimeLimitMinutes: number;
}

export interface UserProfile {
  id: string; // e.g. "8492014"
  authProvider: AuthProvider;
  authIdentifier: string; // email, fb handle, or phone
  name: string;
  bio: string;
  dp: string; // avatar key or data URL
  coins: number;
  totalCoinsSpent: number;
  vipLevel: number; // 0 to 14
  cpPoints: number;
  charmPoints: number;
  winsCount: number;
  equippedChatEffect: string; // effect id
  equippedEntryEffect: string; // 'auto-vip' or specific unlocked vip/shop entry id
  ownedChatEffects: string[];
  ownedEntryEffects: string[];
  familyId: string | null;
  friends: string[]; // friend user IDs
  claimedTasks: string[];
  claimedEvents: string[];
  dailyCheckinStreak: number;
  lastCheckinDate: string | null;
  privacy: PrivacySettings;
  parental: ParentalControls;
  isOnline: boolean;
  currentActivity: string;
  gachaInventory: GachaWonItem[];
  claimedChests: string[];
  lastGachaFreeDate: string | null;
  familyActivityPoints: number;
  idStyle?: 'royal' | 'obsidian' | 'emerald' | 'sunset';
}

export interface GachaWonItem {
  id: string;
  rewardId: string;
  name: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic';
  icon: string;
  acquiredAt: number;
}

export interface PublicFriend {
  id: string;
  name: string;
  dp: string;
  bio: string;
  vipLevel: number;
  cpPoints: number;
  charmPoints: number;
  winsCount: number;
  isOnline: boolean;
  currentActivity: string;
  currentRoomId?: string | null;
  familyName?: string | null;
}

export interface SeatState {
  seatIndex: number; // 0 = owner reserved, 1..9 = open seats
  userId: string | null;
  userName: string | null;
  userDp: string | null;
  vipLevel: number;
  isMuted: boolean;
  isSpeaking: boolean;
  isLocked: boolean;
}

export interface RoomMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userDp: string;
  vipLevel: number;
  chatEffect: string;
  type: 'chat' | 'gift' | 'system' | 'join';
  text: string;
  giftId?: string;
  giftCoins?: number;
  timestamp: number;
}

export interface DirectMessage {
  id: string;
  fromId: string;
  toId: string;
  text: string;
  timestamp: number;
}

export interface RoomInvitation {
  id: string;
  roomId: string;
  roomTitle: string;
  roomType: VoiceRoomType;
  roomLevel: number;
  fromId: string;
  fromName: string;
  fromDp: string;
  fromVipLevel: number;
  toId: string;
  message: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: number;
}

export const VOICE_ROOM_CATEGORIES = ['Friend', 'Game', 'Chat', 'Music'] as const;
export type VoiceRoomCategory = (typeof VOICE_ROOM_CATEGORIES)[number];

export const VOICE_ROOM_TYPES = ['Normal', 'YouTube Room', 'Game Room', 'Official Zyro'] as const;
export type VoiceRoomType = (typeof VOICE_ROOM_TYPES)[number];

export interface VoiceRoom {
  id: string;
  title: string;
  category: VoiceRoomCategory;
  roomType: VoiceRoomType;
  ownerId: string;
  ownerName: string;
  ownerDp: string;
  ownerVipLevel: number;
  level: number;
  xpCoins: number; // total coins spent in this room
  nextLevelCoins: number;
  seats: SeatState[]; // owner + 12 speaker seats
  listenersCount: number;
  createdAt: number;
}

export interface FeedPost {
  id: string;
  authorId: string;
  authorName: string;
  authorDp: string;
  authorVip: number;
  tag: string;
  mediaType?: 'post' | 'video';
  videoTitle?: string;
  videoDuration?: string;
  videoUrl?: string;
  videoTheme?: 'concert' | 'carrom' | 'party';
  content: string;
  likes: string[]; // user IDs
  cpBoosts: number;
  comments: {
    id: string;
    userId: string;
    userName: string;
    text: string;
    timestamp: number;
  }[];
  createdAt: number;
}

export interface FamilyGroup {
  id: string;
  name: string;
  crest: string;
  motto: string;
  level: number;
  totalCp: number;
  activityScore: number;
  barrierUntil: number;
  leaderId: string;
  leaderName: string;
  memberIds: string[];
  maxMembers: number;
}

export interface VipTierInfo {
  level: number;
  name: string;
  entryTitle: string;
  minSpend: number;
  primaryColor: string;
  secondaryColor: string;
  accentHex: string;
  perkSummary: string;
  animationStyle: string;
}

export const VIP_TIERS: VipTierInfo[] = [
  { level: 0, name: 'Starter', entryTitle: 'Standard Arrival', minSpend: 0, primaryColor: '#64748B', secondaryColor: '#94A3B8', accentHex: '#64748B', perkSummary: 'Access to Play & 10-Seat Voice Rooms', animationStyle: 'fade' },
  { level: 1, name: 'VIP 1 · Jade', entryTitle: 'Emerald Breeze', minSpend: 100, primaryColor: '#10B981', secondaryColor: '#34D399', accentHex: '#10B981', perkSummary: 'Emerald Breeze room entry & Jade badge', animationStyle: 'emerald-breeze' },
  { level: 2, name: 'VIP 2 · Azure', entryTitle: 'Skyline Spark', minSpend: 350, primaryColor: '#0EA5E9', secondaryColor: '#38BDF8', accentHex: '#0EA5E9', perkSummary: 'Skyline Spark twin-star arrival trail', animationStyle: 'skyline-spark' },
  { level: 3, name: 'VIP 3 · Amber', entryTitle: 'Amber Lantern', minSpend: 800, primaryColor: '#F59E0B', secondaryColor: '#FBBF24', accentHex: '#F59E0B', perkSummary: 'Amber Lantern glow sweep & +5% daily CP', animationStyle: 'amber-lantern' },
  { level: 4, name: 'VIP 4 · Coral', entryTitle: 'Coral Wave', minSpend: 1500, primaryColor: '#F43F5E', secondaryColor: '#FB7185', accentHex: '#F43F5E', perkSummary: 'Coral Wave sonic ripple entrance', animationStyle: 'coral-wave' },
  { level: 5, name: 'VIP 5 · Knight', entryTitle: 'Velvet Knight', minSpend: 3000, primaryColor: '#6366F1', secondaryColor: '#A5B4FC', accentHex: '#6366F1', perkSummary: 'Velvet Knight crest slam & metallic gleam', animationStyle: 'velvet-knight' },
  { level: 6, name: 'VIP 6 · Aurora', entryTitle: 'Aurora Prism', minSpend: 5500, primaryColor: '#14B8A6', secondaryColor: '#8B5CF6', accentHex: '#14B8A6', perkSummary: 'Aurora Prism spectral curtain banner', animationStyle: 'aurora-prism' },
  { level: 7, name: 'VIP 7 · Solar', entryTitle: 'Solar Flare', minSpend: 9000, primaryColor: '#EA580C', secondaryColor: '#FACC15', accentHex: '#EA580C', perkSummary: 'Solar Flare corona burst & sunbeam rings', animationStyle: 'solar-flare' },
  { level: 8, name: 'VIP 8 · Frost', entryTitle: 'Frost Sovereign', minSpend: 14000, primaryColor: '#06B6D4', secondaryColor: '#E0F2FE', accentHex: '#06B6D4', perkSummary: 'Frost Sovereign ice-crystal shatter', animationStyle: 'frost-sovereign' },
  { level: 9, name: 'VIP 9 · Phoenix', entryTitle: 'Crimson Phoenix', minSpend: 21000, primaryColor: '#DC2626', secondaryColor: '#FB923C', accentHex: '#DC2626', perkSummary: 'Crimson Phoenix rising flame wings', animationStyle: 'crimson-phoenix' },
  { level: 10, name: 'VIP 10 · Valkyrie', entryTitle: 'Cyber Valkyrie', minSpend: 30000, primaryColor: '#4F46E5', secondaryColor: '#22D3EE', accentHex: '#4F46E5', perkSummary: 'Cyber Valkyrie precision laser grid wings', animationStyle: 'cyber-valkyrie' },
  { level: 11, name: 'VIP 11 · Comet', entryTitle: 'Celestial Comet', minSpend: 42000, primaryColor: '#7C3AED', secondaryColor: '#F472B6', accentHex: '#7C3AED', perkSummary: 'Celestial Comet diagonal meteor trail', animationStyle: 'celestial-comet' },
  { level: 12, name: 'VIP 12 · Dragon', entryTitle: 'Imperial Dragon', minSpend: 60000, primaryColor: '#B45309', secondaryColor: '#FDE047', accentHex: '#D97706', perkSummary: 'Imperial Dragon golden coil & thunder flash', animationStyle: 'imperial-dragon' },
  { level: 13, name: 'VIP 13 · Monarch', entryTitle: 'Nebula Monarch', minSpend: 85000, primaryColor: '#6D28D9', secondaryColor: '#38BDF8', accentHex: '#7C3AED', perkSummary: 'Nebula Monarch cosmic vortex & royal ring', animationStyle: 'nebula-monarch' },
  { level: 14, name: 'VIP 14 · Supreme', entryTitle: 'Eternal Supreme', minSpend: 120000, primaryColor: '#991B1B', secondaryColor: '#FBBF24', accentHex: '#EAB308', perkSummary: 'Eternal Supreme red-carpet curtains, crown & fireworks', animationStyle: 'eternal-supreme' },
];

export interface GiftItem {
  id: string;
  name: string;
  coins: number;
  cpReward: number;
  coinReturn: number;
  emoji: string;
  tier: 'classic' | 'deluxe' | 'luxury';
  color: string;
}

export const GIFT_CATALOG: GiftItem[] = [
  { id: 'rose', name: 'Velvet Rose', coins: 10, cpReward: 10, coinReturn: 1, emoji: '🌹', tier: 'classic', color: '#F43F5E' },
  { id: 'coffee', name: 'Party Boba', coins: 30, cpReward: 30, coinReturn: 4, emoji: '🧋', tier: 'classic', color: '#D97706' },
  { id: 'mic_gold', name: 'Golden Mic', coins: 100, cpReward: 115, coinReturn: 16, emoji: '🎤', tier: 'classic', color: '#EAB308' },
  { id: 'sports_car', name: 'Apex Coupe', coins: 200, cpReward: 250, coinReturn: 40, emoji: '🏎️', tier: 'deluxe', color: '#EF4444' },
  { id: 'crown', name: 'Royal Crown', coins: 500, cpReward: 650, coinReturn: 125, emoji: '👑', tier: 'deluxe', color: '#F59E0B' },
  { id: 'yacht', name: 'Starlight Yacht', coins: 1500, cpReward: 2000, coinReturn: 450, emoji: '🛥️', tier: 'luxury', color: '#0EA5E9' },
  { id: 'dragon', name: 'Imperial Dragon', coins: 5000, cpReward: 7000, coinReturn: 1750, emoji: '🐉', tier: 'luxury', color: '#7C3AED' },
];

export function computeGiftCharm(coins: number): number {
  return Math.floor(Math.max(0, coins) / 5);
}

export interface ShopItem {
  id: string;
  category: 'chat_effect' | 'entry_ride';
  name: string;
  description: string;
  price: number;
  previewClass: string;
  accentColor: string;
}

export const SHOP_ITEMS: ShopItem[] = [
  {
    id: 'chat_default',
    category: 'chat_effect',
    name: 'Classic Cloud',
    description: 'Clean crisp room message bubble.',
    price: 0,
    previewClass: 'bg-slate-800/90 text-white border border-white/10',
    accentColor: '#64748B',
  },
  {
    id: 'chat_mint',
    category: 'chat_effect',
    name: 'Jade Wave',
    description: 'Fresh emerald gradient chat frame with shimmer border.',
    price: 150,
    previewClass: 'bg-gradient-to-r from-emerald-600 to-teal-500 text-white border border-emerald-300/60 shadow-sm',
    accentColor: '#10B981',
  },
  {
    id: 'chat_sakura',
    category: 'chat_effect',
    name: 'Sakura Blossom',
    description: 'Soft rose-petal chat frame for warm room greetings.',
    price: 350,
    previewClass: 'bg-gradient-to-r from-rose-500 to-pink-500 text-white border border-pink-200/70 shadow-sm',
    accentColor: '#F43F5E',
  },
  {
    id: 'chat_royal',
    category: 'chat_effect',
    name: 'Royal Gold Scroll',
    description: 'Regal amber-gold chat frame with gilded border.',
    price: 800,
    previewClass: 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-slate-950 font-semibold border border-yellow-200 shadow-md',
    accentColor: '#F59E0B',
  },
  {
    id: 'chat_nebula',
    category: 'chat_effect',
    name: 'Nebula Pulse',
    description: 'Deep indigo-violet aura bubble for VIP hosts.',
    price: 1600,
    previewClass: 'bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-500 text-white border border-indigo-300/70 shadow-md',
    accentColor: '#6366F1',
  },
  {
    id: 'ride_scooter',
    category: 'entry_ride',
    name: 'Mint Retro Scooter',
    description: 'Zip into voice rooms with a cheerful retro scooter trail.',
    price: 400,
    previewClass: 'from-emerald-500 to-cyan-500',
    accentColor: '#10B981',
  },
  {
    id: 'ride_pegasus',
    category: 'entry_ride',
    name: 'Starlight Pegasus',
    description: 'Winged celestial arrival banner across the room stage.',
    price: 2200,
    previewClass: 'from-indigo-500 to-violet-600',
    accentColor: '#6366F1',
  },
  {
    id: 'ride_chariot',
    category: 'entry_ride',
    name: 'Sovereign Gold Chariot',
    description: 'Grand golden chariot arrival with royal confetti burst.',
    price: 6500,
    previewClass: 'from-amber-500 to-red-600',
    accentColor: '#F59E0B',
  },
];

export const TOPUP_PACKAGES = [
  { id: 'pack_500', coins: 500, bonus: 25, priceLabel: '₹99', tag: 'Starter' },
  { id: 'pack_1500', coins: 1500, bonus: 150, priceLabel: '₹249', tag: 'Popular' },
  { id: 'pack_5000', coins: 5000, bonus: 750, priceLabel: '₹799', tag: 'Value' },
  { id: 'pack_15000', coins: 15000, bonus: 3000, priceLabel: '₹1,999', tag: 'VIP Boost' },
  { id: 'pack_50000', coins: 50000, bonus: 12000, priceLabel: '₹4,999', tag: 'Royalty' },
  { id: 'pack_120000', coins: 120000, bonus: 35000, priceLabel: '₹9,999', tag: 'Supreme' },
];

export interface RealPfpPreset {
  id: string;
  label: string;
  imageUrl: string;
}

export const REAL_PFP_PRESETS: RealPfpPreset[] = [
  { id: 'pfp_aria', label: 'Aria Portrait', imageUrl: '/src/assets/images/pfp_aria_portrait_1794700745727.jpg' },
  { id: 'pfp_marcus', label: 'Marcus Portrait', imageUrl: '/src/assets/images/pfp_marcus_portrait_1794700746699.jpg' },
  { id: 'pfp_nadia', label: 'Nadia Portrait', imageUrl: '/src/assets/images/pfp_nadia_portrait_1794700747574.jpg' },
  { id: 'pfp_leo', label: 'Leo Portrait', imageUrl: '/src/assets/images/pfp_leo_portrait_1794700747117.jpg' },
];

export const AVATAR_PRESETS: { id: string; label: string; bg: string; emoji: string }[] = [
  { id: 'avatar_fox', label: 'Crimson Fox', bg: 'from-rose-500 to-orange-400', emoji: '🦊' },
  { id: 'avatar_panda', label: 'Jade Panda', bg: 'from-emerald-500 to-teal-500', emoji: '🐼' },
  { id: 'avatar_lion', label: 'Golden Lion', bg: 'from-amber-500 to-yellow-400', emoji: '🦁' },
  { id: 'avatar_owl', label: 'Indigo Owl', bg: 'from-indigo-600 to-sky-500', emoji: '🦉' },
  { id: 'avatar_cat', label: 'Velvet Cat', bg: 'from-violet-600 to-fuchsia-500', emoji: '🐱' },
  { id: 'avatar_koala', label: 'Cloud Koala', bg: 'from-sky-500 to-cyan-400', emoji: '🐨' },
  { id: 'avatar_dragon', label: 'Imperial Dragon', bg: 'from-red-600 to-amber-500', emoji: '🐲' },
  { id: 'avatar_unicorn', label: 'Aurora Unicorn', bg: 'from-pink-500 to-indigo-500', emoji: '🦄' },
];

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  rewardCoins: number;
  rewardCp: number;
  target: number;
  metric: 'checkin' | 'games' | 'gifts' | 'posts' | 'vip';
}

export const DAILY_TASKS: TaskItem[] = [
  { id: 'task_checkin', title: 'Daily Party Check-In', description: 'Check in today to claim welcome coins & CP.', rewardCoins: 150, rewardCp: 50, target: 1, metric: 'checkin' },
  { id: 'task_play_game', title: 'Arcade Challenger', description: 'Play and finish a Carrom, Uno, Mic, or Spy match.', rewardCoins: 200, rewardCp: 80, target: 1, metric: 'games' },
  { id: 'task_send_gift', title: 'Generous Host', description: 'Send any gift inside a live Voice Room.', rewardCoins: 180, rewardCp: 120, target: 1, metric: 'gifts' },
  { id: 'task_discover_post', title: 'Community Spark', description: 'Share a post or boost CP in Discover.', rewardCoins: 120, rewardCp: 100, target: 1, metric: 'posts' },
  { id: 'task_vip_rise', title: 'Royal Ascent', description: 'Reach VIP Level 1 or higher by spending coins.', rewardCoins: 500, rewardCp: 300, target: 1, metric: 'vip' },
];

export const PARTY_EMOTES = [
  { id: 'laugh', emoji: '😂', label: 'Laugh' },
  { id: 'heart', emoji: '❤️', label: 'Love' },
  { id: 'fire', emoji: '🔥', label: 'Fire' },
  { id: 'clap', emoji: '👏', label: 'Clap' },
  { id: 'star', emoji: '🤩', label: 'Star' },
  { id: 'mic', emoji: '🎤', label: 'Encore' },
];

export interface ActivityChest {
  id: string;
  name: string;
  tier: string;
  requiredPoints: number;
  rewardCoins: number;
  rewardCp: number;
  icon: string;
}

export const ACTIVITY_CHESTS: ActivityChest[] = [
  { id: 'chest_bronze', name: 'Bronze Gift Chest', tier: 'Tier 1', requiredPoints: 150, rewardCoins: 120, rewardCp: 80, icon: '🧰' },
  { id: 'chest_silver', name: 'Silver Party Chest', tier: 'Tier 2', requiredPoints: 500, rewardCoins: 300, rewardCp: 220, icon: '🎁' },
  { id: 'chest_gold', name: 'Gold Clan Chest', tier: 'Tier 3', requiredPoints: 1200, rewardCoins: 750, rewardCp: 550, icon: '🏆' },
  { id: 'chest_royal', name: 'Royal Crown Chest', tier: 'Tier 4', requiredPoints: 2500, rewardCoins: 1800, rewardCp: 1400, icon: '👑' },
];

export interface GachaReward {
  id: string;
  name: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic';
  icon: string;
  color: string;
  coinsBonus: number;
  cpBonus: number;
  unlockShopId?: string;
  unlockCategory?: 'chat_effect' | 'entry_ride';
  weight: number;
}

export const GACHA_REWARDS: GachaReward[] = [
  { id: 'g_confetti', name: 'Party Coin Pouch', rarity: 'Common', icon: '🪙', color: '#F59E0B', coinsBonus: 140, cpBonus: 40, weight: 24 },
  { id: 'g_rose_box', name: 'Velvet Charm Box', rarity: 'Common', icon: '🌹', color: '#F43F5E', coinsBonus: 60, cpBonus: 120, weight: 22 },
  { id: 'g_jade_chat', name: 'Jade Chat Frame', rarity: 'Rare', icon: '💬', color: '#10B981', coinsBonus: 40, cpBonus: 100, unlockShopId: 'chat_mint', unlockCategory: 'chat_effect', weight: 14 },
  { id: 'g_neon_halo', name: 'Neon Halo Crest', rarity: 'Rare', icon: '🪩', color: '#0EA5E9', coinsBonus: 180, cpBonus: 160, weight: 14 },
  { id: 'g_scooter', name: 'Retro Scooter Ride', rarity: 'Epic', icon: '🛵', color: '#06B6D4', coinsBonus: 100, cpBonus: 200, unlockShopId: 'ride_scooter', unlockCategory: 'entry_ride', weight: 10 },
  { id: 'g_sakura_chat', name: 'Sakura Chat Aura', rarity: 'Epic', icon: '🌸', color: '#EC4899', coinsBonus: 120, cpBonus: 240, unlockShopId: 'chat_sakura', unlockCategory: 'chat_effect', weight: 8 },
  { id: 'g_pegasus', name: 'Starlight Pegasus', rarity: 'Mythic', icon: '🦄', color: '#6366F1', coinsBonus: 350, cpBonus: 500, unlockShopId: 'ride_pegasus', unlockCategory: 'entry_ride', weight: 5 },
  { id: 'g_chariot', name: 'Sovereign Chariot', rarity: 'Mythic', icon: '👑', color: '#EAB308', coinsBonus: 800, cpBonus: 1000, unlockShopId: 'ride_chariot', unlockCategory: 'entry_ride', weight: 3 },
];

export function computeVipLevel(totalSpent: number): number {
  let lvl = 0;
  for (const tier of VIP_TIERS) {
    if (totalSpent >= tier.minSpend) {
      lvl = tier.level;
    }
  }
  return lvl;
}

export function computeRoomLevel(xpCoins: number): { level: number; nextLevelCoins: number; currentFloor: number } {
  const thresholds = [0, 200, 600, 1500, 3200, 6000, 10000, 16000, 25000, 40000, 65000];
  let level = 1;
  for (let i = 0; i < thresholds.length; i++) {
    if (xpCoins >= thresholds[i]) {
      level = i + 1;
    }
  }
  const currentFloor = thresholds[Math.min(level - 1, thresholds.length - 1)];
  const nextLevelCoins = thresholds[Math.min(level, thresholds.length - 1)] || currentFloor + 25000;
  return { level, nextLevelCoins, currentFloor };
}
