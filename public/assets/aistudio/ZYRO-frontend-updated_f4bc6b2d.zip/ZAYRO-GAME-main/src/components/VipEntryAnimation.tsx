import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Crown, Flame, Snowflake, Sparkles, Star, Zap, Shield, Compass, Sun } from 'lucide-react';
import { VIP_TIERS, SHOP_ITEMS } from '../shared/types';
import { AvatarBadge } from './AvatarBadge';
import { playVipFanfare } from '../utils/sound';

export interface EntryTrigger {
  id: string;
  userName: string;
  userDp: string;
  vipLevel: number;
  equippedEntryEffect: string;
}

interface VipEntryAnimationProps {
  trigger: EntryTrigger | null;
  onComplete: () => void;
}

function renderTierMotif(vipLevel: number, rideId: string) {
  if (rideId === 'ride_scooter') return <span className="text-3xl">🛵</span>;
  if (rideId === 'ride_pegasus') return <span className="text-3xl">🦄</span>;
  if (rideId === 'ride_chariot') return <span className="text-3xl">🏎️</span>;

  switch (vipLevel) {
    case 1:
      return <span className="text-2xl">🌿</span>;
    case 2:
      return <Sparkles className="w-7 h-7 text-sky-200" />;
    case 3:
      return <span className="text-2xl">🏮</span>;
    case 4:
      return <span className="text-2xl">🌊</span>;
    case 5:
      return <Shield className="w-7 h-7 text-indigo-200" />;
    case 6:
      return <Compass className="w-7 h-7 text-teal-200 animate-spin-slow" />;
    case 7:
      return <Sun className="w-8 h-8 text-yellow-200 animate-spin-slow" />;
    case 8:
      return <Snowflake className="w-8 h-8 text-cyan-100 animate-spin-slow" />;
    case 9:
      return <Flame className="w-8 h-8 text-orange-200" />;
    case 10:
      return <Zap className="w-8 h-8 text-cyan-300" />;
    case 11:
      return <Star className="w-8 h-8 text-pink-200 animate-pulse" />;
    case 12:
      return <span className="text-3xl">🐉</span>;
    case 13:
      return <span className="text-3xl">🌌</span>;
    case 14:
      return <Crown className="w-9 h-9 text-yellow-300 drop-shadow" />;
    default:
      return <Star className="w-6 h-6 text-slate-200" />;
  }
}

export const VipEntryAnimation: React.FC<VipEntryAnimationProps> = ({ trigger, onComplete }) => {
  useEffect(() => {
    if (!trigger) return;

    const effectiveVip =
      trigger.equippedEntryEffect.startsWith('vip_')
        ? Number(trigger.equippedEntryEffect.replace('vip_', ''))
        : trigger.vipLevel;

    playVipFanfare(effectiveVip);

    if (effectiveVip >= 7 || trigger.equippedEntryEffect === 'ride_chariot') {
      const colors =
        effectiveVip === 14
          ? ['#FBBF24', '#DC2626', '#FFFFFF', '#FDE047']
          : effectiveVip >= 11
          ? ['#7C3AED', '#38BDF8', '#F472B6']
          : ['#F59E0B', '#FBBF24', '#FB7185'];

      confetti({
        particleCount: effectiveVip === 14 ? 90 : 45,
        spread: effectiveVip === 14 ? 95 : 65,
        origin: { y: 0.32 },
        colors,
      });
    }

    const timer = setTimeout(onComplete, effectiveVip >= 12 ? 3600 : 2900);
    return () => clearTimeout(timer);
  }, [trigger, onComplete]);

  if (!trigger) return null;

  const isRide = trigger.equippedEntryEffect.startsWith('ride_');
  const rideItem = isRide ? SHOP_ITEMS.find((i) => i.id === trigger.equippedEntryEffect) : null;

  const effectiveVip =
    trigger.equippedEntryEffect.startsWith('vip_')
      ? Number(trigger.equippedEntryEffect.replace('vip_', ''))
      : trigger.vipLevel;

  const tier = VIP_TIERS[Math.min(14, Math.max(0, effectiveVip))];

  const bgGradient = rideItem
    ? `linear-gradient(120deg, ${rideItem.accentColor}, #1E1B4B)`
    : `linear-gradient(125deg, ${tier.primaryColor}, ${tier.secondaryColor})`;

  return (
    <AnimatePresence>
      <motion.div
        key={trigger.id}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pointer-events-none fixed inset-x-0 top-20 z-50 flex flex-col items-center justify-center px-4"
      >
        {/* VIP 14 Curtain Flash Backdrop */}
        {effectiveVip >= 12 && (
          <motion.div
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 0.92 }}
            exit={{ scaleX: 0, opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-2xl rounded-2xl p-[2px] shadow-2xl"
            style={{
              background:
                effectiveVip === 14
                  ? 'linear-gradient(90deg, #FBBF24, #EF4444, #FDE047, #EF4444, #FBBF24)'
                  : `linear-gradient(90deg, ${tier.primaryColor}, ${tier.secondaryColor})`,
            }}
          >
            <div className="relative overflow-hidden rounded-[14px] px-6 py-4 text-white" style={{ background: bgGradient }}>
              {/* Animated sweeping sheen */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -skew-x-12 animate-shimmer" />

              {/* Geometric orbital ring for high tiers */}
              <motion.div
                initial={{ scale: 0.5, rotate: -45, opacity: 0 }}
                animate={{ scale: 1.15, rotate: 0, opacity: 0.25 }}
                transition={{ duration: 0.8 }}
                className="absolute -right-8 -top-8 w-40 h-40 rounded-full border-4 border-dashed border-white/50"
              />

              <div className="relative flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <motion.div
                    initial={{ scale: 0.6, rotate: -15 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: 'spring', stiffness: 260, damping: 16 }}
                  >
                    <AvatarBadge dp={trigger.userDp} name={trigger.userName} vipLevel={effectiveVip} size="lg" />
                  </motion.div>
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white/90">
                      <span>{rideItem ? rideItem.name : tier.name}</span>
                      <span aria-hidden="true">·</span>
                      <span>{tier.entryTitle}</span>
                    </div>
                    <h4 className="font-display text-xl sm:text-2xl font-extrabold tracking-tight text-white drop-shadow-sm">
                      {trigger.userName} Arrives!
                    </h4>
                  </div>
                </div>
                <motion.div
                  initial={{ y: -20, scale: 0.7 }}
                  animate={{ y: 0, scale: 1.1 }}
                  transition={{ type: 'spring', stiffness: 220, damping: 12 }}
                  className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 backdrop-blur-md border border-white/25"
                >
                  {renderTierMotif(effectiveVip, trigger.equippedEntryEffect)}
                </motion.div>
              </div>
            </div>
          </motion.div>
        )}

        {/* VIP 1 - 11 & Standard / Ride Entrances */}
        {effectiveVip < 12 && (
          <motion.div
            initial={{ x: -180, opacity: 0, scale: 0.92 }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            exit={{ x: 200, opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-lg overflow-hidden rounded-2xl shadow-xl border border-white/30 text-white px-5 py-3.5"
            style={{ background: bgGradient }}
          >
            {/* Tier-specific particle/wave accents */}
            {effectiveVip >= 4 && effectiveVip <= 6 && (
              <motion.div
                initial={{ scale: 0.3, opacity: 0.8 }}
                animate={{ scale: 2.2, opacity: 0 }}
                transition={{ duration: 1.2, repeat: 1 }}
                className="absolute left-6 top-1/2 -translate-y-1/2 w-20 h-20 rounded-full border-2 border-white/60"
              />
            )}
            {effectiveVip >= 7 && effectiveVip <= 11 && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -skew-x-12 animate-shimmer" />
            )}

            <div className="relative flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <AvatarBadge dp={trigger.userDp} name={trigger.userName} vipLevel={effectiveVip} size="md" />
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-white/85">
                    {rideItem ? rideItem.name : `${tier.name} · ${tier.entryTitle}`}
                  </div>
                  <div className="font-display text-base sm:text-lg font-bold text-white">
                    {trigger.userName} joined the stage
                  </div>
                </div>
              </div>
              <motion.div
                initial={{ rotate: -20, scale: 0.7 }}
                animate={{ rotate: 0, scale: 1 }}
                transition={{ type: 'spring', stiffness: 280, damping: 14 }}
                className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm"
              >
                {renderTierMotif(effectiveVip, trigger.equippedEntryEffect)}
              </motion.div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
};
