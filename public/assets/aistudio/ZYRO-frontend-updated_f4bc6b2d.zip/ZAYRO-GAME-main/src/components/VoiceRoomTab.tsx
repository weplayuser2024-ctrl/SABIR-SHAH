import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Clapperboard,
  Coins,
  Crown,
  Flame,
  Gamepad2,
  Gift,
  Heart,
  Lock,
  Mic,
  MicOff,
  Plus,
  Radio,
  Search,
  Send,
  Shuffle,
  Smile,
  Sparkles,
  Tag,
  UserPlus,
  Users,
  Video,
  VideoOff,
  X,
} from 'lucide-react';
import {
  GIFT_CATALOG,
  GiftItem,
  PARTY_EMOTES,
  PublicFriend,
  RoomMessage,
  SHOP_ITEMS,
  SeatState,
  UserProfile,
  VOICE_ROOM_CATEGORIES,
  VOICE_ROOM_TYPES,
  VoiceRoom,
  VoiceRoomType,
  computeGiftCharm,
  computeRoomLevel,
} from '../shared/types';
import { AvatarBadge } from './AvatarBadge';
import { playCoinChime } from '../utils/sound';

interface FloatingEmote {
  id: string;
  seatIndex: number;
  userName: string;
  emoji: string;
}

interface GiftBanner {
  id: string;
  senderName: string;
  senderDp: string;
  recipientName: string;
  gift: GiftItem;
  roomLeveledUp: boolean;
  newRoomLevel: number;
}

interface VoiceRoomTabProps {
  user: UserProfile;
  rooms: VoiceRoom[];
  friends: PublicFriend[];
  activeRoomId: string | null;
  activeRoom: VoiceRoom | null;
  roomMessages: RoomMessage[];
  floatingEmotes: FloatingEmote[];
  giftBanner: GiftBanner | null;
  roomError: string | null;
  onJoinRoom: (roomId: string) => void;
  onLeaveRoom: () => void;
  onCreateRoom: (
    title: string,
    category: VoiceRoom['category']
  ) => Promise<string | null>;
  onChangeRoomType: (roomType: VoiceRoomType) => void;
  onInviteFriend: (roomId: string, friendId: string) => Promise<string | null>;
  onTakeSeat: (seatIndex: number) => void;
  onLeaveSeat: () => void;
  onToggleMute: () => void;
  onSetSpeaking: (speaking: boolean) => void;
  onSendChat: (text: string) => void;
  onSendEmote: (emoji: string) => void;
  onSendGift: (giftId: string, recipientId: string) => void;
  onOpenTopUp: () => void;
}

const ACTION_PROMPTS = [
  'Sing 1 chorus line of your favorite song on mic!',
  'Give a dramatic 10-second compliment to the Owner Partner!',
  'Drop your signature emote and tell a 1-sentence plot twist!',
  'Challenge anyone seated to a quick Carrom or Uno duel!',
  'Speak in an accent or radio-DJ voice for your next turn!',
  'Name 3 things in 5 seconds or send a Velvet Rose!',
];

const ROOM_TYPE_THEMES: Record<
  VoiceRoomType,
  {
    bg: string;
    glow: string;
    accentText: string;
    subtleBadge: string;
    shortDesc: string;
  }
> = {
  Normal: {
    bg: 'bg-gradient-to-b from-[#141A3A] via-[#1C234D] to-[#131733] border-indigo-400/20',
    glow: 'from-indigo-500/20 via-violet-500/10 to-transparent',
    accentText: 'text-indigo-200',
    subtleBadge: 'bg-indigo-500/20 text-indigo-100 border-indigo-300/25',
    shortDesc: '12-speaker voice party',
  },
  'YouTube Room': {
    bg: 'bg-gradient-to-b from-[#0C162C] via-[#132544] to-[#111833] border-sky-400/25',
    glow: 'from-sky-500/20 via-cyan-500/10 to-transparent',
    accentText: 'text-sky-200',
    subtleBadge: 'bg-sky-500/20 text-sky-100 border-sky-300/25',
    shortDesc: 'Watch YouTube together in the room',
  },
  'Official Zyro': {
    bg: 'bg-gradient-to-b from-[#170A2B] via-[#251044] to-[#0C1028] border-fuchsia-300/30',
    glow: 'from-fuchsia-400/25 via-violet-500/15 to-transparent',
    accentText: 'text-fuchsia-100',
    subtleBadge: 'bg-fuchsia-500/20 text-fuchsia-100 border-fuchsia-300/30',
    shortDesc: 'Official admin-controlled ZYRO room',
  },
  'Game Room': {
    bg: 'bg-gradient-to-b from-[#0B2229] via-[#11313B] to-[#111B33] border-emerald-400/25',
    glow: 'from-emerald-500/20 via-teal-500/10 to-transparent',
    accentText: 'text-emerald-200',
    subtleBadge: 'bg-emerald-500/20 text-emerald-100 border-emerald-300/25',
    shortDesc: 'Squad matchmaking & mini-game lobby',
  },
};

function renderRoomTypeIcon(type: VoiceRoomType, className = 'w-3.5 h-3.5') {
  if (type === 'YouTube Room') return <Video className={className} />;
  if (type === 'Official Zyro') return <Crown className={className} />;
  if (type === 'Game Room') return <Gamepad2 className={className} />;
  return <Radio className={className} />;
}

export const VoiceRoomTab: React.FC<VoiceRoomTabProps> = ({
  user,
  rooms,
  friends,
  activeRoomId,
  activeRoom,
  roomMessages,
  floatingEmotes,
  giftBanner,
  roomError,
  onJoinRoom,
  onLeaveRoom,
  onCreateRoom,
  onChangeRoomType,
  onInviteFriend,
  onTakeSeat,
  onLeaveSeat,
  onToggleMute,
  onSetSpeaking,
  onSendChat,
  onSendEmote,
  onSendGift,
  onOpenTopUp,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'All' | VoiceRoom['category']>('All');
  const [uidQuery, setUidQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<VoiceRoom['category']>('Friend');
  const [createError, setCreateError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const [chatText, setChatText] = useState('');
  const [activeTray, setActiveTray] = useState<'none' | 'emotes' | 'gifts' | 'invite'>('none');
  const [invitedFriendIds, setInvitedFriendIds] = useState<string[]>([]);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>('');
  const [liveMicActive, setLiveMicActive] = useState(false);
  const [youtubeInput, setYoutubeInput] = useState('');
  const [youtubeEmbed, setYoutubeEmbed] = useState('');

  // Room-type interactive state
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraHint, setCameraHint] = useState<string | null>(null);
  const [actionPromptIdx, setActionPromptIdx] = useState(0);

  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micIntervalRef = useRef<number | null>(null);
  const videoStreamRef = useRef<MediaStream | null>(null);
  const videoElRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [roomMessages]);

  useEffect(() => {
    if (activeRoom) {
      setSelectedRecipientId(activeRoom.ownerId);
    }
    setActiveTray('none');
    setInvitedFriendIds([]);
  }, [activeRoom?.id]);

  // Clean up mic & camera streams on room exit
  useEffect(() => {
    return () => {
      if (micIntervalRef.current) clearInterval(micIntervalRef.current);
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((t) => t.stop());
        micStreamRef.current = null;
      }
      if (videoStreamRef.current) {
        videoStreamRef.current.getTracks().forEach((t) => t.stop());
        videoStreamRef.current = null;
      }
      setCameraActive(false);
      setLiveMicActive(false);
    };
  }, [activeRoomId]);

  useEffect(() => {
    if (videoElRef.current && videoStreamRef.current && cameraActive) {
      videoElRef.current.srcObject = videoStreamRef.current;
    }
  }, [cameraActive]);

  const handleToggleRealAudioMic = async () => {
    if (liveMicActive) {
      if (micIntervalRef.current) clearInterval(micIntervalRef.current);
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((t) => t.stop());
        micStreamRef.current = null;
      }
      setLiveMicActive(false);
      onSetSpeaking(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      source.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      setLiveMicActive(true);

      let lastState = false;
      micIntervalRef.current = window.setInterval(() => {
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        const speaking = avg > 18;
        if (speaking !== lastState) {
          lastState = speaking;
          onSetSpeaking(speaking);
        }
      }, 220);
    } catch {
      onToggleMute();
    }
  };

  const handleToggleStageVideo = async () => {
    setCameraHint(null);
    if (cameraActive) {
      if (videoStreamRef.current) {
        videoStreamRef.current.getTracks().forEach((t) => t.stop());
        videoStreamRef.current = null;
      }
      setCameraActive(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoStreamRef.current = stream;
      setCameraActive(true);
    } catch {
      setCameraHint('Camera unavailable in preview — Stage Broadcast mode active');
    }
  };

  const handleSpinAction = () => {
    const nextIdx = (actionPromptIdx + 1 + Math.floor(Math.random() * (ACTION_PROMPTS.length - 1))) % ACTION_PROMPTS.length;
    setActionPromptIdx(nextIdx);
    onSendChat(`🎯 Action Prompt: ${ACTION_PROMPTS[nextIdx]}`);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);
    setCreating(true);
    const err = await onCreateRoom(newTitle, newCategory);
    setCreating(false);
    if (err) {
      setCreateError(err);
    } else {
      playCoinChime();
      setShowCreateModal(false);
      setNewTitle('');
    }
  };

  const handleSendChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatText.trim()) return;
    onSendChat(chatText.trim());
    setChatText('');
  };

  // ---- ACTIVE VOICE ROOM VIEW (SINGLE COHESIVE BACKGROUND) ----
  if (activeRoomId && activeRoom) {
    const roomType: VoiceRoomType = activeRoom.roomType || 'Normal';
    const theme = ROOM_TYPE_THEMES[roomType] || ROOM_TYPE_THEMES.Normal;
    const mySeat = activeRoom.seats.find((s) => s.userId === user.id);
    const levelStats = computeRoomLevel(activeRoom.xpCoins);
    const levelProgressPct = Math.min(
      100,
      Math.max(
        5,
        Math.round(
          ((activeRoom.xpCoins - levelStats.currentFloor) /
            Math.max(1, levelStats.nextLevelCoins - levelStats.currentFloor)) *
            100
        )
      )
    );
    const seatedTargets = activeRoom.seats.filter((s) => s.userId !== null);

    const renderSeat = (seat: SeatState, isTopSeat: boolean) => {
      const isOwnerSeat = seat.seatIndex === 0;
      const isPartnerSeat = seat.seatIndex === 1;
      const isMine = seat.userId === user.id;
      const seatEmote = floatingEmotes.find((e) => e.seatIndex === seat.seatIndex);

      return (
        <div key={seat.seatIndex} className="relative flex flex-col items-center">
          {seatEmote && (
            <div className="absolute -top-6 z-20 text-3xl animate-float-emote pointer-events-none">
              {seatEmote.emoji}
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              if (isMine && !isOwnerSeat) {
                onLeaveSeat();
              } else if (!seat.userId) {
                onTakeSeat(seat.seatIndex);
              } else if (isOwnerSeat && activeRoom.ownerId !== user.id) {
                onTakeSeat(0);
              }
            }}
            className={`relative rounded-full flex items-center justify-center transition-all ${
              isTopSeat ? 'w-14 h-14 sm:w-18 sm:h-18' : 'w-12 h-12 sm:w-14 sm:h-14'
            } ${
              seat.userId
                ? seat.isSpeaking
                  ? 'ring-4 ring-emerald-400 bg-white/10'
                  : 'bg-white/10 hover:bg-white/15'
                : isOwnerSeat
                ? 'border-2 border-dashed border-amber-400/75 bg-amber-500/15'
                : isPartnerSeat
                ? 'border-2 border-dashed border-rose-400/75 bg-rose-500/15 hover:border-rose-300'
                : 'border-2 border-dashed border-white/25 bg-white/5 hover:border-white/50 hover:bg-white/10'
            }`}
          >
            {seat.userId ? (
              <>
                <AvatarBadge
                  dp={seat.userDp || 'avatar_fox'}
                  name={seat.userName || 'Guest'}
                  vipLevel={seat.vipLevel}
                  size={isTopSeat ? 'lg' : 'md'}
                  className={isTopSeat ? '!w-14 !h-14 sm:!w-18 sm:!h-18' : '!w-12 !h-12 sm:!w-14 sm:!h-14'}
                />
                {seat.isMuted && (
                  <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-950/90 border border-white/20 flex items-center justify-center text-rose-400">
                    <MicOff className="w-2.5 h-2.5" />
                  </span>
                )}
              </>
            ) : isOwnerSeat ? (
              <div className="flex flex-col items-center text-amber-300">
                <Lock className="w-3.5 h-3.5" />
                <span className="text-[9px] font-bold mt-0.5">Owner</span>
              </div>
            ) : isPartnerSeat ? (
              <div className="flex flex-col items-center text-rose-200">
                <Heart className="w-3.5 h-3.5" />
                <span className="text-[9px] font-bold mt-0.5">Partner</span>
              </div>
            ) : (
              <div className="flex flex-col items-center text-white/75">
                <Plus className="w-4 h-4" />
                <span className="text-[9px] font-semibold">Seat {seat.seatIndex + 1}</span>
              </div>
            )}

            {isOwnerSeat && (
              <span className="absolute -top-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow">
                <Crown className="w-3 h-3" />
              </span>
            )}

            {isPartnerSeat && (
              <span className="absolute -top-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-rose-500 text-white flex items-center justify-center shadow">
                <Heart className="w-3 h-3 fill-white" />
              </span>
            )}
          </button>

          <div className="mt-1.5 text-center max-w-full px-0.5">
            <div className="text-[11px] font-semibold text-white truncate">
              {seat.userId
                ? seat.userName
                : isOwnerSeat
                ? 'Owner'
                : isPartnerSeat
                ? 'Owner Partner'
                : `Seat ${seat.seatIndex + 1}`}
            </div>
            <div className={`text-[10px] ${theme.accentText} opacity-80 truncate`}>
              {isOwnerSeat
                ? 'Owner Only'
                : isPartnerSeat && !seat.userId
                ? 'Partner Seat'
                : isMine
                ? 'Tap to Stand'
                : seat.userId
                ? `VIP ${seat.vipLevel}`
                : 'Tap to Sit'}
            </div>
          </div>
        </div>
      );
    };

    const topSeats = activeRoom.seats.slice(0, 2);
    const firstFourRow = activeRoom.seats.slice(2, 6);
    const secondFourRow = activeRoom.seats.slice(6, 10);
    const thirdRow = activeRoom.seats.slice(10, 13);

    return (
      <div className="max-w-4xl mx-auto px-3 sm:px-4 pt-3 pb-24">
        {/* SINGLE COHESIVE ATMOSPHERIC VOICE ROOM CONTAINER */}
        <section
          className={`relative rounded-3xl ${theme.bg} text-white shadow-2xl border overflow-hidden flex flex-col min-h-[calc(100vh-7.5rem)]`}
        >
          {/* Ambient Top Stage Glow */}
          <div
            aria-hidden="true"
            className={`pointer-events-none absolute inset-x-0 top-0 h-64 bg-gradient-to-b ${theme.glow}`}
          />

          {/* 1. VERY TOP: ROOM LEVEL & ROOM NAME */}
          <header className="relative z-10 px-4 sm:px-6 pt-4 pb-3 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <button
                onClick={onLeaveRoom}
                className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center shrink-0 transition-colors"
                aria-label="Leave Voice Room"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono-num text-xs font-extrabold px-2 py-0.5 rounded-lg bg-amber-400 text-slate-950 shrink-0">
                    Lv.{activeRoom.level}
                  </span>
                  <h2 className="font-display text-base sm:text-xl font-extrabold text-white truncate">
                    {activeRoom.title}
                  </h2>
                </div>
                <div className={`mt-0.5 flex items-center gap-2 text-[11px] ${theme.accentText}`}>
                  <span className="inline-flex items-center gap-1 font-semibold">
                    {renderRoomTypeIcon(roomType, 'w-3 h-3')}
                    <span>{roomType}</span>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{activeRoom.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">{activeRoom.listenersCount} Online</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <div className="text-right">
                <div className="font-mono-num text-[11px] text-amber-300 font-semibold">
                  XP {activeRoom.xpCoins.toLocaleString()} / {levelStats.nextLevelCoins.toLocaleString()}
                </div>
                <div className="w-24 sm:w-32 h-1.5 rounded-full bg-white/15 overflow-hidden mt-1 ml-auto">
                  <div
                    className="h-full bg-gradient-to-r from-amber-400 to-rose-400 transition-all duration-300"
                    style={{ width: `${levelProgressPct}%` }}
                  />
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTray((t) => (t === 'invite' ? 'none' : 'invite'))}
                aria-label="Invite Friends to Room"
                title="Invite Friends"
                className={`h-10 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 border shrink-0 whitespace-nowrap transition-colors ${
                  activeTray === 'invite'
                    ? 'bg-indigo-500 text-white border-indigo-400'
                    : 'bg-white/10 hover:bg-white/20 text-white border-white/15'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span className="hidden sm:inline">Invite</span>
              </button>
            </div>
          </header>

          {/* IN-ROOM MODE SWITCHER: Normal / YouTube Room / Game Room / Official Zyro */}
          <div className="relative z-10 px-4 sm:px-6 pt-3">
            <div className="flex items-center gap-1.5 bg-black/25 border border-white/10 rounded-2xl p-1 overflow-x-auto flex-nowrap">
              {VOICE_ROOM_TYPES.map((type) => {
                const selected = roomType === type;
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => onChangeRoomType(type)}
                    className={`flex-1 min-w-max h-9 px-3 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-1.5 whitespace-nowrap transition-colors ${
                      selected
                        ? 'bg-white text-slate-950 shadow-sm'
                        : 'text-white/75 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {renderRoomTypeIcon(type, 'w-3.5 h-3.5 shrink-0')}
                    <span>{type}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Error / Gift Banner Feedback */}
          {roomError && (
            <div className="relative z-10 mx-4 sm:mx-6 mt-3 rounded-xl bg-rose-500/25 border border-rose-400/40 px-4 py-2 text-xs font-semibold text-rose-100">
              {roomError}
            </div>
          )}

          {giftBanner && (
            <div className="relative z-10 mx-4 sm:mx-6 mt-3 rounded-2xl bg-gradient-to-r from-amber-500/90 via-rose-500/90 to-indigo-600/90 px-4 py-2.5 flex items-center justify-between gap-3 shadow-lg border border-white/25">
              <div className="flex items-center gap-3 min-w-0">
                <span className="text-2xl sm:text-3xl animate-bounce shrink-0">{giftBanner.gift.emoji}</span>
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-white/95 truncate">
                    {giftBanner.senderName} sent {giftBanner.gift.name} to {giftBanner.recipientName}
                  </div>
                  <div className="font-display text-xs sm:text-sm font-extrabold text-white">
                    +{giftBanner.gift.coins.toLocaleString()} Room XP
                    {giftBanner.roomLeveledUp ? ` · Room Leveled Up to Lv.${giftBanner.newRoomLevel}!` : ''}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. ROOM TYPE INTERACTIVE STAGE MODULE (INTEGRATED IN SAME BACKGROUND) */}
          {roomType === 'YouTube Room' && (
            <div className="relative z-10 mx-4 sm:mx-6 mt-3 rounded-2xl bg-black/35 border border-violet-300/25 p-3 space-y-3">
              <div className="flex items-center gap-2 text-white">
                <Video className="w-4 h-4 text-violet-300" />
                <div>
                  <div className="text-xs font-bold">ZYRO Watch Together</div>
                  <div className="text-[11px] text-violet-200/80">Paste a public YouTube video link to watch in this room</div>
                </div>
              </div>
              <form className="flex gap-2" onSubmit={(e) => {
                e.preventDefault();
                const match = youtubeInput.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
                if (match) setYoutubeEmbed(`https://www.youtube-nocookie.com/embed/${match[1]}`);
              }}>
                <input value={youtubeInput} onChange={(e) => setYoutubeInput(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className="min-w-0 flex-1 rounded-xl bg-white/10 border border-white/15 px-3 py-2 text-xs text-white placeholder:text-white/45 outline-none" />
                <button className="rounded-xl bg-violet-500 px-4 py-2 text-xs font-bold text-white">Play</button>
              </form>
              {youtubeEmbed && <div className="aspect-video overflow-hidden rounded-xl border border-white/10 bg-black"><iframe title="ZYRO YouTube Watch Room" src={youtubeEmbed} className="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen /></div>}
            </div>
          )}

          {roomType === 'Game Room' && (
            <div className="relative z-10 mx-4 sm:mx-6 mt-3 rounded-2xl bg-black/30 border border-emerald-300/20 p-3 flex flex-wrap items-center justify-between gap-2.5">
              <div className="flex items-center gap-2 text-xs text-emerald-100 font-semibold">
                <Gamepad2 className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>Squad Game Lobby · Pick a quick match callout:</span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {(['Carrom', 'Uno', 'Star Mic', 'Spy'] as const).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => onSendChat(`🎮 Who’s ready for a ${g} squad match? Take a seat!`)}
                    className="h-8 px-2.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/35 border border-emerald-300/25 text-[11px] font-semibold text-emerald-100 whitespace-nowrap transition-colors"
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 3. 10-SEAT STAGE: 2 TOP (OWNER & OWNER PARTNER) + 2 LINES OF 4 SEATS */}
          <div className="relative z-10 px-4 sm:px-6 py-4 space-y-4">
            {/* Top 2 Seats: Owner & Owner Partner */}
            <div className="flex items-start justify-center gap-10 sm:gap-16 pb-3 border-b border-white/10">
              {topSeats.map((seat) => renderSeat(seat, true))}
            </div>

            {/* Line 1: 4 Seats */}
            <div className="grid grid-cols-4 gap-2 sm:gap-4 max-w-2xl mx-auto">
              {firstFourRow.map((seat) => renderSeat(seat, false))}
            </div>

            {/* Line 2: 4 Seats */}
            <div className="grid grid-cols-4 gap-2 sm:gap-4 max-w-2xl mx-auto">
              {secondFourRow.map((seat) => renderSeat(seat, false))}
            </div>
            {/* Line 3: remaining 3 seats (12 speaker seats total including partner seat) */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 max-w-lg mx-auto">
              {thirdRow.map((seat) => renderSeat(seat, false))}
            </div>
          </div>

          {/* 4. INTEGRATED CHAT AREA (PART OF SAME COHESIVE BACKGROUND) */}
          <div className="relative z-10 flex-1 flex flex-col bg-black/25 border-t border-white/10 min-h-[210px] max-h-[290px]">
            <div className="px-4 sm:px-6 py-2 flex items-center justify-between text-[11px] text-white/60 border-b border-white/5">
              <span className="font-semibold text-white/85">Live Room Chat</span>
              <span className="font-mono-num">Coins: {user.coins.toLocaleString()}</span>
            </div>

            <div ref={chatScrollRef} className="flex-1 overflow-y-auto px-4 sm:px-6 py-3 space-y-2 thin-scroll">
              {roomMessages.map((msg) => {
                const effect = SHOP_ITEMS.find((i) => i.id === msg.chatEffect);
                if (msg.type === 'system' || msg.type === 'join') {
                  return (
                    <div
                      key={msg.id}
                      className="text-xs text-indigo-100 bg-white/10 border border-white/10 rounded-xl px-3 py-1.5"
                    >
                      <span className="font-bold text-white">{msg.userName}</span>{' '}
                      {msg.vipLevel > 0 && (
                        <span className="text-amber-300 font-semibold">(VIP {msg.vipLevel}) </span>
                      )}
                      <span className="text-white/85">{msg.text}</span>
                    </div>
                  );
                }
                if (msg.type === 'gift') {
                  return (
                    <div
                      key={msg.id}
                      className="text-xs font-semibold text-amber-100 bg-gradient-to-r from-rose-500/30 to-amber-500/25 border border-amber-300/30 rounded-xl px-3 py-1.5"
                    >
                      {msg.userName} {msg.text} (+{msg.giftCoins?.toLocaleString()} XP)
                    </div>
                  );
                }
                return (
                  <div key={msg.id} className="flex items-start gap-2.5">
                    <AvatarBadge dp={msg.userDp} name={msg.userName} vipLevel={msg.vipLevel} size="xs" />
                    <div className="min-w-0">
                      <div className="text-[11px] font-semibold text-white/70 mb-0.5">
                        {msg.userName} {msg.vipLevel > 0 ? `· VIP ${msg.vipLevel}` : ''}
                      </div>
                      <div
                        className={`inline-block rounded-2xl px-3 py-1.5 text-xs ${
                          effect ? effect.previewClass : 'bg-white/15 text-white border border-white/10'
                        }`}
                      >
                        {msg.text}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 5. EXPANDABLE EMOTE / GIFT TRAY ABOVE BOTTOM BAR (IN SAME BACKGROUND) */}
          {activeTray === 'emotes' && (
            <div className="relative z-10 bg-black/45 backdrop-blur-md border-t border-white/15 px-4 sm:px-6 py-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-amber-200">Quick Stage Emotes</span>
                <button
                  type="button"
                  onClick={() => setActiveTray('none')}
                  className="text-xs text-white/60 hover:text-white"
                >
                  Close
                </button>
              </div>
              <div className="grid grid-cols-6 gap-2">
                {PARTY_EMOTES.map((em) => (
                  <button
                    key={em.id}
                    type="button"
                    onClick={() => {
                      onSendEmote(em.emoji);
                      setActiveTray('none');
                    }}
                    className="py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-center transition-colors"
                  >
                    <div className="text-xl">{em.emoji}</div>
                    <div className="text-[10px] font-semibold text-white/80">{em.label}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTray === 'gifts' && (
            <div className="relative z-10 bg-black/45 backdrop-blur-md border-t border-white/15 px-4 sm:px-6 py-3 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white/80">Send To:</span>
                  <select
                    value={selectedRecipientId}
                    onChange={(e) => setSelectedRecipientId(e.target.value)}
                    className="rounded-lg bg-slate-900 border border-white/20 px-2.5 py-1 text-xs text-white focus:outline-none"
                  >
                    {seatedTargets.map((s) => (
                      <option key={s.seatIndex} value={s.userId!}>
                        {s.userName} {s.seatIndex === 0 ? '(Owner)' : `(Seat ${s.seatIndex + 1})`}
                      </option>
                    ))}
                    {seatedTargets.length === 0 && (
                      <option value={activeRoom.ownerId}>{activeRoom.ownerName} (Owner)</option>
                    )}
                  </select>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono-num text-amber-300 font-bold">
                    {user.coins.toLocaleString()} Coins
                  </span>
                  <button
                    type="button"
                    onClick={onOpenTopUp}
                    className="text-xs font-bold text-amber-300 hover:underline"
                  >
                    + Top Up
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTray('none')}
                    className="text-xs text-white/60 hover:text-white"
                  >
                    Close
                  </button>
                </div>
              </div>

              <div className="text-[11px] text-amber-200/90 font-medium">
                Every 5 coins gifted = +1 Charm on your ID · Larger gifts return up to 35% coins &amp; grow VIP
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-7 gap-2">
                {GIFT_CATALOG.map((gift) => (
                  <button
                    key={gift.id}
                    type="button"
                    onClick={() => onSendGift(gift.id, selectedRecipientId || activeRoom.ownerId)}
                    className="p-2 rounded-xl bg-white/10 hover:bg-rose-500/30 border border-white/15 hover:border-rose-300/50 text-center transition-colors"
                  >
                    <div className="text-xl">{gift.emoji}</div>
                    <div className="text-[11px] font-semibold text-white truncate mt-0.5">{gift.name}</div>
                    <div className="font-mono-num text-[10px] font-bold text-amber-300">{gift.coins}</div>
                    <div className="font-mono-num text-[9px] text-emerald-300">
                      +{computeGiftCharm(gift.coins)}✨ · +{gift.coinReturn}↩
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTray === 'invite' && (
            <div className="relative z-10 bg-black/45 backdrop-blur-md border-t border-white/15 px-4 sm:px-6 py-3 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-indigo-200">Invite Friends to {activeRoom.title}</span>
                <button
                  type="button"
                  onClick={() => setActiveTray('none')}
                  className="text-xs text-white/60 hover:text-white"
                >
                  Close
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto thin-scroll">
                {friends.map((friend) => {
                  const sent = invitedFriendIds.includes(friend.id);
                  return (
                    <div
                      key={friend.id}
                      className="rounded-xl bg-white/10 border border-white/10 px-3 py-2 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <AvatarBadge dp={friend.dp} name={friend.name} vipLevel={friend.vipLevel} size="xs" />
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-white truncate">{friend.name}</div>
                          <div className="font-mono-num text-[10px] text-white/70 truncate">
                            UID {friend.id} · VIP {friend.vipLevel} · ✨ {friend.charmPoints.toLocaleString()} Charm
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        disabled={sent}
                        onClick={async () => {
                          const err = await onInviteFriend(activeRoom.id, friend.id);
                          if (!err) {
                            setInvitedFriendIds((prev) => [...prev, friend.id]);
                          }
                        }}
                        className={`h-8 px-3 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 ${
                          sent
                            ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/30'
                            : 'bg-indigo-500 hover:bg-indigo-400 text-white'
                        }`}
                      >
                        {sent ? <Check className="w-3 h-3" /> : <UserPlus className="w-3 h-3" />}
                        <span>{sent ? 'Invited' : 'Invite'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 6. VERY BOTTOM: CHAT INPUT + MIC + EMOTE + GIFT OPTIONS */}
          <div className="relative z-10 bg-black/40 border-t border-white/15 px-3 sm:px-5 py-3 flex items-center gap-2">
            <form onSubmit={handleSendChatSubmit} className="flex-1 flex items-center gap-2 min-w-0">
              <input
                type="text"
                value={chatText}
                onChange={(e) => setChatText(e.target.value)}
                placeholder="Chat with the room..."
                maxLength={200}
                className="flex-1 min-w-0 h-11 px-3.5 rounded-xl bg-white/10 border border-white/15 text-sm text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-amber-400/70"
              />
              <button
                type="submit"
                aria-label="Send message"
                className="w-11 h-11 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white flex items-center justify-center shrink-0 transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            {/* Mic Mute / Live Mic Toggle */}
            <button
              type="button"
              onClick={mySeat ? onToggleMute : undefined}
              disabled={!mySeat}
              title={!mySeat ? 'Take a seat to speak' : mySeat.isMuted ? 'Unmute Mic' : 'Mute Mic'}
              aria-label="Toggle microphone"
              className={`w-11 h-11 rounded-xl flex items-center justify-center border shrink-0 transition-colors ${
                !mySeat
                  ? 'bg-white/5 text-white/35 border-white/10 cursor-not-allowed'
                  : mySeat.isMuted
                  ? 'bg-rose-500/25 text-rose-200 border-rose-400/40'
                  : 'bg-emerald-500/25 text-emerald-200 border-emerald-400/40'
              }`}
            >
              {mySeat?.isMuted || !mySeat ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={handleToggleRealAudioMic}
              disabled={!mySeat}
              title={liveMicActive ? 'Voice Sensor Live' : 'Enable Voice Sensor'}
              aria-label="Toggle live audio sensor"
              className={`hidden sm:flex w-11 h-11 rounded-xl items-center justify-center border shrink-0 transition-colors ${
                liveMicActive
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                  : 'bg-white/10 text-white/80 border-white/15 hover:bg-white/20 disabled:opacity-35'
              }`}
            >
              <Radio className="w-4 h-4" />
            </button>

            {/* Emote Option */}
            <button
              type="button"
              onClick={() => setActiveTray((t) => (t === 'emotes' ? 'none' : 'emotes'))}
              aria-label="Open Emotes"
              className={`h-11 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border shrink-0 whitespace-nowrap transition-colors ${
                activeTray === 'emotes'
                  ? 'bg-amber-400 text-slate-950 border-amber-300'
                  : 'bg-white/10 hover:bg-white/20 text-amber-200 border-white/15'
              }`}
            >
              <Smile className="w-4 h-4" />
              <span className="hidden sm:inline">Emote</span>
            </button>

            {/* Gift Option */}
            <button
              type="button"
              onClick={() => setActiveTray((t) => (t === 'gifts' ? 'none' : 'gifts'))}
              aria-label="Send Gift"
              className={`h-11 px-3.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shrink-0 whitespace-nowrap transition-colors ${
                activeTray === 'gifts'
                  ? 'bg-rose-500 text-white ring-2 ring-rose-300'
                  : 'bg-gradient-to-r from-rose-500 to-amber-500 hover:brightness-110 text-white'
              }`}
            >
              <Gift className="w-4 h-4" />
              <span>Gift</span>
            </button>
          </div>
        </section>
      </div>
    );
  }

  // ---- ROOM DIRECTORY VIEW ----
  const cleanQuery = uidQuery.trim().toLowerCase();

  const matchingFriends = cleanQuery
    ? friends.filter(
        (f) =>
          f.id.toLowerCase().includes(cleanQuery) ||
          f.name.toLowerCase().includes(cleanQuery)
      )
    : [];

  const getTagCount = (cat: 'All' | VoiceRoom['category']) => {
    if (cat === 'All') return rooms.length;
    if (cat === 'Friend') {
      return rooms.filter(
        (r) =>
          r.category === 'Friend' ||
          user.friends.includes(r.ownerId) ||
          r.seats.some((s) => s.userId && user.friends.includes(s.userId))
      ).length;
    }
    return rooms.filter((r) => r.category === cat).length;
  };

  const filteredRooms = rooms.filter((r) => {
    const matchesCategory =
      categoryFilter === 'All'
        ? true
        : categoryFilter === 'Friend'
        ? r.category === 'Friend' ||
          user.friends.includes(r.ownerId) ||
          r.seats.some((s) => s.userId && user.friends.includes(s.userId))
        : r.category === categoryFilter;

    if (!matchesCategory) return false;
    if (!cleanQuery) return true;

    return (
      r.ownerId.toLowerCase().includes(cleanQuery) ||
      r.ownerName.toLowerCase().includes(cleanQuery) ||
      r.title.toLowerCase().includes(cleanQuery) ||
      r.seats.some(
        (s) =>
          (s.userId && s.userId.toLowerCase().includes(cleanQuery)) ||
          (s.userName && s.userName.toLowerCase().includes(cleanQuery))
      )
    );
  });

  return (
    <div className="max-w-5xl mx-auto px-4 pt-4 pb-28 space-y-5">
      {/* Top Bar: Title + UID Search Input */}
      <div className="space-y-3">
        <div>
          <h2 className="font-display text-2xl font-extrabold text-slate-900">Voice Rooms</h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Search a friend by UID, pick a room tag, or launch your own 10-seat stage.
          </p>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={uidQuery}
            onChange={(e) => setUidQuery(e.target.value)}
            placeholder="Enter friend's UID (e.g. 8011204) or name to find them..."
            className="w-full h-12 pl-11 pr-10 rounded-2xl bg-white border border-slate-200 shadow-sm text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          {uidQuery && (
            <button
              type="button"
              onClick={() => setUidQuery('')}
              aria-label="Clear UID search"
              className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 absolute right-2 top-1/2 -translate-y-1/2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Friend UID Search Results */}
        {cleanQuery && (
          <div className="bg-white rounded-2xl border border-indigo-200 p-4 shadow-sm space-y-2.5">
            <div className="text-xs font-semibold text-indigo-700">
              Friend Lookup ({matchingFriends.length})
            </div>
            {matchingFriends.length === 0 ? (
              <div className="text-xs text-slate-500">
                No player found matching UID or name “{uidQuery}”.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {matchingFriends.map((friend) => {
                  const seatedRoom = rooms.find(
                    (r) =>
                      r.id === friend.currentRoomId ||
                      r.ownerId === friend.id ||
                      r.seats.some((s) => s.userId === friend.id)
                  );
                  return (
                    <div
                      key={friend.id}
                      className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <AvatarBadge dp={friend.dp} name={friend.name} vipLevel={friend.vipLevel} size="sm" />
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">{friend.name}</div>
                          <div className="font-mono-num text-[11px] text-slate-500 truncate">
                            UID {friend.id} · VIP {friend.vipLevel} · ✨ {friend.charmPoints.toLocaleString()} Charm
                          </div>
                        </div>
                      </div>
                      {seatedRoom ? (
                        <button
                          onClick={() => onJoinRoom(seatedRoom.id)}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-semibold whitespace-nowrap shrink-0"
                        >
                          Join Room
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500 whitespace-nowrap shrink-0">
                          {friend.currentActivity}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Create Room + Single-Line Room Tags Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <button
          onClick={() => setShowCreateModal(true)}
          className="h-11 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm inline-flex items-center justify-center gap-2 shadow-sm transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4 shrink-0" />
          <span>Create Room</span>
          <span className="font-mono-num text-[11px] text-indigo-100">(200)</span>
        </button>

        {/* Single-Line Room Tags */}
        <div className="bg-white rounded-2xl border border-slate-200 p-1.5 shadow-sm flex items-center gap-1.5 overflow-x-auto flex-nowrap min-w-0">
          <div className="px-2 flex items-center gap-1 text-xs font-bold text-slate-500 whitespace-nowrap shrink-0">
            <Tag className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden sm:inline">Tags:</span>
          </div>
          {(['All', ...VOICE_ROOM_CATEGORIES] as const).map((cat) => {
            const count = getTagCount(cat);
            const active = categoryFilter === cat;
            return (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`h-9 px-3 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>{cat}</span>
                <span className={`font-mono-num text-[11px] ${active ? 'text-indigo-100' : 'text-slate-400'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Room Cards Grid */}
      {filteredRooms.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center space-y-3">
          <div className="font-display text-base font-bold text-slate-900">
            No matching {categoryFilter === 'All' ? '' : `${categoryFilter} `}voice rooms found
          </div>
          <p className="text-xs text-slate-500">
            Try another room tag, clear your UID search, or create a new room for 200 Coins.
          </p>
          <button
            onClick={() => {
              setNewCategory(categoryFilter === 'All' ? 'Friend' : categoryFilter);
              setShowCreateModal(true);
            }}
            className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Create {categoryFilter === 'All' ? 'Voice' : categoryFilter} Room</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredRooms.map((room) => {
            const seatedCount = room.seats.filter((s) => s.userId !== null).length;
            return (
              <div
                key={room.id}
                className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 gap-2">
                    <span className="inline-flex items-center gap-1.5 font-semibold text-indigo-600 truncate">
                      <span>{room.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num">Lv.{room.level}</span>
                    </span>
                    <span className="inline-flex items-center gap-1 font-mono-num shrink-0">
                      <Users className="w-3.5 h-3.5" /> {seatedCount}/10
                    </span>
                  </div>

                  <h3 className="mt-2 font-display text-lg font-bold text-slate-900 leading-snug">
                    {room.title}
                  </h3>

                  <div className="mt-4 flex items-center gap-3">
                    <AvatarBadge
                      dp={room.ownerDp}
                      name={room.ownerName}
                      vipLevel={room.ownerVipLevel}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-800 truncate">
                        Host: {room.ownerName} · UID {room.ownerId}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {room.listenersCount} online · {room.xpCoins.toLocaleString()} XP
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onJoinRoom(room.id)}
                  className="w-full h-11 rounded-xl bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Enter Voice Room</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Room Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-display text-lg font-bold text-slate-900">Create Voice Room</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
              {createError && (
                <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-2.5 text-xs font-semibold text-rose-700">
                  {createError}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Room Name</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Friday Karaoke & Chill"
                  maxLength={42}
                  className="w-full h-11 px-4 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Room Tag</label>
                <div className="grid grid-cols-4 gap-2">
                  {VOICE_ROOM_CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setNewCategory(cat)}
                      className={`py-2 rounded-xl text-xs font-semibold border ${
                        newCategory === cat
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-white text-slate-700 border-slate-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900 flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 font-semibold">
                  <Coins className="w-4 h-4 text-amber-600" />
                  Creation Fee: 200 Coins
                </span>
                <span>Change room mode anytime inside</span>
              </div>

              <button
                type="submit"
                disabled={creating}
                className="w-full h-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm disabled:opacity-60"
              >
                {creating ? 'Opening Room...' : 'Spend 200 Coins & Launch Room'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
