import React, { useState } from 'react';
import {
  Crown,
  Edit3,
  Lock,
  LogOut,
  Play,
  Shield,
  ShoppingBag,
  Sparkles,
  Upload,
  Check,
  Coins,
  Eye,
} from 'lucide-react';
import {
  AVATAR_PRESETS,
  ParentalControls,
  PrivacySettings,
  REAL_PFP_PRESETS,
  SHOP_ITEMS,
  UserProfile,
  VIP_TIERS,
} from '../shared/types';
import { AvatarBadge } from './AvatarBadge';
import { playCoinChime } from '../utils/sound';

const ID_STYLE_THEMES: Record<
  NonNullable<UserProfile['idStyle']>,
  { label: string; cardBg: string; subText: string; divider: string; swatch: string }
> = {
  royal: {
    label: 'Royal Indigo',
    cardBg: 'bg-gradient-to-br from-indigo-700 via-indigo-800 to-slate-900 text-white border-indigo-400/30',
    subText: 'text-indigo-200',
    divider: 'border-white/15',
    swatch: 'from-indigo-600 to-slate-900',
  },
  obsidian: {
    label: 'Obsidian Gold',
    cardBg: 'bg-gradient-to-br from-slate-900 via-zinc-900 to-slate-950 text-white border-amber-400/35',
    subText: 'text-amber-200/90',
    divider: 'border-amber-300/20',
    swatch: 'from-slate-900 to-amber-700',
  },
  emerald: {
    label: 'Emerald Luxe',
    cardBg: 'bg-gradient-to-br from-emerald-700 via-teal-800 to-slate-900 text-white border-emerald-300/30',
    subText: 'text-emerald-100',
    divider: 'border-white/15',
    swatch: 'from-emerald-600 to-slate-900',
  },
  sunset: {
    label: 'Sunset Velvet',
    cardBg: 'bg-gradient-to-br from-rose-600 via-fuchsia-800 to-slate-900 text-white border-rose-300/30',
    subText: 'text-rose-100',
    divider: 'border-white/15',
    swatch: 'from-rose-500 to-purple-900',
  },
};

interface MeTabProps {
  user: UserProfile;
  onUpdateProfile: (payload: Record<string, unknown>) => Promise<string | null>;
  onBuyShopItem: (itemId: string) => Promise<string | null>;
  onEquipShopItem: (type: 'chat_effect' | 'entry_effect', itemId: string) => Promise<string | null>;
  onUpgradeVip: (coins: number) => Promise<string | null>;
  onPreviewVipEntry: (vipLevel: number, customRideId?: string) => void;
  onOpenTopUp: () => void;
  onLogout: () => void;
}

export const MeTab: React.FC<MeTabProps> = ({
  user,
  onUpdateProfile,
  onBuyShopItem,
  onEquipShopItem,
  onUpgradeVip,
  onPreviewVipEntry,
  onOpenTopUp,
  onLogout,
}) => {
  const [subTab, setSubTab] = useState<'profile' | 'vip' | 'shop' | 'settings'>('profile');
  const [nameInput, setNameInput] = useState(user.name);
  const [bioInput, setBioInput] = useState(user.bio);
  const [dpInput, setDpInput] = useState(user.dp);
  const [idStyleInput, setIdStyleInput] = useState<NonNullable<UserProfile['idStyle']>>(user.idStyle || 'royal');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [privacy, setPrivacy] = useState<PrivacySettings>(user.privacy);
  const [parental, setParental] = useState<ParentalControls>(user.parental);
  const [pinAttempt, setPinAttempt] = useState('');

  const currentVip = VIP_TIERS[Math.min(14, user.vipLevel)];
  const nextVip = user.vipLevel < 14 ? VIP_TIERS[user.vipLevel + 1] : null;
  const activeStyle = ID_STYLE_THEMES[user.idStyle || 'royal'];
  const previewStyle = ID_STYLE_THEMES[idStyleInput];
  const vipProgress = nextVip
    ? Math.min(
        100,
        Math.max(
          4,
          Math.round(
            ((user.totalCoinsSpent - currentVip.minSpend) /
              Math.max(1, nextVip.minSpend - currentVip.minSpend)) *
              100
          )
        )
      )
    : 100;

  const notify = (okMsg: string | null, err: string | null) => {
    setFeedback(okMsg);
    setErrorMsg(err);
  };

  const handleUploadDp = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 240;
        canvas.height = 240;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const minDim = Math.min(img.width, img.height);
          const sx = (img.width - minDim) / 2;
          const sy = (img.height - minDim) / 2;
          ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, 240, 240);
          setDpInput(canvas.toDataURL('image/jpeg', 0.85));
        }
      };
      if (typeof reader.result === 'string') img.src = reader.result;
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = await onUpdateProfile({
      name: nameInput,
      bio: bioInput,
      dp: dpInput,
      idStyle: idStyleInput,
    });
    if (err) notify(null, err);
    else notify('Profile, Real PFP & Signature ID updated!', null);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = await onUpdateProfile({
      privacy,
      parental: { ...parental, pinAttempt },
    });
    if (err) notify(null, err);
    else {
      setPinAttempt('');
      notify('Privacy & Parental Controls saved!', null);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 pt-4 pb-28 space-y-5">
      {/* Signature Profile & ID Card Hero */}
      <div className={`rounded-3xl border p-6 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-5 ${activeStyle.cardBg}`}>
        <div className="flex items-center gap-4 min-w-0">
          <AvatarBadge dp={user.dp} name={user.name} vipLevel={user.vipLevel} size="xl" />
          <div className="min-w-0">
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight truncate">
              {user.name}
            </h2>
            <div className={`mt-1 text-xs sm:text-sm font-mono-num flex flex-wrap items-center gap-x-2.5 gap-y-1 ${activeStyle.subText}`}>
              <span className="font-bold text-white">ID {user.id}</span>
              <span aria-hidden="true">·</span>
              <span className="font-bold text-amber-300">
                VIP {user.vipLevel} ({currentVip.name.replace(/^VIP \d+ · /, '')})
              </span>
              <span className="font-extrabold text-rose-300">
                ✨ {user.charmPoints.toLocaleString()} Charm
              </span>
            </div>
            <div className={`mt-2 pt-2 border-t text-xs font-mono-num flex flex-wrap items-center gap-x-3 gap-y-1 ${activeStyle.divider} ${activeStyle.subText}`}>
              <span className="font-semibold text-amber-300">{user.coins.toLocaleString()} Coins</span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-white">{user.cpPoints.toLocaleString()} CP</span>
              <span aria-hidden="true">·</span>
              <span>{user.winsCount} Wins</span>
            </div>
            <p className="mt-2 text-xs sm:text-sm text-white/85 line-clamp-2">{user.bio}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenTopUp}
            className="h-10 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold inline-flex items-center gap-1.5"
          >
            <Coins className="w-4 h-4" />
            <span>Top Up</span>
          </button>
          <button
            onClick={onLogout}
            className="h-10 px-3.5 rounded-xl bg-white/10 hover:bg-rose-500/80 border border-white/20 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Sub Navigation Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1.5 bg-slate-200/70 rounded-2xl">
        <button
          onClick={() => setSubTab('profile')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 ${
            subTab === 'profile' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
          }`}
        >
          <Edit3 className="w-4 h-4" />
          <span>Edit Profile & DP</span>
        </button>
        <button
          onClick={() => setSubTab('vip')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 ${
            subTab === 'vip' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
          }`}
        >
          <Crown className="w-4 h-4 text-amber-500" />
          <span>VIP 1–14</span>
        </button>
        <button
          onClick={() => setSubTab('shop')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 ${
            subTab === 'shop' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
          }`}
        >
          <ShoppingBag className="w-4 h-4 text-indigo-600" />
          <span>Shop & Effects</span>
        </button>
        <button
          onClick={() => setSubTab('settings')}
          className={`py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 ${
            subTab === 'settings' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
          }`}
        >
          <Shield className="w-4 h-4 text-emerald-600" />
          <span>Privacy & Parental</span>
        </button>
      </div>

      {feedback && (
        <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs font-semibold text-emerald-800">
          {feedback}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-2xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs font-semibold text-rose-700">
          {errorMsg}
        </div>
      )}

      {/* 1. PROFILE EDITOR: REAL PFP, APPEALING NAME & SIGNATURE ID */}
      {subTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-4">
                <AvatarBadge dp={dpInput} name={nameInput} vipLevel={user.vipLevel} size="xl" />
                <div>
                  <div className="font-display text-sm font-bold text-slate-900">Real Profile Photo (PFP)</div>
                  <p className="text-xs text-slate-500 mt-0.5">Upload a real portrait or pick a studio PFP.</p>
                  <label className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-xs font-semibold text-indigo-700 cursor-pointer border border-indigo-200">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Real Photo</span>
                    <input type="file" accept="image/*" onChange={handleUploadDp} className="hidden" />
                  </label>
                </div>
              </div>

              <div>
                <div className="text-xs font-semibold text-slate-700 mb-2">Studio Portrait PFPs</div>
                <div className="grid grid-cols-4 gap-2.5">
                  {REAL_PFP_PRESETS.map((pfp) => (
                    <button
                      key={pfp.id}
                      type="button"
                      onClick={() => setDpInput(pfp.id)}
                      className={`p-1.5 rounded-2xl border flex flex-col items-center gap-1 transition-all ${
                        dpInput === pfp.id
                          ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-200'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <img
                        src={pfp.imageUrl}
                        alt={pfp.label}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover"
                      />
                      <span className="text-[10px] font-semibold text-slate-600 truncate w-full text-center">
                        {pfp.label.split(' ')[0]}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-semibold text-slate-700 mb-2">Classic Avatars</div>
                <div className="grid grid-cols-4 gap-2">
                  {AVATAR_PRESETS.map((av) => (
                    <button
                      key={av.id}
                      type="button"
                      onClick={() => setDpInput(av.id)}
                      className={`p-1.5 rounded-2xl border flex flex-col items-center gap-1 transition-all ${
                        dpInput === av.id
                          ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-200'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <span className={`w-9 h-9 rounded-full bg-gradient-to-br ${av.bg} flex items-center justify-center text-lg`}>
                        {av.emoji}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-600 truncate w-full text-center">
                        {av.label.split(' ')[1]}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="md:col-span-7 space-y-4">
              {/* Live Signature ID Card Preview */}
              <div className={`rounded-2xl border p-4 ${previewStyle.cardBg}`}>
                <div className={`text-[11px] font-semibold mb-2 ${previewStyle.subText}`}>
                  Live ID Card Preview
                </div>
                <div className="flex items-center gap-3.5">
                  <AvatarBadge dp={dpInput} name={nameInput || user.name} vipLevel={user.vipLevel} size="md" />
                  <div className="min-w-0">
                    <div className="font-display text-base font-extrabold text-white truncate">
                      {nameInput || 'Your Name'}
                    </div>
                    <div className={`text-xs font-mono-num ${previewStyle.subText}`}>
                      ID {user.id} · <span className="text-amber-300 font-bold">VIP {user.vipLevel}</span>{' '}
                      <span className="text-rose-300 font-bold">✨ {user.charmPoints.toLocaleString()} Charm</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  ID Appeal Theme
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(Object.keys(ID_STYLE_THEMES) as NonNullable<UserProfile['idStyle']>[]).map((key) => {
                    const theme = ID_STYLE_THEMES[key];
                    const selected = idStyleInput === key;
                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => setIdStyleInput(key)}
                        className={`p-2 rounded-xl border text-left flex items-center gap-2 transition-all ${
                          selected ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className={`w-5 h-5 rounded-full bg-gradient-to-br ${theme.swatch} shrink-0`} />
                        <span className="text-xs font-semibold text-slate-800 truncate">{theme.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Display Name</label>
                <input
                  type="text"
                  required
                  minLength={2}
                  maxLength={28}
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full h-11 px-4 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Bio</label>
                <textarea
                  rows={3}
                  maxLength={160}
                  value={bioInput}
                  onChange={(e) => setBioInput(e.target.value)}
                  placeholder="Tell your friends what games you love..."
                  className="w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                />
                <div className="text-right text-[11px] text-slate-400 mt-1">{bioInput.length}/160</div>
              </div>

              <button
                type="submit"
                className="h-11 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm"
              >
                Save Profile &amp; ID Style
              </button>
            </div>
          </div>
        </form>
      )}

      {/* 2. VIP 1-14 PROGRESSION & ENTRY ANIMATION SHOWCASE */}
      {subTab === 'vip' && (
        <div className="space-y-5">
          <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-6 shadow-xl border border-indigo-400/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs text-amber-300 font-semibold">
                  VIP Progression System (Levels 1 – 14) · Charm ✨ {user.charmPoints.toLocaleString()}
                </div>
                <h3 className="font-display text-2xl font-extrabold mt-1">
                  {currentVip.name} — {currentVip.entryTitle}
                </h3>
                <p className="text-xs text-indigo-200 mt-1">
                  Total Coins Spent &amp; Gifted: <span className="font-mono-num font-bold text-white">{user.totalCoinsSpent.toLocaleString()}</span>
                  {nextVip ? ` · ${(nextVip.minSpend - user.totalCoinsSpent).toLocaleString()} more coins to ${nextVip.name}` : ' · Maximum VIP Rank Achieved!'}
                </p>
                <p className="text-xs text-emerald-300 mt-1.5">
                  Every 5 coins gifted adds +1 Charm to your ID · Larger gifts return up to 35% coins and grow your VIP rank!
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {nextVip && (
                  <button
                    onClick={async () => {
                      const needed = Math.min(user.coins, nextVip.minSpend - user.totalCoinsSpent);
                      const spendAmt = needed > 0 ? needed : 100;
                      const err = await onUpgradeVip(spendAmt);
                      if (err) notify(null, err);
                      else {
                        playCoinChime();
                        notify(`Spent ${spendAmt.toLocaleString()} Coins toward VIP progression!`, null);
                      }
                    }}
                    className="h-10 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold whitespace-nowrap"
                  >
                    Spend Coins to Level Up
                  </button>
                )}
                <button
                  onClick={onOpenTopUp}
                  className="h-10 px-4 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold whitespace-nowrap"
                >
                  Top Up Coins
                </button>
              </div>
            </div>

            <div className="mt-4 w-full h-3 rounded-full bg-white/15 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 via-rose-400 to-indigo-400 transition-all duration-500"
                style={{ width: `${vipProgress}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {VIP_TIERS.filter((t) => t.level >= 1).map((tier) => {
              const unlocked = user.vipLevel >= tier.level;
              const isEquipped =
                user.equippedEntryEffect === `vip_${tier.level}` ||
                (user.equippedEntryEffect === 'auto-vip' && user.vipLevel === tier.level);

              return (
                <div
                  key={tier.level}
                  className={`rounded-3xl border p-5 flex flex-col justify-between gap-4 transition-all ${
                    unlocked
                      ? 'bg-white border-slate-200 shadow-sm'
                      : 'bg-slate-50 border-slate-200/70 opacity-85'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className="px-2.5 py-1 rounded-lg text-xs font-bold text-white"
                        style={{ backgroundColor: tier.primaryColor }}
                      >
                        VIP {tier.level}
                      </span>
                      <span className="font-mono-num text-[11px] font-semibold text-slate-500">
                        {tier.minSpend.toLocaleString()} Coins Spent
                      </span>
                    </div>
                    <h4 className="font-display text-base font-bold text-slate-900 mt-3">
                      {tier.entryTitle}
                    </h4>
                    <p className="text-xs text-slate-600 mt-1">{tier.perkSummary}</p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => onPreviewVipEntry(tier.level)}
                      className="flex-1 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Preview</span>
                    </button>

                    {unlocked ? (
                      <button
                        onClick={async () => {
                          const err = await onEquipShopItem('entry_effect', `vip_${tier.level}`);
                          if (err) notify(null, err);
                          else notify(`Equipped VIP ${tier.level} (${tier.entryTitle}) entry!`, null);
                        }}
                        className={`flex-1 h-9 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-1 ${
                          isEquipped
                            ? 'bg-emerald-600 text-white'
                            : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                        }`}
                      >
                        {isEquipped && <Check className="w-3.5 h-3.5" />}
                        <span>{isEquipped ? 'Equipped' : 'Equip'}</span>
                      </button>
                    ) : (
                      <span className="flex-1 h-9 rounded-xl bg-slate-100 text-slate-400 text-xs font-semibold inline-flex items-center justify-center gap-1">
                        <Lock className="w-3.5 h-3.5" />
                        <span>Locked</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. SHOP: CHAT EFFECTS & ENTRY RIDES */}
      {subTab === 'shop' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-lg font-bold text-slate-900">Chat Bubble Effects</h3>
                <p className="text-xs text-slate-500">Stand out in Voice Room chats. Purchases count toward VIP 1–14!</p>
              </div>
              <span className="font-mono-num text-xs font-bold text-amber-600">{user.coins.toLocaleString()} Coins</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SHOP_ITEMS.filter((i) => i.category === 'chat_effect').map((item) => {
                const owned = user.ownedChatEffects.includes(item.id);
                const equipped = user.equippedChatEffect === item.id;
                return (
                  <div key={item.id} className="rounded-2xl border border-slate-200 p-4 flex flex-col justify-between gap-3">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-display font-bold text-sm text-slate-900">{item.name}</span>
                        <span className="font-mono-num text-xs font-bold text-amber-600">
                          {item.price === 0 ? 'Free' : `${item.price} Coins`}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{item.description}</p>
                      <div className="mt-3">
                        <span className={`inline-block rounded-2xl px-3.5 py-2 text-xs ${item.previewClass}`}>
                          Hello Voice Room! ✨
                        </span>
                      </div>
                    </div>

                    {owned ? (
                      <button
                        onClick={async () => {
                          const err = await onEquipShopItem('chat_effect', item.id);
                          if (err) notify(null, err);
                          else notify(`Equipped ${item.name} chat effect!`, null);
                        }}
                        className={`h-10 rounded-xl text-xs font-semibold ${
                          equipped
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-900 hover:bg-slate-800 text-white'
                        }`}
                      >
                        {equipped ? 'Equipped' : 'Equip Chat Effect'}
                      </button>
                    ) : (
                      <button
                        onClick={async () => {
                          const err = await onBuyShopItem(item.id);
                          if (err) notify(null, err);
                          else {
                            playCoinChime();
                            notify(`Purchased & equipped ${item.name}!`, null);
                          }
                        }}
                        className="h-10 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                      >
                        Buy for {item.price} Coins
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div>
              <h3 className="font-display text-lg font-bold text-slate-900">Special Entry Animations & Rides</h3>
              <p className="text-xs text-slate-500">Equip special arrival rides or use your VIP 1–14 entry animation.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {SHOP_ITEMS.filter((i) => i.category === 'entry_ride').map((item) => {
                const owned = user.ownedEntryEffects.includes(item.id);
                const equipped = user.equippedEntryEffect === item.id;
                return (
                  <div key={item.id} className="rounded-2xl border border-slate-200 p-4 flex flex-col justify-between gap-3">
                    <div>
                      <div className={`h-16 rounded-xl bg-gradient-to-r ${item.previewClass} flex items-center justify-center text-3xl text-white shadow-inner`}>
                        {item.id === 'ride_scooter' ? '🛵' : item.id === 'ride_pegasus' ? '🦄' : '🏎️'}
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        <span className="font-display font-bold text-sm text-slate-900">{item.name}</span>
                        <span className="font-mono-num text-xs font-bold text-amber-600">{item.price.toLocaleString()}</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{item.description}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onPreviewVipEntry(user.vipLevel, item.id)}
                        className="h-9 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700"
                      >
                        Preview
                      </button>
                      {owned ? (
                        <button
                          onClick={async () => {
                            const err = await onEquipShopItem('entry_effect', item.id);
                            if (err) notify(null, err);
                            else notify(`Equipped ${item.name}!`, null);
                          }}
                          className={`flex-1 h-9 rounded-xl text-xs font-semibold ${
                            equipped ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white'
                          }`}
                        >
                          {equipped ? 'Equipped' : 'Equip'}
                        </button>
                      ) : (
                        <button
                          onClick={async () => {
                            const err = await onBuyShopItem(item.id);
                            if (err) notify(null, err);
                            else {
                              playCoinChime();
                              notify(`Purchased & equipped ${item.name}!`, null);
                            }
                          }}
                          className="flex-1 h-9 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                        >
                          Buy
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 4. PRIVACY SETTINGS & PARENTAL CONTROLS */}
      {subTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Privacy Settings */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-indigo-600" />
              <h3 className="font-display text-lg font-bold text-slate-900">Privacy Settings</h3>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Profile Visibility</label>
              <select
                value={privacy.profileVisibility}
                onChange={(e) =>
                  setPrivacy({ ...privacy, profileVisibility: e.target.value as PrivacySettings['profileVisibility'] })
                }
                className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm text-slate-900"
              >
                <option value="everyone">Everyone</option>
                <option value="friends">Friends Only</option>
                <option value="private">Private</option>
              </select>
            </div>

            {[
              { key: 'showOnlineStatus' as const, label: 'Show Online Activity Status' },
              { key: 'allowRoomInvites' as const, label: 'Allow Voice Room Invites' },
              { key: 'allowFriendRequests' as const, label: 'Allow New Friend Requests' },
              { key: 'hideWealthLevel' as const, label: 'Hide VIP & Wealth Badge in Public Lists' },
            ].map((row) => (
              <label key={row.key} className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 cursor-pointer">
                <span className="text-xs sm:text-sm font-medium text-slate-800">{row.label}</span>
                <input
                  type="checkbox"
                  checked={privacy[row.key]}
                  onChange={(e) => setPrivacy({ ...privacy, [row.key]: e.target.checked })}
                  className="w-5 h-5 accent-indigo-600 rounded"
                />
              </label>
            ))}
          </div>

          {/* Parental Controls */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-600" />
                <h3 className="font-display text-lg font-bold text-slate-900">Parental Controls</h3>
              </div>
              <label className="inline-flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={parental.enabled}
                  onChange={(e) => setParental({ ...parental, enabled: e.target.checked })}
                  className="w-5 h-5 accent-emerald-600"
                />
                <span>{parental.enabled ? 'Active' : 'Off'}</span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">4-Digit Parental PIN</label>
                <input
                  type="password"
                  maxLength={4}
                  value={parental.pinCode}
                  onChange={(e) => setParental({ ...parental, pinCode: e.target.value })}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-sm font-mono-num"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Daily Spend Limit (Coins)</label>
                <input
                  type="number"
                  min={0}
                  step={100}
                  value={parental.dailySpendLimit}
                  onChange={(e) => setParental({ ...parental, dailySpendLimit: Number(e.target.value) })}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-sm font-mono-num"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Playtime Reminder Limit: <span className="font-mono-num">{parental.playtimeLimitMinutes} mins</span>
              </label>
              <input
                type="range"
                min={30}
                max={240}
                step={15}
                value={parental.playtimeLimitMinutes}
                onChange={(e) => setParental({ ...parental, playtimeLimitMinutes: Number(e.target.value) })}
                className="w-full accent-emerald-600"
              />
            </div>

            <label className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 cursor-pointer">
              <span className="text-xs sm:text-sm font-medium text-slate-800">Restrict Voice Room Microphone</span>
              <input
                type="checkbox"
                checked={parental.restrictVoiceMic}
                onChange={(e) => setParental({ ...parental, restrictVoiceMic: e.target.checked })}
                className="w-5 h-5 accent-emerald-600"
              />
            </label>

            <label className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 cursor-pointer">
              <span className="text-xs sm:text-sm font-medium text-slate-800">Enable Safe Chat Content Filter</span>
              <input
                type="checkbox"
                checked={parental.safeContentFilter}
                onChange={(e) => setParental({ ...parental, safeContentFilter: e.target.checked })}
                className="w-5 h-5 accent-emerald-600"
              />
            </label>

            {user.parental.enabled && (
              <div>
                <label className="block text-xs font-semibold text-rose-700 mb-1">
                  Confirm Current Parental PIN to Save Changes (Default: 1234)
                </label>
                <input
                  type="password"
                  required
                  maxLength={4}
                  value={pinAttempt}
                  onChange={(e) => setPinAttempt(e.target.value)}
                  placeholder="Enter 4-digit PIN"
                  className="w-full h-10 px-3 rounded-xl border border-rose-300 text-sm font-mono-num"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full h-11 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Save Privacy & Parental Settings</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
