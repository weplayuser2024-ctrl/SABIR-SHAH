import React, { useState } from 'react';
import { X, Search, Eye, EyeOff, Trophy, RotateCcw, Vote } from 'lucide-react';
import { playCoinChime } from '../../utils/sound';

interface SpyGameProps {
  playerName: string;
  onClose: () => void;
  onGameComplete: (won: boolean) => void;
}

interface WordPair {
  civilian: string;
  spy: string;
  civilianClues: string[];
  spyClues: string[];
}

const WORD_PAIRS: WordPair[] = [
  {
    civilian: 'Espresso',
    spy: 'Cappuccino',
    civilianClues: ['Strong dark morning shot', 'Served in a tiny cup', 'Pure roasted beans, no foam'],
    spyClues: ['Creamy cafe drink with milk foam', 'Popular Italian coffee classic', 'Warm morning pick-me-up'],
  },
  {
    civilian: 'Guitar',
    spy: 'Violin',
    civilianClues: ['Has six strings you strum', 'Acoustic wood body at campfires', 'Played with a pick or fingers'],
    spyClues: ['Wooden string instrument played with a bow', 'Classic concert orchestra sound', 'Rests near your shoulder'],
  },
  {
    civilian: 'Snowboard',
    spy: 'Skateboard',
    civilianClues: ['Strapped boots on winter slopes', 'Carving down fresh powder', 'Cold mountain resort sport'],
    spyClues: ['Four wheels under a wooden deck', 'Street tricks and kickflips', 'Roll through the city park'],
  },
];

interface PlayerSlot {
  id: string;
  name: string;
  isSpy: boolean;
  isHuman: boolean;
  eliminated: boolean;
  clue: string;
}

function createMatch(playerName: string): { pair: WordPair; players: PlayerSlot[] } {
  const pair = WORD_PAIRS[Math.floor(Math.random() * WORD_PAIRS.length)];
  const spyIdx = Math.floor(Math.random() * 4);
  const names = [playerName, 'Aria', 'Marcus', 'Leo'];
  const players: PlayerSlot[] = names.map((name, idx) => ({
    id: `p_${idx}`,
    name,
    isSpy: idx === spyIdx,
    isHuman: idx === 0,
    eliminated: false,
    clue: '',
  }));
  return { pair, players };
}

export const SpyGame: React.FC<SpyGameProps> = ({ playerName, onClose, onGameComplete }) => {
  const [match, setMatch] = useState(() => createMatch(playerName));
  const [revealWord, setRevealWord] = useState(true);
  const [phase, setPhase] = useState<'CLUE' | 'VOTE' | 'RESULT'>('CLUE');
  const [clueInput, setClueInput] = useState('');
  const [round, setRound] = useState(1);
  const [log, setLog] = useState<string>('Give a subtle clue for your secret word without giving it away!');
  const [winnerTeam, setWinnerTeam] = useState<'Civilians' | 'Spy' | null>(null);

  const humanPlayer = match.players[0];
  const humanWord = humanPlayer.isSpy ? match.pair.spy : match.pair.civilian;

  const resetMatch = () => {
    setMatch(createMatch(playerName));
    setRevealWord(true);
    setPhase('CLUE');
    setClueInput('');
    setRound(1);
    setWinnerTeam(null);
    setLog('New mystery word dealt! Submit your Round 1 clue.');
  };

  const submitClue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clueInput.trim()) return;

    const updated = match.players.map((p, idx) => {
      if (p.isHuman) return { ...p, clue: clueInput.trim() };
      if (p.eliminated) return p;
      const cluePool = p.isSpy ? match.pair.spyClues : match.pair.civilianClues;
      return { ...p, clue: cluePool[(round + idx) % cluePool.length] };
    });

    setMatch({ ...match, players: updated });
    setClueInput('');
    setPhase('VOTE');
    setLog('All clues are in! Vote out the player you suspect is the Spy.');
  };

  const castVote = (targetId: string) => {
    const target = match.players.find((p) => p.id === targetId);
    if (!target || target.eliminated) return;

    const nextPlayers = match.players.map((p) =>
      p.id === targetId ? { ...p, eliminated: true } : p
    );

    const alive = nextPlayers.filter((p) => !p.eliminated);
    const spyAlive = alive.some((p) => p.isSpy);

    if (!spyAlive) {
      setMatch({ ...match, players: nextPlayers });
      setWinnerTeam('Civilians');
      setPhase('RESULT');
      setLog(`${target.name} was the Spy! Civilians win!`);
      playCoinChime();
      onGameComplete(!humanPlayer.isSpy);
      return;
    }

    if (alive.length <= 2) {
      setMatch({ ...match, players: nextPlayers });
      setWinnerTeam('Spy');
      setPhase('RESULT');
      setLog(`${target.name} was a Civilian! The Spy survived and wins!`);
      playCoinChime();
      onGameComplete(humanPlayer.isSpy);
      return;
    }

    setMatch({ ...match, players: nextPlayers });
    setRound((r) => r + 1);
    setPhase('CLUE');
    setLog(`${target.name} was innocent! Moving to Round ${round + 1}.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-3 sm:p-6">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Search className="w-5 h-5 text-amber-600" />
            <h3 className="font-display text-lg font-bold text-slate-900">Who’s the Spy</h3>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={resetMatch} className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 inline-flex items-center gap-1">
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Round</span>
            </button>
            <button onClick={onClose} aria-label="Exit Spy" className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 bg-slate-900 text-white">
          {/* Secret Dossier Card */}
          <div className="rounded-2xl bg-gradient-to-r from-amber-500/20 to-indigo-500/20 border border-amber-400/30 p-4 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs text-amber-300 font-semibold">
                Round {round} · Your Secret Word
              </div>
              <div className="font-display text-2xl font-extrabold mt-0.5 tracking-tight">
                {revealWord ? humanWord : '••••••••'}
              </div>
            </div>
            <button
              onClick={() => setRevealWord((v) => !v)}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold inline-flex items-center gap-1.5"
            >
              {revealWord ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span>{revealWord ? 'Hide' : 'Reveal'}</span>
            </button>
          </div>

          <div className="text-xs text-slate-300">{log}</div>

          {/* Players & Clues Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {match.players.map((p) => (
              <div
                key={p.id}
                className={`rounded-2xl p-4 border transition-all ${
                  p.eliminated
                    ? 'border-rose-500/30 bg-rose-950/30 opacity-60'
                    : 'border-white/15 bg-white/5'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display font-bold text-sm">
                    {p.name} {p.isHuman ? '(You)' : ''}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {p.eliminated ? 'Eliminated' : phase === 'RESULT' && p.isSpy ? 'SPY' : 'Active'}
                  </span>
                </div>
                <p className="mt-2 text-xs text-indigo-200 min-h-[2rem]">
                  {p.clue ? `Clue: “${p.clue}”` : 'Waiting for clue...'}
                </p>
                {phase === 'VOTE' && !p.eliminated && !p.isHuman && (
                  <button
                    onClick={() => castVote(p.id)}
                    className="mt-3 w-full py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                  >
                    <Vote className="w-3.5 h-3.5" />
                    <span>Vote Out {p.name}</span>
                  </button>
                )}
              </div>
            ))}
          </div>

          {phase === 'CLUE' && (
            <form onSubmit={submitClue} className="flex items-center gap-2">
              <input
                type="text"
                required
                value={clueInput}
                onChange={(e) => setClueInput(e.target.value)}
                placeholder="Describe your secret word in one short clue..."
                maxLength={60}
                className="flex-1 h-11 px-4 rounded-xl bg-white/10 border border-white/20 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
              <button
                type="submit"
                className="h-11 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs whitespace-nowrap"
              >
                Send Clue
              </button>
            </form>
          )}

          {winnerTeam && (
            <div className="rounded-2xl bg-amber-400 text-slate-950 p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Trophy className="w-7 h-7" />
                <div>
                  <div className="font-display font-extrabold">
                    {winnerTeam} Win!
                  </div>
                  <div className="text-xs font-semibold">
                    Words: Civilians = “{match.pair.civilian}” · Spy = “{match.pair.spy}”
                  </div>
                </div>
              </div>
              <button onClick={resetMatch} className="px-4 py-2 rounded-xl bg-slate-950 text-white text-xs font-bold">
                Play Again
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
