import React, { useEffect, useRef, useState } from 'react';
import { X, Mic, MicOff, Music, Trophy, Sparkles } from 'lucide-react';
import { playCoinChime, playTone } from '../../utils/sound';

interface MicGameProps {
  onClose: () => void;
  onGameComplete: (won: boolean) => void;
}

const TRACKS = [
  {
    id: 'neon_nights',
    title: 'Midnight Chorus',
    bpm: 108,
    lyrics: [
      'Turn up the lights across the stage tonight',
      'Every voice together shining bright',
      'Hold the golden note until the morning glow',
      'Raise your hands and let the rhythm flow!',
    ],
  },
  {
    id: 'starlight_duet',
    title: 'Starlight Harmony',
    bpm: 116,
    lyrics: [
      'Dancing on the rooftop under silver stars',
      'Singing out our story near and far',
      'Catch the beat and echo through the crowd',
      'Hit the final chorus strong and loud!',
    ],
  },
];

export const MicGame: React.FC<MicGameProps> = ({ onClose, onGameComplete }) => {
  const [selectedTrack, setSelectedTrack] = useState(TRACKS[0]);
  const [stageState, setStageState] = useState<'READY' | 'SINGING' | 'FINISHED'>('READY');
  const [micEnabled, setMicEnabled] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [timeLeft, setTimeLeft] = useState(20);
  const [lyricIndex, setLyricIndex] = useState(0);
  const [activeBeatLane, setActiveBeatLane] = useState(0);
  const [hitMessage, setHitMessage] = useState('Sing into your mic or tap the glowing pitch pads!');

  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const scoreRef = useRef(0);

  useEffect(() => {
    scoreRef.current = score;
  }, [score]);

  const stopMic = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setMicEnabled(false);
    setMicVolume(0);
  };

  useEffect(() => {
    return () => stopMic();
  }, []);

  const toggleMicrophone = async () => {
    if (micEnabled) {
      stopMic();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      setMicEnabled(true);

      const sample = () => {
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        setMicVolume(Math.min(100, Math.round((avg / 90) * 100)));
        if (avg > 22 && stageState === 'SINGING') {
          setScore((s) => s + 6);
        }
        rafRef.current = requestAnimationFrame(sample);
      };
      rafRef.current = requestAnimationFrame(sample);
    } catch {
      setHitMessage('Mic access unavailable — use the rhythm pitch pads below to score!');
    }
  };

  useEffect(() => {
    if (stageState !== 'SINGING') return;

    const countdown = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(countdown);
          setStageState('FINISHED');
          const won = scoreRef.current >= 450;
          playCoinChime();
          onGameComplete(won);
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    const beatTimer = setInterval(() => {
      setActiveBeatLane(Math.floor(Math.random() * 4));
      setLyricIndex((idx) => (idx + 1) % selectedTrack.lyrics.length);
    }, 1250);

    return () => {
      clearInterval(countdown);
      clearInterval(beatTimer);
    };
  }, [stageState, selectedTrack, onGameComplete]);

  const startPerformance = () => {
    setScore(0);
    setCombo(0);
    setTimeLeft(20);
    setLyricIndex(0);
    setStageState('SINGING');
    setHitMessage('Hit the highlighted note pad on the beat!');
  };

  const handleTapPad = (lane: number) => {
    if (stageState !== 'SINGING') return;
    const notes = [523.25, 587.33, 659.25, 783.99];
    playTone(notes[lane], 0.16, 'triangle', 0.08);
    if (lane === activeBeatLane) {
      const nextCombo = combo + 1;
      const pts = 55 + nextCombo * 10;
      setCombo(nextCombo);
      setScore((s) => s + pts);
      setHitMessage(`Perfect Pitch! +${pts} pts (${nextCombo}x Combo)`);
      setActiveBeatLane((lane + 1 + Math.floor(Math.random() * 3)) % 4);
    } else {
      setCombo(0);
      setScore((s) => s + 15);
      setHitMessage('Good groove! +15 pts');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-3 sm:p-6">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Mic className="w-5 h-5 text-violet-600" />
            <h3 className="font-display text-lg font-bold text-slate-900">Star Mic Stage</h3>
          </div>
          <button onClick={() => { stopMic(); onClose(); }} aria-label="Exit Star Mic" className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto bg-gradient-to-b from-indigo-950 via-violet-950 to-slate-950 text-white space-y-5">
          {/* Top Metrics */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="rounded-2xl bg-white/10 p-3 border border-white/10">
              <div className="text-[11px] text-violet-200">Score</div>
              <div className="font-mono-num text-2xl font-bold text-amber-300">{score}</div>
            </div>
            <div className="rounded-2xl bg-white/10 p-3 border border-white/10">
              <div className="text-[11px] text-violet-200">Combo</div>
              <div className="font-mono-num text-2xl font-bold text-emerald-300">{combo}x</div>
            </div>
            <div className="rounded-2xl bg-white/10 p-3 border border-white/10">
              <div className="text-[11px] text-violet-200">Stage Timer</div>
              <div className="font-mono-num text-2xl font-bold text-white">{timeLeft}s</div>
            </div>
          </div>

          {/* Track Picker & Live Mic Control */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {TRACKS.map((tr) => (
                <button
                  key={tr.id}
                  disabled={stageState === 'SINGING'}
                  onClick={() => setSelectedTrack(tr)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${
                    selectedTrack.id === tr.id
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  <Music className="w-3.5 h-3.5" />
                  <span>{tr.title}</span>
                </button>
              ))}
            </div>

            <button
              onClick={toggleMicrophone}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 ${
                micEnabled ? 'bg-emerald-500 text-white' : 'bg-white/15 text-white hover:bg-white/25'
              }`}
            >
              {micEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              <span>{micEnabled ? `Mic Live (${micVolume}%)` : 'Enable Live Mic'}</span>
            </button>
          </div>

          {/* Teleprompter */}
          <div className="rounded-2xl bg-black/35 border border-white/15 p-6 text-center space-y-2">
            <div className="text-xs font-semibold text-amber-300 flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{hitMessage}</span>
            </div>
            <div className="font-display text-xl sm:text-2xl font-extrabold text-white leading-snug pt-2">
              “{selectedTrack.lyrics[lyricIndex]}”
            </div>
            {micEnabled && (
              <div className="w-full max-w-xs mx-auto h-2 rounded-full bg-white/15 overflow-hidden mt-3">
                <div
                  className="h-full bg-gradient-to-r from-emerald-400 to-amber-400 transition-all duration-75"
                  style={{ width: `${micVolume}%` }}
                />
              </div>
            )}
          </div>

          {stageState === 'READY' && (
            <button
              onClick={startPerformance}
              className="w-full h-12 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 font-display font-extrabold text-sm shadow-lg hover:brightness-105"
            >
              Start Performance (Reach 450 pts to Win)
            </button>
          )}

          {stageState === 'SINGING' && (
            <div className="grid grid-cols-4 gap-3">
              {['Do', 'Re', 'Mi', 'Sol'].map((note, idx) => {
                const isTarget = idx === activeBeatLane;
                return (
                  <button
                    key={note}
                    onClick={() => handleTapPad(idx)}
                    className={`h-24 rounded-2xl font-display font-extrabold text-lg transition-all active:scale-95 border-2 ${
                      isTarget
                        ? 'bg-gradient-to-b from-amber-300 to-amber-500 text-slate-950 border-white shadow-xl scale-[1.03]'
                        : 'bg-white/10 text-white/80 border-white/15 hover:bg-white/20'
                    }`}
                  >
                    {note}
                  </button>
                );
              })}
            </div>
          )}

          {stageState === 'FINISHED' && (
            <div className="rounded-2xl bg-amber-400 text-slate-950 p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Trophy className="w-7 h-7" />
                <div>
                  <div className="font-display font-extrabold">
                    {score >= 450 ? 'Encore Standing Ovation!' : 'Great Stage Debut!'}
                  </div>
                  <div className="text-xs font-semibold">
                    Final Score: {score} · {score >= 450 ? '+180 Coins & +90 CP' : '+60 Coins & +35 CP'}
                  </div>
                </div>
              </div>
              <button onClick={startPerformance} className="px-4 py-2 rounded-xl bg-slate-950 text-white text-xs font-bold">
                Sing Again
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
