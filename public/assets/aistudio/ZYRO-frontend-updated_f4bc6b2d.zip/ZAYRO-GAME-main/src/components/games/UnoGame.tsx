import React, { useEffect, useState } from 'react';
import { X, RotateCcw, Trophy, Layers } from 'lucide-react';
import { playCardSnap, playCoinChime } from '../../utils/sound';

type CardColor = 'red' | 'blue' | 'green' | 'yellow' | 'wild';
type CardValue = '0' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | 'Skip' | '+2' | 'Wild' | '+4';

interface UnoCard {
  id: string;
  color: CardColor;
  value: CardValue;
}

interface UnoGameProps {
  playerName: string;
  onClose: () => void;
  onGameComplete: (won: boolean) => void;
}

const COLORS: ('red' | 'blue' | 'green' | 'yellow')[] = ['red', 'blue', 'green', 'yellow'];
const VALUES: CardValue[] = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'Skip', '+2'];

const COLOR_STYLES: Record<CardColor, string> = {
  red: 'bg-rose-600 text-white border-rose-300',
  blue: 'bg-blue-600 text-white border-blue-300',
  green: 'bg-emerald-600 text-white border-emerald-300',
  yellow: 'bg-amber-400 text-slate-950 border-amber-200',
  wild: 'bg-slate-900 text-white border-indigo-400',
};

function createDeck(): UnoCard[] {
  const deck: UnoCard[] = [];
  let idx = 0;
  for (const c of COLORS) {
    for (const v of VALUES) {
      deck.push({ id: `c_${idx++}`, color: c, value: v });
      deck.push({ id: `c_${idx++}`, color: c, value: v });
    }
  }
  for (let i = 0; i < 4; i++) {
    deck.push({ id: `w_${idx++}`, color: 'wild', value: 'Wild' });
    deck.push({ id: `w4_${idx++}`, color: 'wild', value: '+4' });
  }
  return deck.sort(() => Math.random() - 0.5);
}

export const UnoGame: React.FC<UnoGameProps> = ({ playerName, onClose, onGameComplete }) => {
  const [deck, setDeck] = useState<UnoCard[]>([]);
  const [playerHand, setPlayerHand] = useState<UnoCard[]>([]);
  const [bot1Hand, setBot1Hand] = useState<UnoCard[]>([]);
  const [bot2Hand, setBot2Hand] = useState<UnoCard[]>([]);
  const [topCard, setTopCard] = useState<UnoCard | null>(null);
  const [activeColor, setActiveColor] = useState<'red' | 'blue' | 'green' | 'yellow'>('red');
  const [turnIndex, setTurnIndex] = useState<0 | 1 | 2>(0); // 0=player, 1=Bot Maya, 2=Bot Leo
  const [pendingWildCard, setPendingWildCard] = useState<UnoCard | null>(null);
  const [unoShouted, setUnoShouted] = useState(false);
  const [status, setStatus] = useState('Your turn! Play a matching card or draw.');
  const [winner, setWinner] = useState<string | null>(null);

  const initMatch = () => {
    const fresh = createDeck();
    const p = fresh.slice(0, 7);
    const b1 = fresh.slice(7, 14);
    const b2 = fresh.slice(14, 21);
    const firstNonWildIdx = fresh.findIndex((c, i) => i >= 21 && c.color !== 'wild');
    const starter = fresh[firstNonWildIdx] || { id: 'start', color: 'red', value: '5' };
    const remaining = fresh.slice(21).filter((_, idx) => idx !== firstNonWildIdx - 21);

    setDeck(remaining);
    setPlayerHand(p);
    setBot1Hand(b1);
    setBot2Hand(b2);
    setTopCard(starter);
    setActiveColor(starter.color === 'wild' ? 'blue' : starter.color);
    setTurnIndex(0);
    setWinner(null);
    setUnoShouted(false);
    setPendingWildCard(null);
    setStatus('Match started! Your turn.');
  };

  useEffect(() => {
    initMatch();
  }, []);

  const canPlay = (card: UnoCard) => {
    if (!topCard) return false;
    return card.color === 'wild' || card.color === activeColor || card.value === topCard.value;
  };

  const drawCards = (count: number): UnoCard[] => {
    const nextDeck = deck.length >= count ? [...deck] : [...deck, ...createDeck()];
    const drawn = nextDeck.slice(0, count);
    setDeck(nextDeck.slice(count));
    return drawn;
  };

  const finishTurn = (
    playedCard: UnoCard,
    chosenColor: 'red' | 'blue' | 'green' | 'yellow',
    who: 0 | 1 | 2,
    newCount: number
  ) => {
    setTopCard(playedCard);
    setActiveColor(chosenColor);

    if (newCount === 0) {
      const winName = who === 0 ? playerName : who === 1 ? 'Maya' : 'Leo';
      setWinner(winName);
      setStatus(`${winName} wins the round!`);
      playCoinChime();
      onGameComplete(who === 0);
      return;
    }

    let nextTurn = ((who + 1) % 3) as 0 | 1 | 2;
    if (playedCard.value === 'Skip') {
      nextTurn = ((who + 2) % 3) as 0 | 1 | 2;
      setStatus(`Skip! Turn jumps ahead.`);
    } else if (playedCard.value === '+2' || playedCard.value === '+4') {
      const penalty = playedCard.value === '+4' ? 4 : 2;
      const victim = ((who + 1) % 3) as 0 | 1 | 2;
      const drawn = drawCards(penalty);
      if (victim === 0) setPlayerHand((h) => [...h, ...drawn]);
      if (victim === 1) setBot1Hand((h) => [...h, ...drawn]);
      if (victim === 2) setBot2Hand((h) => [...h, ...drawn]);
      nextTurn = ((who + 2) % 3) as 0 | 1 | 2;
      setStatus(`${playedCard.value} played! ${victim === 0 ? 'You' : victim === 1 ? 'Maya' : 'Leo'} drew ${penalty} cards.`);
    } else {
      setStatus(nextTurn === 0 ? 'Your turn!' : `${nextTurn === 1 ? 'Maya' : 'Leo'} is thinking...`);
    }
    setTurnIndex(nextTurn);
  };

  const handlePlayerCard = (card: UnoCard) => {
    if (turnIndex !== 0 || winner || !canPlay(card)) return;
    playCardSnap();
    const remaining = playerHand.filter((c) => c.id !== card.id);
    setPlayerHand(remaining);

    if (remaining.length === 1 && !unoShouted) {
      setStatus('Quick! Tap UNO! before your final card!');
    }

    if (card.color === 'wild') {
      setPendingWildCard(card);
      return;
    }
    finishTurn(card, card.color, 0, remaining.length);
  };

  const handleSelectWildColor = (color: 'red' | 'blue' | 'green' | 'yellow') => {
    if (!pendingWildCard) return;
    const card = pendingWildCard;
    setPendingWildCard(null);
    finishTurn(card, color, 0, playerHand.length);
  };

  const handlePlayerDraw = () => {
    if (turnIndex !== 0 || winner) return;
    playCardSnap();
    const drawn = drawCards(1);
    setPlayerHand((h) => [...h, ...drawn]);
    setStatus('Drew 1 card. Next turn!');
    setTurnIndex(1);
  };

  // Bot turn automation
  useEffect(() => {
    if (winner || turnIndex === 0 || pendingWildCard) return;
    const timer = setTimeout(() => {
      const hand = turnIndex === 1 ? bot1Hand : bot2Hand;
      const playable = hand.find((c) => canPlay(c));
      if (playable) {
        playCardSnap();
        const nextHand = hand.filter((c) => c.id !== playable.id);
        if (turnIndex === 1) setBot1Hand(nextHand);
        else setBot2Hand(nextHand);

        const nextColor =
          playable.color === 'wild'
            ? COLORS[Math.floor(Math.random() * COLORS.length)]
            : playable.color;
        finishTurn(playable, nextColor, turnIndex, nextHand.length);
      } else {
        const drawn = drawCards(1);
        if (turnIndex === 1) setBot1Hand((h) => [...h, ...drawn]);
        else setBot2Hand((h) => [...h, ...drawn]);
        const next = ((turnIndex + 1) % 3) as 0 | 1 | 2;
        setTurnIndex(next);
        setStatus(next === 0 ? 'Your turn!' : `${next === 1 ? 'Maya' : 'Leo'} drew a card.`);
      }
    }, 850);
    return () => clearTimeout(timer);
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-3 sm:p-6">
      <div className="w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-emerald-600" />
            <h3 className="font-display text-lg font-bold text-slate-900">Uno Blitz</h3>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={initMatch} className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 inline-flex items-center gap-1">
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Deal</span>
            </button>
            <button onClick={onClose} aria-label="Exit Uno" className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 bg-gradient-to-b from-teal-900 to-slate-900 text-white">
          {/* Opponents */}
          <div className="grid grid-cols-2 gap-3">
            <div className={`rounded-2xl p-3 border ${turnIndex === 1 ? 'border-amber-400 bg-white/15' : 'border-white/10 bg-white/5'}`}>
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold">Maya</span>
                <span className="font-mono-num">{bot1Hand.length} cards</span>
              </div>
            </div>
            <div className={`rounded-2xl p-3 border ${turnIndex === 2 ? 'border-amber-400 bg-white/15' : 'border-white/10 bg-white/5'}`}>
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold">Leo</span>
                <span className="font-mono-num">{bot2Hand.length} cards</span>
              </div>
            </div>
          </div>

          {/* Center Table */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 py-4">
            <button
              onClick={handlePlayerDraw}
              disabled={turnIndex !== 0 || !!winner}
              className="w-24 h-36 rounded-2xl bg-slate-800 border-2 border-white/30 shadow-lg flex flex-col items-center justify-center hover:scale-105 transition-transform disabled:opacity-60"
            >
              <span className="font-display font-extrabold text-sm">DRAW</span>
              <span className="text-[11px] text-slate-300 mt-1">{deck.length} left</span>
            </button>

            {topCard && (
              <div className="flex flex-col items-center gap-2">
                <div className={`w-28 h-40 rounded-2xl border-4 shadow-2xl flex flex-col items-center justify-center ${COLOR_STYLES[topCard.color]}`}>
                  <span className="font-display text-3xl font-extrabold">{topCard.value}</span>
                </div>
                <div className="text-xs font-semibold text-white/90 capitalize">
                  Active Color: <span className="underline">{activeColor}</span>
                </div>
              </div>
            )}

            <button
              onClick={() => {
                setUnoShouted(true);
                playCoinChime();
                setStatus('UNO! shouted loud and clear!');
              }}
              className={`px-5 py-3 rounded-2xl font-display font-extrabold text-sm shadow-lg transition-transform active:scale-95 ${
                playerHand.length <= 2
                  ? 'bg-amber-400 text-slate-950 animate-bounce'
                  : 'bg-white/15 text-white hover:bg-white/25'
              }`}
            >
              UNO!
            </button>
          </div>

          <div className="text-center text-xs font-medium text-teal-100">{status}</div>

          {/* Wild Color Picker */}
          {pendingWildCard && (
            <div className="rounded-2xl bg-white text-slate-900 p-4 flex flex-col items-center gap-3">
              <div className="font-display text-sm font-bold">Choose Wild Color</div>
              <div className="flex items-center gap-3">
                {COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => handleSelectWildColor(c)}
                    className={`w-12 h-12 rounded-xl capitalize font-bold text-xs border-2 ${COLOR_STYLES[c]}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Winner Banner */}
          {winner && (
            <div className="rounded-2xl bg-amber-400 text-slate-950 p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Trophy className="w-7 h-7" />
                <div>
                  <div className="font-display font-extrabold">{winner} Wins!</div>
                  <div className="text-xs font-semibold">
                    {winner === playerName ? '+180 Coins & +90 CP earned' : '+60 Coins & +35 CP participation reward'}
                  </div>
                </div>
              </div>
              <button onClick={initMatch} className="px-4 py-2 rounded-xl bg-slate-950 text-white text-xs font-bold">
                Play Again
              </button>
            </div>
          )}

          {/* Player Hand */}
          <div>
            <div className="text-xs font-semibold text-teal-200 mb-2">
              Your Hand ({playerHand.length} cards)
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {playerHand.map((card) => {
                const playable = turnIndex === 0 && !winner && canPlay(card);
                return (
                  <button
                    key={card.id}
                    onClick={() => handlePlayerCard(card)}
                    disabled={!playable}
                    className={`w-16 h-24 rounded-xl border-2 flex flex-col items-center justify-center font-display font-extrabold text-lg transition-all ${
                      COLOR_STYLES[card.color]
                    } ${
                      playable
                        ? 'hover:-translate-y-2 shadow-lg cursor-pointer ring-2 ring-white/80'
                        : 'opacity-45 cursor-not-allowed'
                    }`}
                  >
                    <span>{card.value}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
