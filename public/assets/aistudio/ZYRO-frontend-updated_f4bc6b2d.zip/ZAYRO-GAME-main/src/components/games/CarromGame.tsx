import React, { useEffect, useRef, useState } from 'react';
import { X, RotateCcw, Trophy, Crosshair } from 'lucide-react';
import { playCarromClack, playCoinChime } from '../../utils/sound';

interface Puck {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  kind: 'white' | 'black' | 'queen' | 'striker';
  pocketed: boolean;
}

interface CarromGameProps {
  onClose: () => void;
  onGameComplete: (won: boolean) => void;
}

const BOARD_SIZE = 440;
const POCKET_RADIUS = 22;
const POCKETS = [
  { x: 28, y: 28 },
  { x: BOARD_SIZE - 28, y: 28 },
  { x: 28, y: BOARD_SIZE - 28 },
  { x: BOARD_SIZE - 28, y: BOARD_SIZE - 28 },
];

function createInitialPucks(): Puck[] {
  const cx = BOARD_SIZE / 2;
  const cy = BOARD_SIZE / 2;
  const pucks: Puck[] = [
    { id: 'queen', x: cx, y: cy, vx: 0, vy: 0, radius: 12, kind: 'queen', pocketed: false },
  ];

  // Inner ring (6 alternating pucks)
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI) / 3;
    pucks.push({
      id: `in_${i}`,
      x: cx + Math.cos(angle) * 26,
      y: cy + Math.sin(angle) * 26,
      vx: 0,
      vy: 0,
      radius: 12,
      kind: i % 2 === 0 ? 'white' : 'black',
      pocketed: false,
    });
  }

  // Outer ring (6 pucks)
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI) / 3 + Math.PI / 6;
    pucks.push({
      id: `out_${i}`,
      x: cx + Math.cos(angle) * 50,
      y: cy + Math.sin(angle) * 50,
      vx: 0,
      vy: 0,
      radius: 12,
      kind: i % 2 === 0 ? 'black' : 'white',
      pocketed: false,
    });
  }

  pucks.push({
    id: 'striker',
    x: cx,
    y: BOARD_SIZE - 78,
    vx: 0,
    vy: 0,
    radius: 15,
    kind: 'striker',
    pocketed: false,
  });

  return pucks;
}

export const CarromGame: React.FC<CarromGameProps> = ({ onClose, onGameComplete }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pucksRef = useRef<Puck[]>(createInitialPucks());
  const [turn, setTurn] = useState<'player' | 'bot'>('player');
  const [phase, setPhase] = useState<'AIM' | 'MOVING' | 'GAME_OVER'>('AIM');
  const [playerScore, setPlayerScore] = useState(0);
  const [botScore, setBotScore] = useState(0);
  const [strikerX, setStrikerX] = useState(BOARD_SIZE / 2);
  const [statusText, setStatusText] = useState('Slide striker & drag back on board to shoot!');
  const [winner, setWinner] = useState<'player' | 'bot' | null>(null);

  const dragRef = useRef<{ active: boolean; x: number; y: number } | null>(null);
  const turnRef = useRef<'player' | 'bot'>('player');
  const phaseRef = useRef<'AIM' | 'MOVING' | 'GAME_OVER'>('AIM');
  const rewardSentRef = useRef(false);

  useEffect(() => {
    turnRef.current = turn;
  }, [turn]);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  const resetGame = () => {
    pucksRef.current = createInitialPucks();
    setTurn('player');
    setPhase('AIM');
    setPlayerScore(0);
    setBotScore(0);
    setStrikerX(BOARD_SIZE / 2);
    setWinner(null);
    rewardSentRef.current = false;
    setStatusText('Your turn! Slide striker & drag back on board to shoot.');
  };

  // Update striker X along baseline during player aim
  useEffect(() => {
    if (phase === 'AIM' && turn === 'player') {
      const striker = pucksRef.current.find((p) => p.kind === 'striker');
      if (striker) {
        striker.x = strikerX;
        striker.y = BOARD_SIZE - 78;
        striker.vx = 0;
        striker.vy = 0;
        striker.pocketed = false;
      }
    }
  }, [strikerX, phase, turn]);

  // Physics loop
  useEffect(() => {
    let rafId = 0;
    let pocketedThisTurn = false;

    const step = () => {
      const pucks = pucksRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');

      if (phaseRef.current === 'MOVING') {
        let anyMoving = false;
        for (const p of pucks) {
          if (p.pocketed) continue;
          p.x += p.vx;
          p.y += p.vy;
          p.vx *= 0.982;
          p.vy *= 0.982;
          if (Math.hypot(p.vx, p.vy) < 0.08) {
            p.vx = 0;
            p.vy = 0;
          } else {
            anyMoving = true;
          }

          // Wall bounce
          const margin = 20 + p.radius;
          if (p.x < margin) {
            p.x = margin;
            p.vx = Math.abs(p.vx) * 0.85;
            playCarromClack();
          } else if (p.x > BOARD_SIZE - margin) {
            p.x = BOARD_SIZE - margin;
            p.vx = -Math.abs(p.vx) * 0.85;
            playCarromClack();
          }
          if (p.y < margin) {
            p.y = margin;
            p.vy = Math.abs(p.vy) * 0.85;
            playCarromClack();
          } else if (p.y > BOARD_SIZE - margin) {
            p.y = BOARD_SIZE - margin;
            p.vy = -Math.abs(p.vy) * 0.85;
            playCarromClack();
          }

          // Pocket check
          for (const pk of POCKETS) {
            if (Math.hypot(p.x - pk.x, p.y - pk.y) < POCKET_RADIUS) {
              p.pocketed = true;
              p.vx = 0;
              p.vy = 0;
              if (p.kind !== 'striker') {
                pocketedThisTurn = true;
                playCoinChime();
                const pts = p.kind === 'queen' ? 3 : 1;
                if (turnRef.current === 'player') {
                  setPlayerScore((s) => s + pts);
                } else {
                  setBotScore((s) => s + pts);
                }
              }
            }
          }
        }

        // Elastic disc collisions
        for (let i = 0; i < pucks.length; i++) {
          const a = pucks[i];
          if (a.pocketed) continue;
          for (let j = i + 1; j < pucks.length; j++) {
            const b = pucks[j];
            if (b.pocketed) continue;
            const dx = b.x - a.x;
            const dy = b.y - a.y;
            const dist = Math.hypot(dx, dy);
            const minDist = a.radius + b.radius;
            if (dist > 0 && dist < minDist) {
              const nx = dx / dist;
              const ny = dy / dist;
              const overlap = minDist - dist;
              a.x -= nx * (overlap / 2);
              a.y -= ny * (overlap / 2);
              b.x += nx * (overlap / 2);
              b.y += ny * (overlap / 2);

              const rvx = b.vx - a.vx;
              const rvy = b.vy - a.vy;
              const velAlongNormal = rvx * nx + rvy * ny;
              if (velAlongNormal < 0) {
                const impulse = -0.92 * velAlongNormal;
                a.vx -= impulse * nx;
                a.vy -= impulse * ny;
                b.vx += impulse * nx;
                b.vy += impulse * ny;
                playCarromClack();
              }
            }
          }
        }

        if (!anyMoving) {
          const remainingPucks = pucks.filter((p) => p.kind !== 'striker' && !p.pocketed);
          if (remainingPucks.length === 0) {
            setPhase('GAME_OVER');
          } else {
            const nextTurn = pocketedThisTurn ? turnRef.current : turnRef.current === 'player' ? 'bot' : 'player';
            pocketedThisTurn = false;
            setTurn(nextTurn);
            setPhase('AIM');
            const striker = pucks.find((p) => p.kind === 'striker');
            if (striker) {
              striker.pocketed = false;
              striker.vx = 0;
              striker.vy = 0;
              striker.x = BOARD_SIZE / 2;
              striker.y = nextTurn === 'player' ? BOARD_SIZE - 78 : 78;
            }
            setStatusText(
              nextTurn === 'player'
                ? 'Your turn! Aim and pull back to strike.'
                : 'Opponent is lining up a shot...'
            );
          }
        }
      }

      // Draw Board
      if (ctx) {
        // Outer wooden frame
        ctx.fillStyle = '#5C3419';
        ctx.fillRect(0, 0, BOARD_SIZE, BOARD_SIZE);

        // Playing surface
        ctx.fillStyle = '#F3DFC1';
        ctx.fillRect(18, 18, BOARD_SIZE - 36, BOARD_SIZE - 36);

        // Center mandala ring
        ctx.strokeStyle = '#B91C1C';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(BOARD_SIZE / 2, BOARD_SIZE / 2, 54, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = '#92400E';
        ctx.beginPath();
        ctx.arc(BOARD_SIZE / 2, BOARD_SIZE / 2, 16, 0, Math.PI * 2);
        ctx.stroke();

        // Baselines
        ctx.strokeStyle = '#78350F';
        ctx.lineWidth = 2;
        ctx.strokeRect(86, 70, BOARD_SIZE - 172, 16);
        ctx.strokeRect(86, BOARD_SIZE - 86, BOARD_SIZE - 172, 16);

        // Pockets
        for (const pk of POCKETS) {
          ctx.fillStyle = '#1E1B18';
          ctx.beginPath();
          ctx.arc(pk.x, pk.y, POCKET_RADIUS, 0, Math.PI * 2);
          ctx.fill();
        }

        // Aim guide line
        const striker = pucks.find((p) => p.kind === 'striker');
        if (dragRef.current?.active && striker && phaseRef.current === 'AIM' && turnRef.current === 'player') {
          const dx = striker.x - dragRef.current.x;
          const dy = striker.y - dragRef.current.y;
          ctx.strokeStyle = 'rgba(79, 70, 229, 0.8)';
          ctx.lineWidth = 3;
          ctx.setLineDash([6, 4]);
          ctx.beginPath();
          ctx.moveTo(striker.x, striker.y);
          ctx.lineTo(striker.x + dx * 2.2, striker.y + dy * 2.2);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Draw pucks
        for (const p of pucks) {
          if (p.pocketed) continue;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          if (p.kind === 'white') {
            ctx.fillStyle = '#FFFDF7';
            ctx.strokeStyle = '#B45309';
          } else if (p.kind === 'black') {
            ctx.fillStyle = '#1F2937';
            ctx.strokeStyle = '#030712';
          } else if (p.kind === 'queen') {
            ctx.fillStyle = '#DC2626';
            ctx.strokeStyle = '#7F1D1D';
          } else {
            ctx.fillStyle = '#F59E0B';
            ctx.strokeStyle = '#4F46E5';
          }
          ctx.fill();
          ctx.lineWidth = p.kind === 'striker' ? 3 : 2;
          ctx.stroke();

          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * 0.5, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(255,255,255,0.45)';
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
      }

      rafId = requestAnimationFrame(step);
    };

    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, []);

  // Bot turn logic
  useEffect(() => {
    if (phase === 'AIM' && turn === 'bot') {
      const timer = setTimeout(() => {
        const pucks = pucksRef.current;
        const striker = pucks.find((p) => p.kind === 'striker');
        const target = pucks.find((p) => p.kind !== 'striker' && !p.pocketed);
        if (!striker || !target) return;

        striker.x = 120 + Math.random() * (BOARD_SIZE - 240);
        striker.y = 78;
        const dx = target.x - striker.x;
        const dy = target.y - striker.y;
        const dist = Math.max(1, Math.hypot(dx, dy));
        const speed = 13 + Math.random() * 4;
        striker.vx = (dx / dist) * speed;
        striker.vy = (dy / dist) * speed;
        playCarromClack();
        setPhase('MOVING');
        setStatusText('Opponent took their shot!');
      }, 850);
      return () => clearTimeout(timer);
    }
  }, [phase, turn]);

  // Game over reward trigger
  useEffect(() => {
    if (phase === 'GAME_OVER' && !rewardSentRef.current) {
      rewardSentRef.current = true;
      const didWin = playerScore >= botScore;
      setWinner(didWin ? 'player' : 'bot');
      onGameComplete(didWin);
    }
  }, [phase, playerScore, botScore, onGameComplete]);

  const getPointerPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const scale = BOARD_SIZE / rect.width;
    return {
      x: (e.clientX - rect.left) * scale,
      y: (e.clientY - rect.top) * scale,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (phase !== 'AIM' || turn !== 'player') return;
    const pos = getPointerPos(e);
    dragRef.current = { active: true, x: pos.x, y: pos.y };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!dragRef.current?.active) return;
    const pos = getPointerPos(e);
    dragRef.current.x = pos.x;
    dragRef.current.y = pos.y;
  };

  const handlePointerUp = () => {
    if (!dragRef.current?.active || phase !== 'AIM' || turn !== 'player') {
      dragRef.current = null;
      return;
    }
    const striker = pucksRef.current.find((p) => p.kind === 'striker');
    if (striker) {
      const dx = striker.x - dragRef.current.x;
      const dy = striker.y - dragRef.current.y;
      const mag = Math.hypot(dx, dy);
      if (mag > 10) {
        const clamped = Math.min(mag, 130);
        const speed = (clamped / 130) * 18;
        striker.vx = (dx / mag) * speed;
        striker.vy = (dy / mag) * speed;
        playCarromClack();
        setPhase('MOVING');
        setStatusText('Shot fired!');
      }
    }
    dragRef.current = null;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-3 sm:p-6">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Crosshair className="w-5 h-5 text-amber-600" />
            <h3 className="font-display text-lg font-bold text-slate-900">Carrom Arena</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={resetGame}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
            <button onClick={onClose} aria-label="Exit Carrom" className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-6 overflow-y-auto flex flex-col items-center gap-4">
          <div className="w-full max-w-[440px] flex items-center justify-between bg-slate-50 rounded-2xl px-4 py-2.5 border border-slate-200">
            <div>
              <div className="text-[11px] font-semibold text-slate-500">You</div>
              <div className="font-mono-num text-xl font-bold text-indigo-700">{playerScore}</div>
            </div>
            <div className="text-center px-3">
              <div className="text-xs font-semibold text-slate-800">{turn === 'player' ? 'Your Turn' : 'Opponent Turn'}</div>
              <div className="text-[11px] text-slate-500">Queen = 3 pts</div>
            </div>
            <div className="text-right">
              <div className="text-[11px] font-semibold text-slate-500">Bot</div>
              <div className="font-mono-num text-xl font-bold text-rose-600">{botScore}</div>
            </div>
          </div>

          <canvas
            ref={canvasRef}
            width={BOARD_SIZE}
            height={BOARD_SIZE}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="w-full max-w-[420px] aspect-square rounded-2xl shadow-lg touch-none cursor-crosshair border-4 border-[#3E220F]"
          />

          <div className="w-full max-w-[420px] space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>Striker Position</span>
              <span>{statusText}</span>
            </div>
            <input
              type="range"
              min={95}
              max={BOARD_SIZE - 95}
              value={strikerX}
              disabled={phase !== 'AIM' || turn !== 'player'}
              onChange={(e) => setStrikerX(Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>

          {winner && (
            <div className="w-full max-w-[420px] rounded-2xl bg-amber-50 border border-amber-200 p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Trophy className="w-7 h-7 text-amber-500 shrink-0" />
                <div>
                  <div className="font-display font-bold text-slate-900">
                    {winner === 'player' ? 'Victory! +180 Coins & +90 CP' : 'Match Complete! +60 Coins & +35 CP'}
                  </div>
                  <div className="text-xs text-slate-600">Final Score: You {playerScore} – {botScore} Bot</div>
                </div>
              </div>
              <button
                onClick={resetGame}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold whitespace-nowrap"
              >
                Play Again
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
