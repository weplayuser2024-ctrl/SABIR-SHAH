import React, { useEffect, useRef, useState } from 'react';
import {
  Heart,
  MessageCircle,
  Send,
  Sparkles,
  Users,
  Shield,
  ShieldCheck,
  Plus,
  Coins,
  X,
  CheckCircle2,
  MessageSquare,
  Video,
  Play,
  Pause,
  Gift,
  Swords,
  Lock,
  UserPlus,
  RotateCw,
  ChevronDown,
  ChevronUp,
  Film,
  FileText,
} from 'lucide-react';
import {
  ACTIVITY_CHESTS,
  ActivityChest,
  FamilyGroup,
  FeedPost,
  GACHA_REWARDS,
  GIFT_CATALOG,
  GachaReward,
  PublicFriend,
  UserProfile,
  computeGiftCharm,
} from '../shared/types';
import { AvatarBadge } from './AvatarBadge';
import { playCoinChime } from '../utils/sound';

interface DiscoverTabProps {
  user: UserProfile;
  friends: PublicFriend[];
  posts: FeedPost[];
  families: FamilyGroup[];
  onCollectDailyCp: () => Promise<{ bonusCp: number; bonusCoins: number } | { error: string }>;
  onCreatePost: (payload: {
    content: string;
    tag: string;
    mediaType: 'post' | 'video';
    videoTitle?: string;
    videoDuration?: string;
    videoUrl?: string;
    videoTheme?: 'concert' | 'carrom' | 'party';
  }) => Promise<string | null>;
  onLikePost: (postId: string) => Promise<void>;
  onBoostPostCp: (postId: string) => Promise<void>;
  onCommentPost: (postId: string, text: string) => Promise<void>;
  onSendCpGift: (
    friendId: string,
    giftId: string
  ) => Promise<
    | { cpEarned: number; charmEarned: number; coinReturn: number; giftName: string; friendName: string }
    | { error: string }
  >;
  onJoinFamily: (familyId: string) => Promise<void>;
  onCreateFamily: (name: string, motto: string, crest: string) => Promise<string | null>;
  onContributeFamily: (familyId: string) => Promise<string | null>;
  onAddFamilyMember: (familyId: string, friendId: string) => Promise<{ addedName: string } | { error: string }>;
  onActivateBarrier: (familyId: string) => Promise<string | null>;
  onStealFamily: (
    familyId: string
  ) => Promise<{ blocked: boolean; stolenCp: number; message: string } | { error: string }>;
  onClaimChest: (chestId: string) => Promise<{ chest: ActivityChest } | { error: string }>;
  onSpinGacha: () => Promise<
    { reward: GachaReward; rewardIndex: number; usedFreeSpin: boolean } | { error: string }
  >;
  onOpenChat: (friendId?: string) => void;
}

interface PlayableFriendVideoProps {
  videoUrl?: string;
  videoTitle?: string;
  videoDuration?: string;
  videoTheme?: 'concert' | 'carrom' | 'party';
}

const PlayableFriendVideo: React.FC<PlayableFriendVideoProps> = ({
  videoUrl,
  videoTitle,
  videoDuration = '0:20',
  videoTheme = 'party',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (videoUrl) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let tick = 0;

    const drawFrame = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const grad = ctx.createLinearGradient(0, 0, w, h);
      if (videoTheme === 'concert') {
        grad.addColorStop(0, '#1e1b4b');
        grad.addColorStop(0.55, '#4c1d95');
        grad.addColorStop(1, '#be185d');
      } else if (videoTheme === 'carrom') {
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.55, '#1e3a8a');
        grad.addColorStop(1, '#b45309');
      } else {
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.5, '#312e81');
        grad.addColorStop(1, '#0284c7');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      if (videoTheme === 'carrom') {
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
        ctx.lineWidth = 3;
        ctx.strokeRect(24, 18, w - 48, h - 36);
        const cx = w * 0.5 + Math.sin(tick * 0.06) * (w * 0.25);
        const cy = h * 0.5 + Math.cos(tick * 0.08) * (h * 0.18);
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(cx, cy, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(w * 0.5 - Math.cos(tick * 0.05) * 70, h * 0.5, 13, 0, Math.PI * 2);
        ctx.fill();
      } else {
        const bars = 20;
        const barW = (w - 80) / bars;
        for (let i = 0; i < bars; i++) {
          const amp = playing
            ? 14 + Math.abs(Math.sin(tick * 0.12 + i * 0.55)) * 68
            : 12 + Math.abs(Math.sin(i * 0.7)) * 26;
          ctx.fillStyle = i % 2 === 0 ? 'rgba(251, 191, 36, 0.75)' : 'rgba(56, 189, 248, 0.75)';
          ctx.fillRect(40 + i * barW, h - 24 - amp, Math.max(4, barW - 4), amp);
        }
      }

      if (playing) {
        tick += 1;
        setProgress((prev) => (prev >= 100 ? 0 : prev + 0.6));
        rafId = requestAnimationFrame(drawFrame);
      }
    };

    drawFrame();
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [playing, videoTheme, videoUrl]);

  if (videoUrl) {
    return (
      <div className="rounded-2xl overflow-hidden bg-slate-950 border border-slate-200">
        {videoTitle && (
          <div className="px-3.5 py-2 bg-slate-900 text-white text-xs font-semibold flex items-center gap-2">
            <Video className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{videoTitle}</span>
          </div>
        )}
        <video src={videoUrl} controls playsInline className="w-full max-h-60 object-cover" />
      </div>
    );
  }

  return (
    <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-800/30">
      <canvas ref={canvasRef} width={560} height={180} className="w-full h-44 object-cover block" />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-slate-950/40 flex flex-col justify-between p-3.5">
        <div className="flex items-center justify-between gap-2 text-white">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold truncate">
            <Video className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{videoTitle || 'Party Highlight Clip'}</span>
          </div>
          <span className="font-mono-num text-[11px] font-semibold text-slate-200 bg-black/45 px-2 py-0.5 rounded-md shrink-0">
            {videoDuration}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            aria-label={playing ? 'Pause friend video' : 'Play friend video'}
            className="w-10 h-10 rounded-full bg-white/95 hover:bg-white text-slate-950 flex items-center justify-center shadow-md shrink-0 transition-transform active:scale-95"
          >
            {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>
          <div className="flex-1 h-1.5 rounded-full bg-white/25 overflow-hidden">
            <div
              className="h-full bg-amber-400 transition-all duration-100"
              style={{ width: `${Math.min(100, progress)}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export const DiscoverTab: React.FC<DiscoverTabProps> = ({
  user,
  friends,
  posts,
  families,
  onCollectDailyCp,
  onCreatePost,
  onLikePost,
  onBoostPostCp,
  onCommentPost,
  onSendCpGift,
  onJoinFamily,
  onCreateFamily,
  onContributeFamily,
  onAddFamilyMember,
  onActivateBarrier,
  onStealFamily,
  onClaimChest,
  onSpinGacha,
  onOpenChat,
}) => {
  const [feedFilter, setFeedFilter] = useState<'all' | 'post' | 'video'>('all');
  const [showAllPosts, setShowAllPosts] = useState(false);
  const [showComposer, setShowComposer] = useState(false);
  const [composerType, setComposerType] = useState<'post' | 'video'>('post');
  const [postText, setPostText] = useState('');
  const [postTag, setPostTag] = useState('Party Moment');
  const [videoTitle, setVideoTitle] = useState('');
  const [videoTheme, setVideoTheme] = useState<'concert' | 'carrom' | 'party'>('concert');
  const [videoUrl, setVideoUrl] = useState<string | undefined>(undefined);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [statusBanner, setStatusBanner] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  const [activeOption, setActiveOption] = useState<'cp' | 'family' | 'gacha'>('cp');

  // Option 1: CP Gift state
  const [selectedGiftFriendId, setSelectedGiftFriendId] = useState<string>(friends[0]?.id || '');
  const [selectedGiftId, setSelectedGiftId] = useState<string>(GIFT_CATALOG[0].id);
  const [sendingGift, setSendingGift] = useState(false);

  // Option 2: Family state
  const [showCreateFamily, setShowCreateFamily] = useState(false);
  const [famName, setFamName] = useState('');
  const [famMotto, setFamMotto] = useState('');
  const [famCrest, setFamCrest] = useState('🔥');
  const [famErr, setFamErr] = useState<string | null>(null);
  const [memberToAddId, setMemberToAddId] = useState<string>('');

  // Option 3: Spin Wheel Gacha state
  const [wheelAngle, setWheelAngle] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [latestReward, setLatestReward] = useState<GachaReward | null>(null);

  useEffect(() => {
    if (!selectedGiftFriendId && friends.length > 0) {
      setSelectedGiftFriendId(friends[0].id);
    }
  }, [friends, selectedGiftFriendId]);

  const myFamily = families.find((f) => f.id === user.familyId) || null;
  const eligibleAddFriends = friends.filter((f) => !myFamily?.memberIds.includes(f.id));

  useEffect(() => {
    if (eligibleAddFriends.length > 0 && !eligibleAddFriends.some((f) => f.id === memberToAddId)) {
      setMemberToAddId(eligibleAddFriends[0].id);
    }
  }, [eligibleAddFriends, memberToAddId]);

  const today = new Date().toISOString().slice(0, 10);
  const collectedToday = user.lastCheckinDate === today;
  const freeSpinAvailable = user.lastGachaFreeDate !== today;

  const showNotice = (msg: string) => {
    setErrorBanner(null);
    setStatusBanner(msg);
  };

  const showErr = (msg: string) => {
    setStatusBanner(null);
    setErrorBanner(msg);
  };

  const filteredPosts = posts.filter((p) => {
    const kind = p.mediaType === 'video' ? 'video' : 'post';
    if (feedFilter === 'all') return true;
    return kind === feedFilter;
  });

  const visiblePosts = showAllPosts ? filteredPosts : filteredPosts.slice(0, 2);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      showErr('Video clip must be under 1.5 MB. Pick a shorter clip or use a party highlight theme.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setVideoUrl(reader.result);
        if (!videoTitle.trim()) {
          setVideoTitle(file.name.replace(/\.[^.]+$/, '').slice(0, 50));
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!postText.trim()) return;
    const err = await onCreatePost({
      content: postText.trim(),
      tag: postTag,
      mediaType: composerType,
      videoTitle: composerType === 'video' ? videoTitle.trim() || 'Party Highlight Video' : undefined,
      videoDuration: composerType === 'video' ? '0:20' : undefined,
      videoUrl: composerType === 'video' ? videoUrl : undefined,
      videoTheme: composerType === 'video' ? videoTheme : undefined,
    });
    if (err) {
      showErr(err);
    } else {
      setPostText('');
      setVideoTitle('');
      setVideoUrl(undefined);
      setShowComposer(false);
      showNotice(composerType === 'video' ? 'Friend video shared! +25 CP earned.' : 'Moment published! +25 CP earned.');
    }
  };

  const handleCollectCp = async () => {
    const res = await onCollectDailyCp();
    if ('error' in res) showErr(res.error);
    else {
      playCoinChime();
      showNotice(`Collected +${res.bonusCp} CP and +${res.bonusCoins} Coins!`);
    }
  };

  const handleSendCpGiftSubmit = async () => {
    if (!selectedGiftFriendId || sendingGift) return;
    setSendingGift(true);
    const res = await onSendCpGift(selectedGiftFriendId, selectedGiftId);
    setSendingGift(false);
    if ('error' in res) {
      showErr(res.error);
    } else {
      playCoinChime();
      const returnPart = res.coinReturn > 0 ? ` · +${res.coinReturn.toLocaleString()} Return Coins` : '';
      showNotice(
        `Sent ${res.giftName} to ${res.friendName}! +${res.cpEarned} CP · +${res.charmEarned} Charm${returnPart}`
      );
    }
  };

  const handleCreateFamilySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFamErr(null);
    const err = await onCreateFamily(famName, famMotto, famCrest);
    if (err) setFamErr(err);
    else {
      playCoinChime();
      setShowCreateFamily(false);
      setFamName('');
      setFamMotto('');
      showNotice('Your new Family is live!');
    }
  };

  const handleSpinWheel = async () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setErrorBanner(null);
    const res = await onSpinGacha();
    if ('error' in res) {
      setIsSpinning(false);
      showErr(res.error);
      return;
    }

    const sliceDeg = 360 / GACHA_REWARDS.length;
    const targetMod = (360 - res.rewardIndex * sliceDeg + 360) % 360;
    const currentMod = ((wheelAngle % 360) + 360) % 360;
    const delta = (targetMod - currentMod + 360) % 360;
    const nextAngle = wheelAngle + 360 * 5 + delta;
    setWheelAngle(nextAngle);

    window.setTimeout(() => {
      setIsSpinning(false);
      setLatestReward(res.reward);
      playCoinChime();
      showNotice(
        `Won ${res.reward.icon} ${res.reward.name} (+${res.reward.coinsBonus} Coins, +${res.reward.cpBonus} CP)!`
      );
    }, 3650);
  };

  const selectedGift = GIFT_CATALOG.find((g) => g.id === selectedGiftId) || GIFT_CATALOG[0];
  const selectedFriend = friends.find((f) => f.id === selectedGiftFriendId) || friends[0];

  const getBarrierCountdown = (until: number) => {
    const ms = until - Date.now();
    if (ms <= 0) return null;
    const mins = Math.ceil(ms / 60000);
    const hrs = Math.floor(mins / 60);
    const remMins = mins % 60;
    return hrs > 0 ? `${hrs}h ${remMins}m` : `${remMins}m`;
  };

  const sliceAngle = 360 / GACHA_REWARDS.length;
  const polarToCartesian = (cx: number, cy: number, r: number, angleDeg: number) => {
    const rad = (angleDeg * Math.PI) / 180;
    return {
      x: cx + r * Math.cos(rad),
      y: cy + r * Math.sin(rad),
    };
  };

  const createSlicePath = (index: number) => {
    const startAngle = index * sliceAngle - 90 - sliceAngle / 2;
    const endAngle = startAngle + sliceAngle;
    const start = polarToCartesian(160, 160, 150, startAngle);
    const end = polarToCartesian(160, 160, 150, endAngle);
    return `M 160 160 L ${start.x} ${start.y} A 150 150 0 0 1 ${end.x} ${end.y} Z`;
  };

  const rarityBadgeClass = (rarity: string) => {
    if (rarity === 'Mythic') return 'text-amber-700 bg-amber-50 border-amber-200';
    if (rarity === 'Epic') return 'text-violet-700 bg-violet-50 border-violet-200';
    if (rarity === 'Rare') return 'text-sky-700 bg-sky-50 border-sky-200';
    return 'text-slate-600 bg-slate-100 border-slate-200';
  };

  return (
    <div className="max-w-5xl mx-auto px-4 pt-4 pb-28 space-y-5">
      {/* 1. VERY TOP SECTION: Friends Posts & Videos */}
      <section className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-lg sm:text-xl font-extrabold text-slate-900">
              Friends Posts &amp; Videos
            </h2>
            <p className="text-xs text-slate-500">
              Watch clips, like highlights, and boost friends’ moments
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="inline-flex p-1 rounded-xl bg-slate-100">
              {(['all', 'video', 'post'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setFeedFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    feedFilter === tab ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {tab === 'all' ? 'All' : tab === 'video' ? 'Videos' : 'Posts'}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowComposer((v) => !v)}
              className="h-9 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>
          </div>
        </div>

        {showComposer && (
          <form onSubmit={handlePostSubmit} className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setComposerType('post')}
                className={`h-9 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 border ${
                  composerType === 'post'
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-slate-700 border-slate-200'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Post</span>
              </button>
              <button
                type="button"
                onClick={() => setComposerType('video')}
                className={`h-9 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 border ${
                  composerType === 'video'
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-slate-700 border-slate-200'
                }`}
              >
                <Film className="w-3.5 h-3.5" />
                <span>Video</span>
              </button>

              <select
                value={postTag}
                onChange={(e) => setPostTag(e.target.value)}
                className="ml-auto text-xs font-semibold text-indigo-700 bg-white rounded-xl px-2.5 h-9 border border-slate-200"
              >
                <option value="Party Moment">Party Moment</option>
                <option value="Voice Room Clip">Voice Room Clip</option>
                <option value="Carrom & Uno">Carrom &amp; Uno</option>
                <option value="Looking for Squad">Looking for Squad</option>
              </select>
            </div>

            {composerType === 'video' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <input
                  type="text"
                  value={videoTitle}
                  onChange={(e) => setVideoTitle(e.target.value)}
                  placeholder="Video title (e.g. Room Duet Finale)"
                  maxLength={80}
                  className="h-10 px-3 rounded-xl border border-slate-200 bg-white text-xs text-slate-900"
                />
                <div className="flex items-center gap-2">
                  <select
                    value={videoTheme}
                    onChange={(e) => setVideoTheme(e.target.value as 'concert' | 'carrom' | 'party')}
                    className="flex-1 h-10 px-2.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700"
                  >
                    <option value="concert">Stage Visualizer</option>
                    <option value="carrom">Carrom Highlight</option>
                    <option value="party">Party Beat Clip</option>
                  </select>
                  <label className="h-10 px-3 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-700 text-xs font-semibold inline-flex items-center cursor-pointer whitespace-nowrap">
                    <span>{videoUrl ? 'Clip Ready' : 'Upload MP4'}</span>
                    <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" />
                  </label>
                </div>
              </div>
            )}

            <textarea
              rows={2}
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
              placeholder={
                composerType === 'video'
                  ? 'Describe your shared friend video...'
                  : 'Share a win, room invite, or moment with friends...'
              }
              maxLength={280}
              className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowComposer(false)}
                className="h-9 px-4 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-600"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="h-9 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Publish (+25 CP)</span>
              </button>
            </div>
          </form>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {visiblePosts.map((post) => {
            const liked = post.likes.includes(user.id);
            const isVideo = post.mediaType === 'video';
            return (
              <article
                key={post.id}
                className="rounded-2xl border border-slate-200 bg-slate-50/60 p-4 flex flex-col justify-between gap-3"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <AvatarBadge dp={post.authorDp} name={post.authorName} vipLevel={post.authorVip} size="sm" />
                      <div className="min-w-0">
                        <div className="font-semibold text-sm text-slate-900 truncate">{post.authorName}</div>
                        <div className="text-[11px] text-slate-500 truncate">
                          {isVideo ? 'Video' : 'Post'} · {post.tag} · VIP {post.authorVip}
                        </div>
                      </div>
                    </div>
                    <span className="font-mono-num text-xs font-bold text-amber-600 shrink-0">
                      +{post.cpBoosts} CP
                    </span>
                  </div>

                  {isVideo && (
                    <PlayableFriendVideo
                      videoUrl={post.videoUrl}
                      videoTitle={post.videoTitle}
                      videoDuration={post.videoDuration}
                      videoTheme={post.videoTheme}
                    />
                  )}

                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">{post.content}</p>
                </div>

                <div className="space-y-2.5 pt-2 border-t border-slate-200/70">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className={`text-xs font-semibold inline-flex items-center gap-1 py-1 ${
                        liked ? 'text-rose-600' : 'text-slate-600 hover:text-rose-600'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${liked ? 'fill-rose-600' : ''}`} />
                      <span>{post.likes.length}</span>
                    </button>

                    <button
                      onClick={() => {
                        playCoinChime();
                        onBoostPostCp(post.id);
                      }}
                      className="text-xs font-semibold text-amber-600 hover:text-amber-700 inline-flex items-center gap-1 py-1"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>+20 CP</span>
                    </button>

                    <span className="text-xs text-slate-500 inline-flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      <span>{post.comments.length}</span>
                    </span>

                    {post.authorId !== user.id && (
                      <button
                        type="button"
                        onClick={() => onOpenChat(post.authorId)}
                        className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 py-1 px-2 rounded-lg hover:bg-indigo-50"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Message</span>
                      </button>
                    )}
                  </div>

                  {post.comments.length > 0 && (
                    <div className="space-y-1 bg-white rounded-xl border border-slate-200/70 p-2.5">
                      {post.comments.slice(-2).map((c) => (
                        <div key={c.id} className="text-[11px] text-slate-700">
                          <span className="font-bold text-slate-900">{c.userName}: </span>
                          <span>{c.text}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const txt = (commentInputs[post.id] || '').trim();
                      if (!txt) return;
                      onCommentPost(post.id, txt);
                      setCommentInputs((prev) => ({ ...prev, [post.id]: '' }));
                    }}
                    className="flex items-center gap-1.5"
                  >
                    <input
                      type="text"
                      value={commentInputs[post.id] || ''}
                      onChange={(e) => setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))}
                      placeholder="Reply..."
                      className="flex-1 h-8 px-3 rounded-lg bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button type="submit" className="h-8 px-3 rounded-lg bg-slate-900 text-white text-xs font-semibold">
                      Send
                    </button>
                  </form>
                </div>
              </article>
            );
          })}
        </div>

        {filteredPosts.length > 2 && (
          <div className="flex justify-center">
            <button
              type="button"
              onClick={() => setShowAllPosts((v) => !v)}
              className="h-9 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold inline-flex items-center gap-1.5"
            >
              {showAllPosts ? (
                <>
                  <ChevronUp className="w-4 h-4" />
                  <span>Show Less</span>
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4" />
                  <span>View All {filteredPosts.length} Posts &amp; Videos</span>
                </>
              )}
            </button>
          </div>
        )}
      </section>

      {statusBanner && (
        <div className="rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs font-semibold text-emerald-800">
          {statusBanner}
        </div>
      )}
      {errorBanner && (
        <div className="rounded-2xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs font-semibold text-rose-700">
          {errorBanner}
        </div>
      )}

      {/* 2. THREE SPECIFIC OPTIONS BELOW: 1) CP, 2) Family, 3) Spin Wheel Gacha */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          type="button"
          onClick={() => setActiveOption('cp')}
          className={`text-left rounded-2xl border p-4 transition-all flex items-center gap-3.5 ${
            activeOption === 'cp'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
              : 'bg-white text-slate-900 border-slate-200 hover:border-indigo-300 shadow-xs'
          }`}
        >
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              activeOption === 'cp' ? 'bg-white/20 text-amber-300' : 'bg-amber-100 text-amber-600'
            }`}
          >
            <Gift className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="font-display text-sm font-extrabold truncate">1. CP Gifting</div>
            <div className={`text-xs truncate ${activeOption === 'cp' ? 'text-indigo-100' : 'text-slate-500'}`}>
              <span className="font-mono-num font-bold">{user.cpPoints.toLocaleString()}</span> CP · Send gifts
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveOption('family')}
          className={`text-left rounded-2xl border p-4 transition-all flex items-center gap-3.5 ${
            activeOption === 'family'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
              : 'bg-white text-slate-900 border-slate-200 hover:border-indigo-300 shadow-xs'
          }`}
        >
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              activeOption === 'family' ? 'bg-white/20 text-emerald-300' : 'bg-indigo-100 text-indigo-600'
            }`}
          >
            <Shield className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="font-display text-sm font-extrabold truncate">2. Family &amp; Chests</div>
            <div className={`text-xs truncate ${activeOption === 'family' ? 'text-indigo-100' : 'text-slate-500'}`}>
              {myFamily ? myFamily.name : 'Create · Barrier & Steal'}
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveOption('gacha')}
          className={`text-left rounded-2xl border p-4 transition-all flex items-center gap-3.5 ${
            activeOption === 'gacha'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
              : 'bg-white text-slate-900 border-slate-200 hover:border-indigo-300 shadow-xs'
          }`}
        >
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              activeOption === 'gacha' ? 'bg-white/20 text-amber-300' : 'bg-rose-100 text-rose-600'
            }`}
          >
            <RotateCw className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="font-display text-sm font-extrabold truncate">3. Spin Wheel Gacha</div>
            <div className={`text-xs truncate ${activeOption === 'gacha' ? 'text-indigo-100' : 'text-slate-500'}`}>
              {freeSpinAvailable ? 'Free Daily Spin Ready' : 'Win items & rides'}
            </div>
          </div>
        </button>
      </div>

      {/* OPTION 1 PANEL: CP BY SENDING VIRTUAL GIFTS */}
      {activeOption === 'cp' && (
        <section className="space-y-4">
          <div className="rounded-3xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-700 text-white p-5 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-indigo-100">
                Your Contribution Power · <span className="font-mono-num font-bold text-amber-300">{user.cpPoints.toLocaleString()} CP</span>
              </div>
              <h3 className="font-display text-lg sm:text-xl font-extrabold mt-0.5">
                Earn CP by Sending Virtual Gifts
              </h3>
              <p className="text-xs text-indigo-100 mt-1">
                Every 5 coins gifted = +1 Charm on your ID · Larger gifts return up to 35% coins &amp; grow VIP.
              </p>
            </div>
            <button
              onClick={handleCollectCp}
              disabled={collectedToday}
              className={`h-11 px-4 rounded-2xl text-xs font-bold whitespace-nowrap shrink-0 inline-flex items-center gap-2 ${
                collectedToday
                  ? 'bg-white/15 text-indigo-100 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow'
              }`}
            >
              {collectedToday ? <CheckCircle2 className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
              <span>{collectedToday ? 'Daily CP Claimed' : `Daily Bonus +${80 + user.vipLevel * 15} CP`}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-3">
              <div className="text-sm font-display font-bold text-slate-900">1. Choose a Friend</div>
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {friends.map((f) => {
                  const selected = f.id === selectedGiftFriendId;
                  return (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setSelectedGiftFriendId(f.id)}
                      className={`w-full text-left p-2.5 rounded-2xl border flex items-center justify-between gap-2.5 transition-colors ${
                        selected
                          ? 'bg-indigo-50 border-indigo-500'
                          : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <AvatarBadge dp={f.dp} name={f.name} vipLevel={f.vipLevel} size="sm" />
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">{f.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono-num truncate">
                            ID {f.id} · VIP {f.vipLevel} · ✨ {f.charmPoints.toLocaleString()} Charm · {f.cpPoints.toLocaleString()} CP
                          </div>
                        </div>
                      </div>
                      {selected && (
                        <span className="text-[11px] font-bold text-indigo-600 shrink-0">Selected</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between gap-2">
                <div className="text-sm font-display font-bold text-slate-900">2. Select a Virtual Gift</div>
                <span className="font-mono-num text-xs font-semibold text-amber-600">
                  Balance: {user.coins.toLocaleString()} Coins
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {GIFT_CATALOG.map((gift) => {
                  const active = gift.id === selectedGiftId;
                  return (
                    <button
                      key={gift.id}
                      type="button"
                      onClick={() => setSelectedGiftId(gift.id)}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        active
                          ? 'bg-amber-50 border-amber-500 shadow-xs'
                          : 'bg-slate-50/60 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="text-2xl">{gift.emoji}</div>
                      <div className="mt-1.5 text-xs font-bold text-slate-900 truncate">{gift.name}</div>
                      <div className="mt-0.5 text-[11px] font-mono-num text-slate-500">
                        {gift.coins.toLocaleString()} Coins
                      </div>
                      <div className="mt-1 text-[11px] font-mono-num font-bold text-emerald-700">
                        +{gift.cpReward.toLocaleString()} CP · +{computeGiftCharm(gift.coins)} Charm
                      </div>
                      <div className="mt-0.5 text-[10px] font-mono-num font-semibold text-amber-600">
                        +{gift.coinReturn.toLocaleString()} Return Coins
                      </div>
                    </button>
                  );
                })}
              </div>

              <button
                type="button"
                disabled={!selectedFriend || sendingGift}
                onClick={handleSendCpGiftSubmit}
                className="w-full h-12 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors px-3"
              >
                <Gift className="w-4 h-4 shrink-0" />
                <span className="truncate">
                  Send {selectedGift.emoji} {selectedGift.name} to {selectedFriend?.name || 'Friend'} (+
                  {selectedGift.cpReward} CP · +{computeGiftCharm(selectedGift.coins)} Charm · +{selectedGift.coinReturn}{' '}
                  Return)
                </span>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* OPTION 2 PANEL: FAMILY (CREATE, ADD MEMBERS, BARRIER & STEAL, ACTIVITY CHESTS) */}
      {activeOption === 'family' && (
        <section className="space-y-4">
          {/* Activity & Gifting Chests */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-display text-base font-extrabold text-slate-900">
                  Activity &amp; Gifting Reward Chests
                </h3>
                <p className="text-xs text-slate-500">
                  Gift friends, shield your clan, or raid rivals to fill your activity gauge and unlock chests.
                </p>
              </div>
              <div className="px-3.5 py-2 rounded-xl bg-amber-50 border border-amber-200 text-xs font-bold text-amber-900 font-mono-num">
                Activity: {user.familyActivityPoints.toLocaleString()} pts
              </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {ACTIVITY_CHESTS.map((chest) => {
                const claimed = user.claimedChests.includes(chest.id);
                const unlocked = user.familyActivityPoints >= chest.requiredPoints;
                const pct = Math.min(100, Math.round((user.familyActivityPoints / chest.requiredPoints) * 100));
                return (
                  <div
                    key={chest.id}
                    className={`rounded-2xl border p-3.5 flex flex-col justify-between gap-3 ${
                      claimed
                        ? 'bg-emerald-50/50 border-emerald-200'
                        : unlocked
                        ? 'bg-amber-50/70 border-amber-300'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">{chest.icon}</span>
                        <span className="text-[11px] font-bold text-slate-500 font-mono-num">
                          {chest.requiredPoints.toLocaleString()} pts
                        </span>
                      </div>
                      <div className="mt-2 text-xs font-extrabold text-slate-900">{chest.name}</div>
                      <div className="text-[11px] text-slate-600 font-mono-num mt-0.5">
                        +{chest.rewardCoins} Coins · +{chest.rewardCp} CP
                      </div>
                      <div className="mt-2 h-1.5 rounded-full bg-slate-200 overflow-hidden">
                        <div className="h-full bg-indigo-600" style={{ width: `${pct}%` }} />
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={claimed || !unlocked}
                      onClick={async () => {
                        const res = await onClaimChest(chest.id);
                        if ('error' in res) showErr(res.error);
                        else {
                          playCoinChime();
                          showNotice(
                            `Opened ${res.chest.name}! Claimed +${res.chest.rewardCoins} Coins & +${res.chest.rewardCp} CP.`
                          );
                        }
                      }}
                      className={`h-9 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 ${
                        claimed
                          ? 'bg-emerald-100 text-emerald-700 cursor-default'
                          : unlocked
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                          : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {claimed ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Claimed</span>
                        </>
                      ) : unlocked ? (
                        <span>Open Chest</span>
                      ) : (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>Locked</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Your Family Interactive Controls (Add Members + Barrier) */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-display text-base font-extrabold text-slate-900">
                {myFamily ? `Your Family: ${myFamily.crest} ${myFamily.name}` : 'Join or Create a Family'}
              </h3>
              <p className="text-xs text-slate-500">
                Add friends, raise a Barrier to block raids, or Steal CP from rival clans
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowCreateFamily(true)}
              className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Create Family (500 Coins)</span>
            </button>
          </div>

          {myFamily && (
            <div className="bg-white rounded-3xl border border-indigo-200 p-5 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-2xl">
                    {myFamily.crest}
                  </div>
                  <div>
                    <div className="font-display text-base font-extrabold text-slate-900">{myFamily.name}</div>
                    <div className="text-xs text-slate-500 font-mono-num">
                      Lv.{myFamily.level} · {myFamily.totalCp.toLocaleString()} CP · {myFamily.memberIds.length}/
                      {myFamily.maxMembers} Members
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {getBarrierCountdown(myFamily.barrierUntil) ? (
                    <span className="h-9 px-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold inline-flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Barrier Active ({getBarrierCountdown(myFamily.barrierUntil)})</span>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={async () => {
                        const err = await onActivateBarrier(myFamily.id);
                        if (err) showErr(err);
                        else {
                          playCoinChime();
                          showNotice(`Barrier Shield activated on ${myFamily.name} for 2 hours! +40 CP earned.`);
                        }
                      }}
                      className="h-9 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <Shield className="w-3.5 h-3.5" />
                      <span>Activate Barrier (80 Coins)</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={async () => {
                      const err = await onContributeFamily(myFamily.id);
                      if (err) showErr(err);
                      else {
                        playCoinChime();
                        showNotice(`Contributed 50 Coins → +100 Family CP & +100 Activity!`);
                      }
                    }}
                    className="h-9 px-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold whitespace-nowrap"
                  >
                    Boost +100 CP (50 Coins)
                  </button>
                </div>
              </div>

              {/* Add Member to Family */}
              <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="text-xs font-semibold text-slate-700 flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>Add Friend as Family Member</span>
                </div>
                {eligibleAddFriends.length > 0 ? (
                  <div className="flex items-center gap-2">
                    <select
                      value={memberToAddId}
                      onChange={(e) => setMemberToAddId(e.target.value)}
                      className="h-9 px-3 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-800"
                    >
                      {eligibleAddFriends.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name} (VIP {f.vipLevel})
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!memberToAddId) return;
                        const res = await onAddFamilyMember(myFamily.id, memberToAddId);
                        if ('error' in res) showErr(res.error);
                        else showNotice(`Added ${res.addedName} to ${myFamily.name}! +30 Activity earned.`);
                      }}
                      className="h-9 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold whitespace-nowrap"
                    >
                      Add Member
                    </button>
                  </div>
                ) : (
                  <span className="text-xs text-slate-500">All listed friends are already in {myFamily.name}.</span>
                )}
              </div>
            </div>
          )}

          {/* All / Rival Families with Steal & Barrier Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {families.map((fam) => {
              const isMember = user.familyId === fam.id;
              const shieldLeft = getBarrierCountdown(fam.barrierUntil);
              return (
                <div
                  key={fam.id}
                  className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between gap-4"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-2xl">
                          {fam.crest}
                        </div>
                        <div>
                          <h4 className="font-display text-base font-bold text-slate-900">{fam.name}</h4>
                          <div className="text-xs text-slate-500">
                            Lv.{fam.level} · Leader: {fam.leaderName}
                          </div>
                        </div>
                      </div>
                      <span className="font-mono-num text-xs font-bold text-amber-600">
                        {fam.totalCp.toLocaleString()} CP
                      </span>
                    </div>
                    <p className="mt-2.5 text-xs text-slate-600">{fam.motto}</p>
                    <div className="mt-3 text-xs text-slate-500 flex flex-wrap items-center gap-3">
                      <span className="inline-flex items-center gap-1">
                        <Users className="w-3.5 h-3.5" /> {fam.memberIds.length}/{fam.maxMembers} Members
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 font-semibold ${
                          shieldLeft ? 'text-emerald-700' : 'text-slate-500'
                        }`}
                      >
                        {shieldLeft ? (
                          <>
                            <ShieldCheck className="w-3.5 h-3.5" /> Barrier Active ({shieldLeft})
                          </>
                        ) : (
                          <>
                            <Shield className="w-3.5 h-3.5" /> Unshielded
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => onJoinFamily(fam.id)}
                      className={`flex-1 h-10 rounded-xl text-xs font-semibold transition-colors ${
                        isMember
                          ? 'bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                      }`}
                    >
                      {isMember ? 'Leave Family' : 'Join Family'}
                    </button>

                    {!isMember && (
                      <button
                        type="button"
                        onClick={async () => {
                          const res = await onStealFamily(fam.id);
                          if ('error' in res) showErr(res.error);
                          else if (res.blocked) showErr(res.message);
                          else {
                            playCoinChime();
                            showNotice(res.message);
                          }
                        }}
                        className="h-10 px-3.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <Swords className="w-3.5 h-3.5" />
                        <span>Steal CP</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* OPTION 3 PANEL: SPIN WHEEL GACHA */}
      {activeOption === 'gacha' && (
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col items-center gap-5">
            <div className="text-center">
              <h3 className="font-display text-lg font-extrabold text-slate-900">Party Spin Wheel Gacha</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Spin to win rare entry rides, chat frames, coins &amp; CP bonuses!
              </p>
            </div>

            <div className="relative w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center">
              {/* Top Pointer */}
              <div
                aria-hidden="true"
                className="absolute -top-2 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-l-[12px] border-r-[12px] border-t-[20px] border-l-transparent border-r-transparent border-t-amber-400 drop-shadow"
              />

              {/* Rotating Wheel */}
              <div
                className="w-full h-full rounded-full shadow-xl border-4 border-slate-900 overflow-hidden transition-transform duration-[3600ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
                style={{ transform: `rotate(${wheelAngle}deg)` }}
              >
                <svg viewBox="0 0 320 320" className="w-full h-full">
                  {GACHA_REWARDS.map((item, idx) => {
                    const labelAngle = idx * sliceAngle - 90;
                    const pos = polarToCartesian(160, 160, 102, labelAngle);
                    return (
                      <g key={item.id}>
                        <path
                          d={createSlicePath(idx)}
                          fill={item.color}
                          stroke="#ffffff"
                          strokeWidth="2"
                        />
                        <text
                          x={pos.x}
                          y={pos.y}
                          textAnchor="middle"
                          dominantBaseline="central"
                          fontSize="24"
                          transform={`rotate(${idx * sliceAngle}, ${pos.x}, ${pos.y})`}
                        >
                          {item.icon}
                        </text>
                      </g>
                    );
                  })}
                  <circle cx="160" cy="160" r="30" fill="#0f172a" stroke="#fbbf24" strokeWidth="4" />
                  <text
                    x="160"
                    y="160"
                    textAnchor="middle"
                    dominantBaseline="central"
                    fill="#fbbf24"
                    fontSize="11"
                    fontWeight="800"
                  >
                    SPIN
                  </text>
                </svg>
              </div>
            </div>

            <button
              type="button"
              disabled={isSpinning}
              onClick={handleSpinWheel}
              className="w-full max-w-xs h-12 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 hover:brightness-105 disabled:opacity-60 text-slate-950 font-extrabold text-sm shadow-md inline-flex items-center justify-center gap-2 transition-all"
            >
              <RotateCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
              <span>
                {isSpinning
                  ? 'Spinning...'
                  : freeSpinAvailable
                  ? 'Use Free Daily Spin'
                  : 'Spin Wheel (100 Coins)'}
              </span>
            </button>
          </div>

          <div className="lg:col-span-6 space-y-4">
            {latestReward && (
              <div className="bg-gradient-to-r from-indigo-600 to-violet-700 text-white rounded-3xl p-5 shadow-md flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center text-3xl shrink-0">
                  {latestReward.icon}
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-amber-300">
                    {latestReward.rarity} Reward Unlocked
                  </div>
                  <div className="font-display text-lg font-extrabold truncate">{latestReward.name}</div>
                  <div className="text-xs text-indigo-100 font-mono-num">
                    +{latestReward.coinsBonus} Coins · +{latestReward.cpBonus} CP
                    {latestReward.unlockShopId ? ' · Equipped Item Unlocked in Me Shop!' : ''}
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-display text-sm font-extrabold text-slate-900">
                  Prize Pool ({GACHA_REWARDS.length} Items)
                </h4>
                <span className="text-xs text-slate-500 font-mono-num">
                  Balance: {user.coins.toLocaleString()} Coins
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {GACHA_REWARDS.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-xl border border-slate-200 bg-slate-50/70 p-2.5 flex items-center gap-2.5"
                  >
                    <span className="text-xl shrink-0">{r.icon}</span>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 truncate">{r.name}</div>
                      <span
                        className={`inline-block mt-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold border ${rarityBadgeClass(
                          r.rarity
                        )}`}
                      >
                        {r.rarity}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-3">
              <h4 className="font-display text-sm font-extrabold text-slate-900">
                Your Won Items ({user.gachaInventory.length})
              </h4>
              {user.gachaInventory.length === 0 ? (
                <p className="text-xs text-slate-500">
                  Spin the wheel to collect items, chat frames, and VIP entry rides!
                </p>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
                  {user.gachaInventory.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-xl border border-slate-200 bg-slate-50 p-2.5 flex items-center gap-2"
                    >
                      <span className="text-xl shrink-0">{item.icon}</span>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900 truncate">{item.name}</div>
                        <div className="text-[10px] text-slate-500">{item.rarity}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Create Family Modal */}
      {showCreateFamily && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-display text-lg font-bold text-slate-900">Create New Family</h3>
              <button
                onClick={() => setShowCreateFamily(false)}
                className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateFamilySubmit} className="p-6 space-y-4">
              {famErr && (
                <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-2.5 text-xs font-semibold text-rose-700">
                  {famErr}
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Family Crest</label>
                <div className="flex items-center gap-2">
                  {['🔥', '👑', '🌟', '🐉', '🛡️', '⚡'].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFamCrest(c)}
                      className={`w-10 h-10 rounded-xl text-xl border ${
                        famCrest === c ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Family Name</label>
                <input
                  type="text"
                  required
                  value={famName}
                  onChange={(e) => setFamName(e.target.value)}
                  placeholder="e.g. Velvet Strikers"
                  maxLength={26}
                  className="w-full h-11 px-4 rounded-xl border border-slate-300 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Motto</label>
                <input
                  type="text"
                  value={famMotto}
                  onChange={(e) => setFamMotto(e.target.value)}
                  placeholder="Play fair, win big, level together."
                  maxLength={90}
                  className="w-full h-11 px-4 rounded-xl border border-slate-300 text-sm"
                />
              </div>
              <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900 flex items-center gap-2 font-semibold">
                <Coins className="w-4 h-4 text-amber-600" />
                <span>Creation Cost: 500 Coins (counts toward VIP level!)</span>
              </div>
              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm"
              >
                Create Family
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
