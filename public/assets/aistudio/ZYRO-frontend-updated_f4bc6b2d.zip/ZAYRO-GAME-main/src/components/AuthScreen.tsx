import React, { useState } from 'react';
import { Mail, Phone, ShieldCheck, ArrowRight, Sparkles, CheckCircle2, Upload } from 'lucide-react';
import { AuthProvider, REAL_PFP_PRESETS, UserProfile } from '../shared/types';
import { AvatarBadge } from './AvatarBadge';

interface AuthScreenProps {
  onAuthenticated: (token: string, user: UserProfile) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthenticated }) => {
  const [provider, setProvider] = useState<AuthProvider>('gmail');
  const [identifier, setIdentifier] = useState('weplayuser2024@gmail.com');
  const [displayName, setDisplayName] = useState('');
  const [selectedDp, setSelectedDp] = useState<string>(REAL_PFP_PRESETS[0].id);
  const [step, setStep] = useState<'identify' | 'verify'>('identify');
  const [codeInput, setCodeInput] = useState('');
  const [previewCode, setPreviewCode] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleUploadPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 220;
        canvas.height = 220;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const minDim = Math.min(img.width, img.height);
          const sx = (img.width - minDim) / 2;
          const sy = (img.height - minDim) / 2;
          ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, 220, 220);
          setSelectedDp(canvas.toDataURL('image/jpeg', 0.85));
        }
      };
      if (typeof reader.result === 'string') img.src = reader.result;
    };
    reader.readAsDataURL(file);
  };

  const handleSelectProvider = (next: AuthProvider) => {
    setProvider(next);
    setStep('identify');
    setError(null);
    setPreviewCode(null);
    setCodeInput('');
    if (next === 'gmail') setIdentifier('weplayuser2024@gmail.com');
    if (next === 'facebook') setIdentifier('');
    if (next === 'phone') setIdentifier('');
  };

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/request-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider, identifier }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not send verification code.');
      } else {
        setPreviewCode(data.verificationCodePreview);
        setCodeInput(data.verificationCodePreview);
        setStep('verify');
      }
    } catch {
      setError('Network error while requesting verification code.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider, identifier, code: codeInput, displayName, dp: selectedDp }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Verification failed.');
      } else {
        onAuthenticated(data.token, data.user);
      }
    } catch {
      setError('Network error while signing in.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F6FB] flex items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 bg-white rounded-3xl shadow-xl border border-slate-200/80 overflow-hidden">
        {/* Left Visual Showcase */}
        <div className="lg:col-span-6 bg-gradient-to-br from-indigo-700 via-indigo-600 to-violet-700 p-8 sm:p-10 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="relative z-10">
            <div className="font-display text-2xl font-extrabold tracking-tight">JoyPlay</div>
            <h1 className="mt-6 font-display text-3xl sm:text-4xl font-extrabold leading-tight tracking-tight text-balance">
              Party games, live 10-seat voice rooms, and VIP entrances.
            </h1>
            <p className="mt-4 text-sm sm:text-base text-indigo-100 leading-relaxed max-w-md">
              Challenge friends in Carrom, Uno, Star Mic, and Who’s the Spy. Level up voice rooms with gifts, collect CP with your Family, and unlock VIP 1–14 arrival animations.
            </p>
          </div>

          <div className="relative z-10 mt-8 grid grid-cols-2 gap-3">
            <div className="rounded-2xl overflow-hidden border border-white/15 bg-white/10">
              <img
                src="/src/assets/images/game_carrom_cover_1794694356725.jpg"
                alt="Carrom board game"
                referrerPolicy="no-referrer"
                className="w-full h-24 object-cover"
              />
              <div className="px-3 py-2 text-xs font-semibold">Carrom Arena</div>
            </div>
            <div className="rounded-2xl overflow-hidden border border-white/15 bg-white/10">
              <img
                src="/src/assets/images/game_uno_cover_1794694357332.jpg"
                alt="Uno card game"
                referrerPolicy="no-referrer"
                className="w-full h-24 object-cover"
              />
              <div className="px-3 py-2 text-xs font-semibold">Uno Blitz</div>
            </div>
          </div>
        </div>

        {/* Right Login Form */}
        <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-center">
          <div className="max-w-md w-full mx-auto">
            <h2 className="font-display text-2xl font-bold text-slate-900">Sign in to JoyPlay</h2>
            <p className="mt-1.5 text-sm text-slate-500">
              Choose Gmail, Facebook, or your phone number to access your account and coins.
            </p>

            {/* Provider Segmented Selector */}
            <div className="mt-6 grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => handleSelectProvider('gmail')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[44px] ${
                  provider === 'gmail'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Mail className="w-4 h-4 text-rose-500" />
                <span>Gmail</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectProvider('facebook')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[44px] ${
                  provider === 'facebook'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold">f</span>
                <span>Facebook</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectProvider('phone')}
                className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[44px] ${
                  provider === 'phone'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Phone className="w-4 h-4 text-emerald-600" />
                <span>Phone</span>
              </button>
            </div>

            {error && (
              <div className="mt-4 rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs font-medium text-rose-700">
                {error}
              </div>
            )}

            {step === 'identify' ? (
              <form onSubmit={handleRequestCode} className="mt-6 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {provider === 'gmail'
                      ? 'Gmail Address'
                      : provider === 'facebook'
                      ? 'Facebook Username or Email'
                      : 'Mobile Phone Number'}
                  </label>
                  <input
                    type={provider === 'gmail' ? 'email' : provider === 'phone' ? 'tel' : 'text'}
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder={
                      provider === 'gmail'
                        ? 'player@gmail.com'
                        : provider === 'facebook'
                        ? 'alex.rivera'
                        : '+1 555 234 5678'
                    }
                    className="w-full h-12 px-4 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Display Nickname (optional for new accounts)
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. AceStriker"
                    maxLength={28}
                    className="w-full h-12 px-4 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">
                      Profile Photo (Real PFP)
                    </label>
                    <label className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Own</span>
                      <input type="file" accept="image/*" onChange={handleUploadPhoto} className="hidden" />
                    </label>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <AvatarBadge dp={selectedDp} name={displayName || 'Player'} size="md" showVipRing={false} />
                    <div className="flex items-center gap-2 flex-wrap">
                      {REAL_PFP_PRESETS.map((pfp) => (
                        <button
                          key={pfp.id}
                          type="button"
                          onClick={() => setSelectedDp(pfp.id)}
                          className={`w-10 h-10 rounded-full overflow-hidden border-2 transition-all ${
                            selectedDp === pfp.id ? 'border-indigo-600 scale-105' : 'border-slate-200 opacity-80 hover:opacity-100'
                          }`}
                          title={pfp.label}
                        >
                          <img src={pfp.imageUrl} alt={pfp.label} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors disabled:opacity-60"
                >
                  <span>{loading ? 'Sending Verification...' : `Continue with ${provider === 'gmail' ? 'Gmail' : provider === 'facebook' ? 'Facebook' : 'Phone'}`}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerify} className="mt-6 space-y-4">
                <div className="rounded-xl bg-indigo-50 border border-indigo-200 px-4 py-3 text-xs text-indigo-900">
                  <div className="flex items-center gap-2 font-semibold">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    <span>Verification code sent to {identifier}</span>
                  </div>
                  {previewCode && (
                    <div className="mt-1.5 flex items-center justify-between text-indigo-700">
                      <span>Your 6-digit code:</span>
                      <span className="font-mono-num font-bold text-sm tracking-widest bg-white px-2.5 py-0.5 rounded-md border border-indigo-200">
                        {previewCode}
                      </span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Enter 6-Digit Verification Code
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={codeInput}
                    onChange={(e) => setCodeInput(e.target.value)}
                    placeholder="123456"
                    className="w-full h-12 px-4 rounded-xl border border-slate-300 text-center font-mono-num text-lg font-bold tracking-[0.35em] text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setStep('identify');
                      setError(null);
                    }}
                    className="h-12 px-4 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap"
                  >
                    Change Account
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 h-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors disabled:opacity-60"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{loading ? 'Signing In...' : 'Verify & Enter JoyPlay'}</span>
                  </button>
                </div>
              </form>
            )}

            <div className="mt-6 pt-5 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Protected with privacy controls, parental spend limits, and unique player IDs.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
