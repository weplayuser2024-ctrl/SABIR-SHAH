import React, { useState } from 'react';
import {
  X,
  Coins,
  Trophy,
  CheckCircle2,
  Users,
  Sparkles,
  Crown,
  Gift,
  UserPlus,
  UserCheck,
  Radio,
} from 'lucide-react';
import {
  DAILY_TASKS,
  PublicFriend,
  TOPUP_PACKAGES,
  UserProfile,
  VIP_TIERS,
} from '../shared/types';
import { AvatarBadge } from './AvatarBadge';
import { playCoinChime } from '../utils/sound';

// ---- TOP UP MODAL ----
interface TopUpModalProps {
  user: UserProfile;
  onClose: () => void;
  onTopUpSuccess: (user: UserProfile, added: number) => void;
}

export const TopUpModal: React.FC<TopUpModalProps> = ({ user, onClose, onTopUpSuccess }) => {
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleBuyPackage = async (packageId: string) => {
    setLoadingId(packageId);
    setFeedback(null);
    try {
      const token = localStorage.getItem('joyplay_token') || '';
      const res = await fetch('/api/coins/topup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ packageId }),
      });
      const data = await res.json();
      if (res.ok) {
        playCoinChime();
        setFeedback(`+${data.addedCoins.toLocaleString()} Coins added to your balance!`);
        onTopUpSuccess(data.user, data.addedCoins);
      }
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900">Top Up Coins</h3>
            <p className="text-xs text-slate-500">
              Current Balance: <span className="font-mono-num font-bold text-amber-600">{user.coins.toLocaleString()}</span> Coins · Spend coins on gifts, rooms & shop to unlock VIP 1–14
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Top Up"
            className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 thin-scroll">
          {feedback && (
            <div className="rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{feedback}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
            {TOPUP_PACKAGES.map((pkg) => (
              <button
                key={pkg.id}
                onClick={() => handleBuyPackage(pkg.id)}
                disabled={loadingId !== null}
                className="group text-left rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-md p-4 transition-all bg-gradient-to-b from-white to-amber-50/40 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold text-amber-700">{pkg.tag}</span>
                    <span>+{pkg.bonus.toLocaleString()} Bonus</span>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                      <Coins className="w-5 h-5" />
                    </div>
                    <div className="font-mono-num text-xl font-bold text-slate-900">
                      {pkg.coins.toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Total {(pkg.coins + pkg.bonus).toLocaleString()}</span>
                  <span className="px-3 py-1.5 rounded-lg bg-amber-500 group-hover:bg-amber-600 text-white text-xs font-bold whitespace-nowrap">
                    {loadingId === pkg.id ? 'Adding...' : pkg.priceLabel}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ---- EVENTS MODAL ----
interface EventsModalProps {
  user: UserProfile;
  onClose: () => void;
  onClaimEvent: (eventId: string) => Promise<string | null>;
}

export const EventsModal: React.FC<EventsModalProps> = ({ user, onClose, onClaimEvent }) => {
  const [msg, setMsg] = useState<string | null>(null);

  const events = [
    {
      id: 'evt_welcome_festival',
      title: 'Grand Party Festival Bonus',
      desc: 'Celebrate the season with free party coins and Family CP!',
      coins: 300,
      cp: 150,
      locked: false,
      lockLabel: 'Available Now',
    },
    {
      id: 'evt_party_streak',
      title: 'Weekend Squad Warmup',
      desc: 'Join a Voice Room or play Carrom, Uno, Mic, or Spy today.',
      coins: 450,
      cp: 200,
      locked: false,
      lockLabel: 'Available Now',
    },
    {
      id: 'evt_vip_celebration',
      title: 'VIP Royal Showcase Gift',
      desc: 'Exclusive bonus chest for players who reached VIP Level 1 or higher.',
      coins: 600,
      cp: 250,
      locked: user.vipLevel < 1,
      lockLabel: user.vipLevel < 1 ? 'Requires VIP 1+' : `Unlocked (VIP ${user.vipLevel})`,
    },
  ];

  const handleClaim = async (id: string) => {
    const err = await onClaimEvent(id);
    if (err) setMsg(err);
    else {
      playCoinChime();
      setMsg('Event reward claimed!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        <div className="relative h-44 sm:h-52 w-full bg-indigo-950 shrink-0">
          <img
            src="/src/assets/images/event_festival_banner_1794694357646.jpg"
            alt="JoyPlay Grand Festival"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/35 to-transparent flex flex-col justify-end p-6">
            <div className="text-xs font-semibold text-amber-300">Seasonal Events · Streak Day {user.dailyCheckinStreak}</div>
            <h3 className="font-display text-2xl font-extrabold text-white">JoyPlay Crown Festival</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Events"
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/45 hover:bg-black/65 text-white flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-3 thin-scroll">
          {msg && (
            <div className="rounded-xl bg-indigo-50 border border-indigo-200 px-4 py-2.5 text-xs font-semibold text-indigo-800">
              {msg}
            </div>
          )}

          {events.map((evt) => {
            const claimed = user.claimedEvents.includes(evt.id);
            return (
              <div
                key={evt.id}
                className="rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div>
                  <div className="text-xs text-slate-500">
                    {evt.lockLabel} · +{evt.coins} Coins · +{evt.cp} CP
                  </div>
                  <h4 className="font-display text-base font-bold text-slate-900 mt-0.5">{evt.title}</h4>
                  <p className="text-xs text-slate-600 mt-1">{evt.desc}</p>
                </div>
                <button
                  onClick={() => handleClaim(evt.id)}
                  disabled={claimed || evt.locked}
                  className={`px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 min-h-[40px] ${
                    claimed
                      ? 'bg-slate-100 text-slate-400'
                      : evt.locked
                      ? 'bg-slate-100 text-slate-500'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  }`}
                >
                  {claimed ? 'Claimed' : evt.locked ? 'Locked' : 'Claim Reward'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ---- RANKINGS MODAL ----
interface RankingEntry {
  rank: number;
  id: string;
  name: string;
  dp: string;
  vipLevel: number;
  charmPoints?: number;
  score: number;
}

interface RankingsModalProps {
  rankings: { wealth: RankingEntry[]; charm: RankingEntry[]; wins: RankingEntry[] };
  onClose: () => void;
}

export const RankingsModal: React.FC<RankingsModalProps> = ({ rankings, onClose }) => {
  const [tab, setTab] = useState<'wealth' | 'charm' | 'wins'>('charm');
  const rows = rankings[tab] || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[88vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-amber-500" />
            <h3 className="font-display text-lg font-bold text-slate-900">Hall of Fame Rankings</h3>
          </div>
          <button onClick={onClose} aria-label="Close Rankings" className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 pt-4">
          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setTab('wealth')}
              className={`py-2 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                tab === 'wealth' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              VIP Wealth
            </button>
            <button
              onClick={() => setTab('charm')}
              className={`py-2 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                tab === 'charm' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Room Charm
            </button>
            <button
              onClick={() => setTab('wins')}
              className={`py-2 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                tab === 'wins' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Game Wins
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto space-y-2.5 thin-scroll">
          {rows.map((entry) => {
            const vipTier = VIP_TIERS[Math.min(14, entry.vipLevel)];
            return (
              <div
                key={entry.id}
                className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-slate-50/70 px-4 py-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center font-mono-num text-xs font-bold shrink-0 ${
                      entry.rank === 1
                        ? 'bg-amber-400 text-slate-950'
                        : entry.rank === 2
                        ? 'bg-slate-300 text-slate-900'
                        : entry.rank === 3
                        ? 'bg-orange-300 text-slate-900'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {entry.rank}
                  </div>
                  <AvatarBadge dp={entry.dp} name={entry.name} vipLevel={entry.vipLevel} size="sm" />
                  <div className="min-w-0">
                    <div className="font-semibold text-sm text-slate-900 truncate">{entry.name}</div>
                    <div className="text-xs text-slate-500 font-mono-num">
                      ID {entry.id} · {vipTier.name} · ✨ {(entry.charmPoints ?? 0).toLocaleString()} Charm
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-mono-num text-sm font-bold text-indigo-700">
                    {entry.score.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {tab === 'wealth' ? 'Coins Spent' : tab === 'charm' ? 'Charm' : 'Wins'}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ---- TASKS MODAL ----
interface TasksModalProps {
  user: UserProfile;
  taskProgress: Record<string, number>;
  onClose: () => void;
  onClaimTask: (taskId: string) => Promise<string | null>;
}

export const TasksModal: React.FC<TasksModalProps> = ({ user, taskProgress, onClose, onClaimTask }) => {
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleClaim = async (taskId: string) => {
    const err = await onClaimTask(taskId);
    if (err) setFeedback(err);
    else {
      playCoinChime();
      setFeedback('Task reward claimed!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[88vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <h3 className="font-display text-lg font-bold text-slate-900">Daily Party Tasks</h3>
          </div>
          <button onClick={onClose} aria-label="Close Tasks" className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-3 thin-scroll">
          {feedback && (
            <div className="rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-xs font-semibold text-emerald-800">
              {feedback}
            </div>
          )}

          {DAILY_TASKS.map((task) => {
            const current = Math.min(task.target, taskProgress[task.metric] || 0);
            const ready = current >= task.target;
            const claimed = user.claimedTasks.includes(task.id);

            return (
              <div
                key={task.id}
                className="rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="text-xs text-slate-500">
                    Reward: +{task.rewardCoins} Coins · +{task.rewardCp} CP · Progress {current}/{task.target}
                  </div>
                  <h4 className="font-display text-sm font-bold text-slate-900">{task.title}</h4>
                  <p className="text-xs text-slate-600">{task.description}</p>
                </div>

                <button
                  onClick={() => handleClaim(task.id)}
                  disabled={!ready || claimed}
                  className={`px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 min-h-[40px] ${
                    claimed
                      ? 'bg-slate-100 text-slate-400'
                      : ready
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                      : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {claimed ? 'Claimed' : ready ? 'Claim' : 'In Progress'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ---- ONLINE FRIENDS MODAL ----
interface FriendsModalProps {
  user: UserProfile;
  friends: PublicFriend[];
  onClose: () => void;
  onToggleFriend: (friendId: string) => Promise<void>;
  onSendCp: (friendId: string) => Promise<string | null>;
  onJoinRoom: (roomId: string) => void;
}

export const FriendsModal: React.FC<FriendsModalProps> = ({
  user,
  friends,
  onClose,
  onToggleFriend,
  onSendCp,
  onJoinRoom,
}) => {
  const [filter, setFilter] = useState<'online' | 'all'>('online');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const visibleFriends = friends.filter((f) => (filter === 'online' ? f.isOnline : true));

  const handleGiftCp = async (friendId: string, friendName: string) => {
    const err = await onSendCp(friendId);
    if (err) setStatusMsg(err);
    else {
      playCoinChime();
      setStatusMsg(`Sent +40 CP to ${friendName}!`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[88vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-emerald-600" />
            <h3 className="font-display text-lg font-bold text-slate-900">Online Friends & Players</h3>
          </div>
          <button onClick={onClose} aria-label="Close Friends" className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 pt-4 flex items-center justify-between gap-3">
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl w-52">
            <button
              onClick={() => setFilter('online')}
              className={`py-1.5 px-3 rounded-lg text-xs font-semibold ${
                filter === 'online' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Online ({friends.filter((f) => f.isOnline).length})
            </button>
            <button
              onClick={() => setFilter('all')}
              className={`py-1.5 px-3 rounded-lg text-xs font-semibold ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              All ({friends.length})
            </button>
          </div>
          <span className="text-xs text-slate-500">Send CP costs 20 Coins</span>
        </div>

        <div className="p-6 overflow-y-auto space-y-3 thin-scroll">
          {statusMsg && (
            <div className="rounded-xl bg-indigo-50 border border-indigo-200 px-4 py-2.5 text-xs font-semibold text-indigo-800">
              {statusMsg}
            </div>
          )}

          {visibleFriends.length === 0 ? (
            <div className="text-center py-10 text-sm text-slate-500">
              No friends matching this filter right now.
            </div>
          ) : (
            visibleFriends.map((friend) => {
              const isAdded = user.friends.includes(friend.id);
              return (
                <div
                  key={friend.id}
                  className="rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <AvatarBadge dp={friend.dp} name={friend.name} vipLevel={friend.vipLevel} size="md" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-slate-900 truncate">{friend.name}</span>
                        <span className="text-[11px] font-bold text-amber-600 inline-flex items-center gap-1 font-mono-num shrink-0">
                          <Crown className="w-3 h-3" /> VIP {friend.vipLevel} · ✨ {friend.charmPoints.toLocaleString()} Charm
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 truncate">
                        ID {friend.id} · {friend.isOnline ? 'Online' : 'Offline'} · {friend.currentActivity}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {friend.currentRoomId && (
                      <button
                        onClick={() => {
                          onJoinRoom(friend.currentRoomId!);
                          onClose();
                        }}
                        className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <Radio className="w-3.5 h-3.5" />
                        <span>Join Room</span>
                      </button>
                    )}
                    <button
                      onClick={() => handleGiftCp(friend.id, friend.name)}
                      className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold inline-flex items-center gap-1 whitespace-nowrap"
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>+40 CP</span>
                    </button>
                    <button
                      onClick={() => onToggleFriend(friend.id)}
                      aria-label={isAdded ? 'Remove Friend' : 'Add Friend'}
                      className={`p-2 rounded-xl border text-xs font-semibold ${
                        isAdded
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {isAdded ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
