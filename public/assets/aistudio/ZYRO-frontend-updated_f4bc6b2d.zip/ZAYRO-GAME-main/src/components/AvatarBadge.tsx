import React, { useState } from 'react';
import { AVATAR_PRESETS, REAL_PFP_PRESETS, VIP_TIERS } from '../shared/types';

interface AvatarBadgeProps {
  dp: string;
  name: string;
  vipLevel?: number;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showVipRing?: boolean;
  className?: string;
}

const SIZE_CLASSES = {
  xs: 'w-7 h-7 text-sm',
  sm: 'w-9 h-9 text-base',
  md: 'w-12 h-12 text-xl',
  lg: 'w-16 h-16 text-3xl',
  xl: 'w-20 h-20 text-4xl',
};

export const AvatarBadge: React.FC<AvatarBadgeProps> = ({
  dp,
  name,
  vipLevel = 0,
  size = 'md',
  showVipRing = true,
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);
  const realPfp = REAL_PFP_PRESETS.find((p) => p.id === dp);
  const preset = AVATAR_PRESETS.find((p) => p.id === dp);
  const vipInfo = VIP_TIERS[Math.min(14, Math.max(0, vipLevel))];
  const imageSrc = realPfp
    ? realPfp.imageUrl
    : dp.startsWith('data:image') || dp.startsWith('http') || dp.startsWith('/')
    ? dp
    : null;

  const ringStyle =
    showVipRing && vipLevel >= 1
      ? {
          boxShadow: `0 0 0 2px #ffffff, 0 0 0 4px ${vipInfo.primaryColor}`,
        }
      : undefined;

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-full shrink-0 select-none overflow-hidden ${SIZE_CLASSES[size]} ${
        preset ? `bg-gradient-to-br ${preset.bg}` : 'bg-indigo-600 text-white'
      } ${className}`}
      style={ringStyle}
      title={name}
    >
      {imageSrc && !imgError ? (
        <img
          src={imageSrc}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover"
        />
      ) : preset ? (
        <span aria-hidden="true">{preset.emoji}</span>
      ) : (
        <span className="font-display font-bold uppercase text-white">
          {name.slice(0, 1) || 'J'}
        </span>
      )}
    </div>
  );
};
