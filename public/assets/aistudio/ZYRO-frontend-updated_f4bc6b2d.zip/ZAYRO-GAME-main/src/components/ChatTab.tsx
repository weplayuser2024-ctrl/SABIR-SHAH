import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Check,
  CheckCheck,
  Mail,
  MessageSquare,
  Radio,
  Search,
  Send,
  X,
} from 'lucide-react';
import { DirectMessage, PublicFriend, RoomInvitation, UserProfile } from '../shared/types';
import { AvatarBadge } from './AvatarBadge';

interface ChatTabProps {
  user: UserProfile;
  friends: PublicFriend[];
  invitations: RoomInvitation[];
  chatPreviews: Record<string, DirectMessage | null>;
  initialFriendId: string | null;
  incomingDm: DirectMessage | null;
  authHeaders: () => Record<string, string>;
  onJoinRoom: (roomId: string) => void;
  onRespondInvitation: (invitationId: string, action: 'accept' | 'decline', roomId?: string) => Promise<void>;
  onUpdatePreview: (friendId: string, message: DirectMessage) => void;
}

export const ChatTab: React.FC<ChatTabProps> = ({
  user,
  friends,
  invitations,
  chatPreviews,
  initialFriendId,
  incomingDm,
  authHeaders,
  onJoinRoom,
  onRespondInvitation,
  onUpdatePreview,
}) => {
  const [viewMode, setViewMode] = useState<'messages' | 'invites'>('messages');
  const [selectedFriendId, setSelectedFriendId] = useState<string | null>(
    initialFriendId || friends[0]?.id || null
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [mobileShowThread, setMobileShowThread] = useState(Boolean(initialFriendId));

  const scrollRef = useRef<HTMLDivElement | null>(null);

  const pendingInvites = invitations.filter((i) => i.status === 'pending');
  const selectedFriend = friends.find((f) => f.id === selectedFriendId) || null;

  useEffect(() => {
    if (initialFriendId) {
      setSelectedFriendId(initialFriendId);
      setMobileShowThread(true);
      setViewMode('messages');
    }
  }, [initialFriendId]);

  useEffect(() => {
    if (!selectedFriendId) return;
    let active = true;
    setLoading(true);
    fetch(`/api/chats/${encodeURIComponent(selectedFriendId)}`, {
      headers: authHeaders(),
    })
      .then((res) => res.json())
      .then((data) => {
        if (active && Array.isArray(data.messages)) {
          setMessages(data.messages);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedFriendId, authHeaders]);

  useEffect(() => {
    if (!incomingDm || !selectedFriendId) return;
    const matchesThread =
      (incomingDm.fromId === selectedFriendId && incomingDm.toId === user.id) ||
      (incomingDm.fromId === user.id && incomingDm.toId === selectedFriendId);
    if (matchesThread) {
      setMessages((prev) =>
        prev.some((m) => m.id === incomingDm.id) ? prev : [...prev, incomingDm]
      );
    }
  }, [incomingDm, selectedFriendId, user.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, selectedFriendId]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !selectedFriendId || sending) return;
    setSending(true);
    setDraft('');
    try {
      const res = await fetch(`/api/chats/${encodeURIComponent(selectedFriendId)}`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data.messages)) {
        setMessages(data.messages);
        if (data.message) {
          onUpdatePreview(selectedFriendId, data.message);
        }
      }
    } catch {
      // Keep UI responsive
    } finally {
      setSending(false);
    }
  };

  const filteredFriends = friends.filter((f) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return f.name.toLowerCase().includes(q) || f.id.toLowerCase().includes(q);
  });

  const formatTime = (ts: number) =>
    new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="max-w-5xl mx-auto px-4 pt-4 pb-28 space-y-5">
      {/* Header & Section Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-extrabold text-slate-900">Chat & Invites</h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Messages from friends and live Voice Room invitations
          </p>
        </div>

        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-200/70 rounded-xl w-full sm:w-80">
          <button
            type="button"
            onClick={() => setViewMode('messages')}
            className={`h-10 px-3 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 whitespace-nowrap transition-colors ${
              viewMode === 'messages' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Friend Messages</span>
          </button>
          <button
            type="button"
            onClick={() => setViewMode('invites')}
            className={`h-10 px-3 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 whitespace-nowrap transition-colors ${
              viewMode === 'invites' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Room Invites ({pendingInvites.length})</span>
          </button>
        </div>
      </div>

      {/* Pending Room Invitations Highlight Banner when on Messages view */}
      {viewMode === 'messages' && pendingInvites.length > 0 && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-900 truncate">
                {pendingInvites[0].fromName} invited you to {pendingInvites[0].roomTitle}
              </div>
              <div className="text-[11px] text-slate-600 truncate">
                Lv.{pendingInvites[0].roomLevel} · {pendingInvites[0].roomType}
                {pendingInvites.length > 1 ? ` · +${pendingInvites.length - 1} more invite(s)` : ''}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() =>
                onRespondInvitation(pendingInvites[0].id, 'accept', pendingInvites[0].roomId)
              }
              className="h-9 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold whitespace-nowrap"
            >
              Join Room
            </button>
            <button
              type="button"
              onClick={() => setViewMode('invites')}
              className="h-9 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold whitespace-nowrap"
            >
              View All
            </button>
          </div>
        </div>
      )}

      {viewMode === 'invites' ? (
        <section className="space-y-3">
          {invitations.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center space-y-2">
              <div className="font-display text-base font-bold text-slate-900">
                No room invitations yet
              </div>
              <p className="text-xs text-slate-500">
                When a friend invites you to their Voice Room, it will appear right here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {invitations.map((inv) => {
                const isPending = inv.status === 'pending';
                return (
                  <div
                    key={inv.id}
                    className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <AvatarBadge
                            dp={inv.fromDp}
                            name={inv.fromName}
                            vipLevel={inv.fromVipLevel}
                            size="sm"
                          />
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-slate-900 truncate">
                              {inv.fromName}
                            </div>
                            <div className="font-mono-num text-[11px] text-slate-500">
                              UID {inv.fromId} · {formatTime(inv.createdAt)}
                            </div>
                          </div>
                        </div>
                        <span
                          className={`text-[11px] font-semibold ${
                            isPending
                              ? 'text-indigo-600'
                              : inv.status === 'accepted'
                              ? 'text-emerald-600'
                              : 'text-slate-400'
                          }`}
                        >
                          {isPending ? 'Pending' : inv.status === 'accepted' ? 'Joined' : 'Declined'}
                        </span>
                      </div>

                      <div className="rounded-2xl bg-slate-50 border border-slate-100 p-3.5 space-y-1">
                        <div className="text-xs font-semibold text-indigo-600">
                          {inv.roomType} · Lv.{inv.roomLevel}
                        </div>
                        <div className="font-display text-base font-bold text-slate-900">
                          {inv.roomTitle}
                        </div>
                        <p className="text-xs text-slate-600">“{inv.message}”</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onRespondInvitation(inv.id, 'accept', inv.roomId)}
                        className="flex-1 h-11 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>{isPending ? 'Accept & Join Room' : 'Enter Room'}</span>
                      </button>
                      {isPending && (
                        <button
                          type="button"
                          onClick={() => onRespondInvitation(inv.id, 'decline')}
                          aria-label="Decline invitation"
                          className="h-11 px-4 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 text-xs font-semibold inline-flex items-center justify-center gap-1"
                        >
                          <X className="w-4 h-4" />
                          <span>Decline</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      ) : (
        /* Friend Messages Split View */
        <section className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden grid grid-cols-1 md:grid-cols-12 h-[68vh] min-h-[480px] max-h-[680px]">
          {/* Left Pane: Friends List */}
          <aside
            className={`md:col-span-4 border-r border-slate-200 bg-slate-50 flex flex-col min-h-0 ${
              mobileShowThread ? 'hidden md:flex' : 'flex'
            }`}
          >
            <div className="p-3 border-b border-slate-200 bg-white">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search friend or UID..."
                  className="w-full h-10 pl-9 pr-3 rounded-xl bg-slate-100 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 thin-scroll">
              {filteredFriends.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  No friends match “{searchQuery}”.
                </div>
              ) : (
                filteredFriends.map((friend) => {
                  const active = friend.id === selectedFriendId;
                  const preview = chatPreviews[friend.id];
                  return (
                    <button
                      key={friend.id}
                      type="button"
                      onClick={() => {
                        setSelectedFriendId(friend.id);
                        setMobileShowThread(true);
                      }}
                      className={`w-full px-4 py-3 text-left flex items-center gap-3 transition-colors ${
                        active ? 'bg-indigo-50' : 'hover:bg-white'
                      }`}
                    >
                      <AvatarBadge
                        dp={friend.dp}
                        name={friend.name}
                        vipLevel={friend.vipLevel}
                        size="sm"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-bold text-slate-900 truncate">
                            {friend.name}
                          </span>
                          <span
                            className={`text-[10px] font-semibold shrink-0 ${
                              friend.isOnline ? 'text-emerald-600' : 'text-slate-400'
                            }`}
                          >
                            {friend.isOnline ? 'Online' : 'Offline'}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 truncate mt-0.5">
                          {preview
                            ? `${preview.fromId === user.id ? 'You: ' : ''}${preview.text}`
                            : friend.currentActivity}
                        </div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </aside>

          {/* Right Pane: Conversation Thread */}
          <div
            className={`md:col-span-8 flex flex-col min-h-0 bg-slate-50/50 ${
              mobileShowThread ? 'flex' : 'hidden md:flex'
            }`}
          >
            {selectedFriend ? (
              <>
                <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between gap-3 shrink-0">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      onClick={() => setMobileShowThread(false)}
                      aria-label="Back to friends list"
                      className="md:hidden w-9 h-9 rounded-xl hover:bg-slate-100 flex items-center justify-center text-slate-600"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <AvatarBadge
                      dp={selectedFriend.dp}
                      name={selectedFriend.name}
                      vipLevel={selectedFriend.vipLevel}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-slate-900 truncate">
                        {selectedFriend.name}
                      </div>
                      <div className="font-mono-num text-[11px] text-slate-500 truncate">
                        UID {selectedFriend.id} · VIP {selectedFriend.vipLevel} · ✨ {selectedFriend.charmPoints.toLocaleString()} Charm
                      </div>
                    </div>
                  </div>

                  {selectedFriend.currentRoomId && (
                    <button
                      type="button"
                      onClick={() => onJoinRoom(selectedFriend.currentRoomId!)}
                      className="h-9 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <Radio className="w-3.5 h-3.5" />
                      <span>Join Room</span>
                    </button>
                  )}
                </div>

                <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2.5 thin-scroll">
                  {loading ? (
                    <div className="text-center py-8 text-xs text-slate-500">
                      Loading messages...
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="max-w-xs mx-auto my-8 rounded-2xl bg-white border border-slate-200 px-4 py-3 text-center text-xs text-slate-600">
                      No messages with <strong>{selectedFriend.name}</strong> yet. Say hello!
                    </div>
                  ) : (
                    messages.map((m) => {
                      const isMine = m.fromId === user.id;
                      return (
                        <div
                          key={m.id}
                          className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-xs sm:text-sm shadow-xs ${
                              isMine
                                ? 'bg-indigo-600 text-white rounded-tr-sm'
                                : 'bg-white border border-slate-200 text-slate-900 rounded-tl-sm'
                            }`}
                          >
                            <p className="leading-relaxed break-words">{m.text}</p>
                            <div
                              className={`mt-1 flex items-center justify-end gap-1 font-mono-num text-[10px] ${
                                isMine ? 'text-indigo-100' : 'text-slate-400'
                              }`}
                            >
                              <span>{formatTime(m.timestamp)}</span>
                              {isMine && <CheckCheck className="w-3.5 h-3.5" />}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                <form
                  onSubmit={handleSend}
                  className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
                >
                  <input
                    type="text"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder={`Message ${selectedFriend.name}...`}
                    maxLength={400}
                    className="flex-1 h-11 px-4 rounded-xl bg-slate-100 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    disabled={!draft.trim() || sending}
                    aria-label="Send message"
                    className="w-11 h-11 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white flex items-center justify-center shrink-0 transition-colors"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center p-6 text-xs text-slate-500">
                Select a friend to view messages.
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
